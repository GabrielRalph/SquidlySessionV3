/**
 * Letter Selector Module
 * 
 * Handles letter selection UI components for the keyboard panel.
 * Provides LetterIcon, LettersIcon, LetterLayout, and related events.
 */

import { GridIcon, GridLayout } from "../../Utilities/Buttons/grid-icon.js";
import { AccessEvent } from "../../Utilities/Buttons/access-buttons.js";

// Letter groups configuration
export const LETTER_GROUPS = {
    "atoi": {
        letters: "abcdefghi",
        icon: { symbol: "atoi", type: "topic-action" },
    },
    "jtor": {
        letters: "jklmnopqr",
        icon: { symbol: "jtor", type: "topic-action" },
    },
    "sto0": {
        letters: "stuvwxyz0",
        icon: { symbol: "sto0", type: "topic-action" },
    },
    "1to9": {
        letters: "123456789",
        icon: { symbol: "1to9", type: "topic-action" },
    }
}

// Special letters configuration
export const SPECIAL_LETTERS = {
    "space": {
        displayValue: "Space",
        symbol: "space",
        type: "action",
        letterValue: " ",
    }
}

// Event classes for letter selection
export class LetterEvent extends AccessEvent {
    constructor(letter, originalEvent) {
        super("letter", originalEvent, { bubbles: true });
        this.value = SPECIAL_LETTERS[letter]?.letterValue ?? letter;
    }
}

export class LettersEvent extends AccessEvent {
    constructor(letters, originalEvent) {
        super("show-letters", originalEvent, { bubbles: true });
        this.letters = letters;
    }
}

// Individual letter icon (for 9-grid display)
export class LetterIcon extends GridIcon {
    constructor(letter, group) {
        let config = SPECIAL_LETTERS[letter] || { type: "adjective", symbol: { text: letter.toUpperCase() } };
        config.events = { "access-click": (e) => { this.dispatchEvent(new LetterEvent(letter, e)) } }
        super(config, group);
    }
}

// Letter group icon (for A-I, J-R, S-Z, 1-9 buttons)
export class LettersIcon extends GridIcon {
    constructor(letterGroup, group) {
        const groupConfig = LETTER_GROUPS[letterGroup] ?? letterGroup;
        super(groupConfig.icon, group);
        this.events = {
            "access-click": (e) => {
                this.dispatchEvent(new LettersEvent(groupConfig.letters, e));
            }
        }
    }
}

// Letter layout for displaying 9 letters in a 2x5 grid
// Row 0: A-E (5 letters), Row 1: F-I (4 letters)
// Each letter button is the same size as back button (1 grid cell)
export class LetterLayout extends GridLayout {
    constructor() {
        super(2, 5); // 2 rows, 5 columns
    }

    /**
     * Show the letters in the letter grid.
     * @param {string} letters - String of letters to display (e.g., "abcdefghi")
     * @param {boolean} [immediate=false] - If true, set the content immediately without transition.
     */
    async showLetters(letters, immediate = false) {
        this.innerHTML = "";
        const lettersArray = [...letters].slice(0, 9);

        // Functional approach: calculate row/col instead of if-else
        lettersArray.forEach((letter, i) => {
            const icon = new LetterIcon(letter, `letter-${Math.floor(i / 5)}`);
            const row = Math.floor(i / 5); // 0 for first 5, 1 for next 4
            const col = i % 5; // Column position within row
            this.add(icon, row, col);
        });
    }
}

const words = [
  {
    "Word": "you",
    "FREQcount": "2134713"
  },
  {
    "Word": "I",
    "FREQcount": "2038529"
  },
  {
    "Word": "the",
    "FREQcount": "1501908"
  },
  {
    "Word": "to",
    "FREQcount": "1156570"
  },
  {
    "Word": "s",
    "FREQcount": "1057301"
  },
  {
    "Word": "a",
    "FREQcount": "1041179"
  },
  {
    "Word": "it",
    "FREQcount": "963712"
  },
  {
    "Word": "t",
    "FREQcount": "733338"
  },
  {
    "Word": "that",
    "FREQcount": "719677"
  },
  {
    "Word": "and",
    "FREQcount": "682780"
  },
  {
    "Word": "of",
    "FREQcount": "590439"
  },
  {
    "Word": "what",
    "FREQcount": "501965"
  },
  {
    "Word": "in",
    "FREQcount": "498444"
  },
  {
    "Word": "me",
    "FREQcount": "471339"
  },
  {
    "Word": "is",
    "FREQcount": "459663"
  },
  {
    "Word": "we",
    "FREQcount": "459607"
  },
  {
    "Word": "this",
    "FREQcount": "406915"
  },
  {
    "Word": "he",
    "FREQcount": "389497"
  },
  {
    "Word": "on",
    "FREQcount": "354742"
  },
  {
    "Word": "for",
    "FREQcount": "351650"
  },
  {
    "Word": "my",
    "FREQcount": "344899"
  },
  {
    "Word": "m",
    "FREQcount": "343245"
  },
  {
    "Word": "your",
    "FREQcount": "328715"
  },
  {
    "Word": "don",
    "FREQcount": "321085"
  },
  {
    "Word": "have",
    "FREQcount": "314232"
  },
  {
    "Word": "do",
    "FREQcount": "312915"
  },
  {
    "Word": "re",
    "FREQcount": "311072"
  },
  {
    "Word": "no",
    "FREQcount": "304549"
  },
  {
    "Word": "be",
    "FREQcount": "293085"
  },
  {
    "Word": "know",
    "FREQcount": "291780"
  },
  {
    "Word": "was",
    "FREQcount": "288391"
  },
  {
    "Word": "not",
    "FREQcount": "276673"
  },
  {
    "Word": "can",
    "FREQcount": "267620"
  },
  {
    "Word": "are",
    "FREQcount": "265672"
  },
  {
    "Word": "all",
    "FREQcount": "263255"
  },
  {
    "Word": "with",
    "FREQcount": "257465"
  },
  {
    "Word": "just",
    "FREQcount": "242206"
  },
  {
    "Word": "get",
    "FREQcount": "233772"
  },
  {
    "Word": "here",
    "FREQcount": "230788"
  },
  {
    "Word": "but",
    "FREQcount": "225291"
  },
  {
    "Word": "ll",
    "FREQcount": "224097"
  },
  {
    "Word": "there",
    "FREQcount": "221754"
  },
  {
    "Word": "so",
    "FREQcount": "216452"
  },
  {
    "Word": "they",
    "FREQcount": "209250"
  },
  {
    "Word": "right",
    "FREQcount": "204428"
  },
  {
    "Word": "like",
    "FREQcount": "203947"
  },
  {
    "Word": "out",
    "FREQcount": "197131"
  },
  {
    "Word": "go",
    "FREQcount": "193445"
  },
  {
    "Word": "she",
    "FREQcount": "190377"
  },
  {
    "Word": "up",
    "FREQcount": "187170"
  },
  {
    "Word": "about",
    "FREQcount": "185206"
  },
  {
    "Word": "if",
    "FREQcount": "180610"
  },
  {
    "Word": "him",
    "FREQcount": "177710"
  },
  {
    "Word": "got",
    "FREQcount": "168631"
  },
  {
    "Word": "oh",
    "FREQcount": "167781"
  },
  {
    "Word": "at",
    "FREQcount": "164072"
  },
  {
    "Word": "now",
    "FREQcount": "163333"
  },
  {
    "Word": "come",
    "FREQcount": "160190"
  },
  {
    "Word": "one",
    "FREQcount": "156684"
  },
  {
    "Word": "how",
    "FREQcount": "155867"
  },
  {
    "Word": "well",
    "FREQcount": "152523"
  },
  {
    "Word": "yeah",
    "FREQcount": "152262"
  },
  {
    "Word": "her",
    "FREQcount": "144627"
  },
  {
    "Word": "want",
    "FREQcount": "140718"
  },
  {
    "Word": "think",
    "FREQcount": "137261"
  },
  {
    "Word": "good",
    "FREQcount": "133117"
  },
  {
    "Word": "see",
    "FREQcount": "130393"
  },
  {
    "Word": "let",
    "FREQcount": "123381"
  },
  {
    "Word": "did",
    "FREQcount": "119410"
  },
  {
    "Word": "why",
    "FREQcount": "114687"
  },
  {
    "Word": "who",
    "FREQcount": "113370"
  },
  {
    "Word": "as",
    "FREQcount": "113068"
  },
  {
    "Word": "his",
    "FREQcount": "108364"
  },
  {
    "Word": "will",
    "FREQcount": "108306"
  },
  {
    "Word": "going",
    "FREQcount": "108288"
  },
  {
    "Word": "from",
    "FREQcount": "103992"
  },
  {
    "Word": "when",
    "FREQcount": "103739"
  },
  {
    "Word": "back",
    "FREQcount": "102467"
  },
  {
    "Word": "okay",
    "FREQcount": "102320"
  },
  {
    "Word": "yes",
    "FREQcount": "101835"
  },
  {
    "Word": "gonna",
    "FREQcount": "101804"
  },
  {
    "Word": "d",
    "FREQcount": "101335"
  },
  {
    "Word": "time",
    "FREQcount": "99890"
  },
  {
    "Word": "look",
    "FREQcount": "99311"
  },
  {
    "Word": "take",
    "FREQcount": "96443"
  },
  {
    "Word": "an",
    "FREQcount": "95071"
  },
  {
    "Word": "man",
    "FREQcount": "94133"
  },
  {
    "Word": "where",
    "FREQcount": "93341"
  },
  {
    "Word": "them",
    "FREQcount": "90720"
  },
  {
    "Word": "would",
    "FREQcount": "90162"
  },
  {
    "Word": "been",
    "FREQcount": "88573"
  },
  {
    "Word": "some",
    "FREQcount": "88089"
  },
  {
    "Word": "hey",
    "FREQcount": "88079"
  },
  {
    "Word": "tell",
    "FREQcount": "87949"
  },
  {
    "Word": "or",
    "FREQcount": "86970"
  },
  {
    "Word": "us",
    "FREQcount": "86478"
  },
  {
    "Word": "had",
    "FREQcount": "85472"
  },
  {
    "Word": "were",
    "FREQcount": "84804"
  },
  {
    "Word": "say",
    "FREQcount": "83629"
  },
  {
    "Word": "could",
    "FREQcount": "83109"
  },
  {
    "Word": "didn",
    "FREQcount": "80623"
  },
  {
    "Word": "really",
    "FREQcount": "76508"
  },
  {
    "Word": "something",
    "FREQcount": "76508"
  },
  {
    "Word": "down",
    "FREQcount": "76004"
  },
  {
    "Word": "then",
    "FREQcount": "75966"
  },
  {
    "Word": "little",
    "FREQcount": "73766"
  },
  {
    "Word": "way",
    "FREQcount": "72661"
  },
  {
    "Word": "our",
    "FREQcount": "71425"
  },
  {
    "Word": "make",
    "FREQcount": "70775"
  },
  {
    "Word": "too",
    "FREQcount": "69950"
  },
  {
    "Word": "never",
    "FREQcount": "69490"
  },
  {
    "Word": "by",
    "FREQcount": "68364"
  },
  {
    "Word": "over",
    "FREQcount": "67488"
  },
  {
    "Word": "more",
    "FREQcount": "66228"
  },
  {
    "Word": "need",
    "FREQcount": "66040"
  },
  {
    "Word": "mean",
    "FREQcount": "63443"
  },
  {
    "Word": "very",
    "FREQcount": "63304"
  },
  {
    "Word": "off",
    "FREQcount": "60155"
  },
  {
    "Word": "mr",
    "FREQcount": "60098"
  },
  {
    "Word": "sorry",
    "FREQcount": "59566"
  },
  {
    "Word": "give",
    "FREQcount": "59559"
  },
  {
    "Word": "has",
    "FREQcount": "57830"
  },
  {
    "Word": "thank",
    "FREQcount": "56877"
  },
  {
    "Word": "love",
    "FREQcount": "56864"
  },
  {
    "Word": "said",
    "FREQcount": "56531"
  },
  {
    "Word": "am",
    "FREQcount": "56438"
  },
  {
    "Word": "people",
    "FREQcount": "56252"
  },
  {
    "Word": "please",
    "FREQcount": "56149"
  },
  {
    "Word": "sure",
    "FREQcount": "56091"
  },
  {
    "Word": "any",
    "FREQcount": "56068"
  },
  {
    "Word": "thing",
    "FREQcount": "55522"
  },
  {
    "Word": "only",
    "FREQcount": "55269"
  },
  {
    "Word": "because",
    "FREQcount": "54622"
  },
  {
    "Word": "two",
    "FREQcount": "54384"
  },
  {
    "Word": "should",
    "FREQcount": "54159"
  },
  {
    "Word": "doing",
    "FREQcount": "52492"
  },
  {
    "Word": "much",
    "FREQcount": "49636"
  },
  {
    "Word": "sir",
    "FREQcount": "49188"
  },
  {
    "Word": "maybe",
    "FREQcount": "47249"
  },
  {
    "Word": "help",
    "FREQcount": "46977"
  },
  {
    "Word": "anything",
    "FREQcount": "46270"
  },
  {
    "Word": "these",
    "FREQcount": "46104"
  },
  {
    "Word": "god",
    "FREQcount": "46061"
  },
  {
    "Word": "even",
    "FREQcount": "44672"
  },
  {
    "Word": "night",
    "FREQcount": "44168"
  },
  {
    "Word": "call",
    "FREQcount": "43931"
  },
  {
    "Word": "talk",
    "FREQcount": "43605"
  },
  {
    "Word": "nothing",
    "FREQcount": "43534"
  },
  {
    "Word": "into",
    "FREQcount": "43074"
  },
  {
    "Word": "first",
    "FREQcount": "42869"
  },
  {
    "Word": "find",
    "FREQcount": "42379"
  },
  {
    "Word": "wait",
    "FREQcount": "42343"
  },
  {
    "Word": "put",
    "FREQcount": "42251"
  },
  {
    "Word": "great",
    "FREQcount": "41864"
  },
  {
    "Word": "thought",
    "FREQcount": "41232"
  },
  {
    "Word": "day",
    "FREQcount": "40893"
  },
  {
    "Word": "work",
    "FREQcount": "40699"
  },
  {
    "Word": "life",
    "FREQcount": "40629"
  },
  {
    "Word": "before",
    "FREQcount": "40501"
  },
  {
    "Word": "better",
    "FREQcount": "40494"
  },
  {
    "Word": "again",
    "FREQcount": "40428"
  },
  {
    "Word": "still",
    "FREQcount": "40225"
  },
  {
    "Word": "home",
    "FREQcount": "39491"
  },
  {
    "Word": "guy",
    "FREQcount": "38893"
  },
  {
    "Word": "won",
    "FREQcount": "38729"
  },
  {
    "Word": "those",
    "FREQcount": "38404"
  },
  {
    "Word": "than",
    "FREQcount": "37679"
  },
  {
    "Word": "around",
    "FREQcount": "37573"
  },
  {
    "Word": "other",
    "FREQcount": "37505"
  },
  {
    "Word": "away",
    "FREQcount": "37276"
  },
  {
    "Word": "new",
    "FREQcount": "36913"
  },
  {
    "Word": "last",
    "FREQcount": "36878"
  },
  {
    "Word": "uh",
    "FREQcount": "36579"
  },
  {
    "Word": "ever",
    "FREQcount": "36170"
  },
  {
    "Word": "stop",
    "FREQcount": "36071"
  },
  {
    "Word": "keep",
    "FREQcount": "35846"
  },
  {
    "Word": "told",
    "FREQcount": "35679"
  },
  {
    "Word": "must",
    "FREQcount": "35661"
  },
  {
    "Word": "things",
    "FREQcount": "35337"
  },
  {
    "Word": "big",
    "FREQcount": "34824"
  },
  {
    "Word": "after",
    "FREQcount": "34812"
  },
  {
    "Word": "long",
    "FREQcount": "34433"
  },
  {
    "Word": "does",
    "FREQcount": "34002"
  },
  {
    "Word": "always",
    "FREQcount": "33418"
  },
  {
    "Word": "their",
    "FREQcount": "33413"
  },
  {
    "Word": "everything",
    "FREQcount": "33399"
  },
  {
    "Word": "nice",
    "FREQcount": "33125"
  },
  {
    "Word": "name",
    "FREQcount": "32735"
  },
  {
    "Word": "money",
    "FREQcount": "32679"
  },
  {
    "Word": "doesn",
    "FREQcount": "32435"
  },
  {
    "Word": "guys",
    "FREQcount": "32198"
  },
  {
    "Word": "feel",
    "FREQcount": "31989"
  },
  {
    "Word": "believe",
    "FREQcount": "31882"
  },
  {
    "Word": "thanks",
    "FREQcount": "31789"
  },
  {
    "Word": "old",
    "FREQcount": "31056"
  },
  {
    "Word": "place",
    "FREQcount": "30736"
  },
  {
    "Word": "fine",
    "FREQcount": "30502"
  },
  {
    "Word": "kind",
    "FREQcount": "30125"
  },
  {
    "Word": "isn",
    "FREQcount": "29886"
  },
  {
    "Word": "hello",
    "FREQcount": "29857"
  },
  {
    "Word": "lot",
    "FREQcount": "29066"
  },
  {
    "Word": "years",
    "FREQcount": "29003"
  },
  {
    "Word": "made",
    "FREQcount": "28626"
  },
  {
    "Word": "leave",
    "FREQcount": "28596"
  },
  {
    "Word": "hi",
    "FREQcount": "28464"
  },
  {
    "Word": "girl",
    "FREQcount": "28413"
  },
  {
    "Word": "hear",
    "FREQcount": "28323"
  },
  {
    "Word": "father",
    "FREQcount": "28279"
  },
  {
    "Word": "through",
    "FREQcount": "28026"
  },
  {
    "Word": "every",
    "FREQcount": "28007"
  },
  {
    "Word": "bad",
    "FREQcount": "27804"
  },
  {
    "Word": "listen",
    "FREQcount": "27784"
  },
  {
    "Word": "remember",
    "FREQcount": "27666"
  },
  {
    "Word": "three",
    "FREQcount": "27654"
  },
  {
    "Word": "boy",
    "FREQcount": "27021"
  },
  {
    "Word": "coming",
    "FREQcount": "26878"
  },
  {
    "Word": "wrong",
    "FREQcount": "26678"
  },
  {
    "Word": "might",
    "FREQcount": "26334"
  },
  {
    "Word": "stay",
    "FREQcount": "26298"
  },
  {
    "Word": "house",
    "FREQcount": "26214"
  },
  {
    "Word": "may",
    "FREQcount": "26080"
  },
  {
    "Word": "baby",
    "FREQcount": "25978"
  },
  {
    "Word": "another",
    "FREQcount": "25970"
  },
  {
    "Word": "ok",
    "FREQcount": "25928"
  },
  {
    "Word": "dad",
    "FREQcount": "25870"
  },
  {
    "Word": "gotta",
    "FREQcount": "25852"
  },
  {
    "Word": "wanna",
    "FREQcount": "25796"
  },
  {
    "Word": "wanted",
    "FREQcount": "25616"
  },
  {
    "Word": "enough",
    "FREQcount": "25568"
  },
  {
    "Word": "talking",
    "FREQcount": "25385"
  },
  {
    "Word": "happened",
    "FREQcount": "24994"
  },
  {
    "Word": "show",
    "FREQcount": "24906"
  },
  {
    "Word": "course",
    "FREQcount": "24848"
  },
  {
    "Word": "being",
    "FREQcount": "24781"
  },
  {
    "Word": "care",
    "FREQcount": "24748"
  },
  {
    "Word": "done",
    "FREQcount": "24737"
  },
  {
    "Word": "getting",
    "FREQcount": "24719"
  },
  {
    "Word": "mind",
    "FREQcount": "24715"
  },
  {
    "Word": "left",
    "FREQcount": "24707"
  },
  {
    "Word": "ask",
    "FREQcount": "24640"
  },
  {
    "Word": "car",
    "FREQcount": "24636"
  },
  {
    "Word": "understand",
    "FREQcount": "24605"
  },
  {
    "Word": "mother",
    "FREQcount": "24476"
  },
  {
    "Word": "which",
    "FREQcount": "24339"
  },
  {
    "Word": "try",
    "FREQcount": "24314"
  },
  {
    "Word": "shit",
    "FREQcount": "24207"
  },
  {
    "Word": "hell",
    "FREQcount": "24012"
  },
  {
    "Word": "miss",
    "FREQcount": "23850"
  },
  {
    "Word": "came",
    "FREQcount": "23650"
  },
  {
    "Word": "wouldn",
    "FREQcount": "23628"
  },
  {
    "Word": "own",
    "FREQcount": "23419"
  },
  {
    "Word": "world",
    "FREQcount": "23216"
  },
  {
    "Word": "guess",
    "FREQcount": "23153"
  },
  {
    "Word": "next",
    "FREQcount": "23090"
  },
  {
    "Word": "kill",
    "FREQcount": "23081"
  },
  {
    "Word": "else",
    "FREQcount": "22907"
  },
  {
    "Word": "dead",
    "FREQcount": "22898"
  },
  {
    "Word": "trying",
    "FREQcount": "22849"
  },
  {
    "Word": "someone",
    "FREQcount": "22752"
  },
  {
    "Word": "real",
    "FREQcount": "22583"
  },
  {
    "Word": "room",
    "FREQcount": "22415"
  },
  {
    "Word": "morning",
    "FREQcount": "22389"
  },
  {
    "Word": "huh",
    "FREQcount": "22350"
  },
  {
    "Word": "hold",
    "FREQcount": "22273"
  },
  {
    "Word": "ain",
    "FREQcount": "22248"
  },
  {
    "Word": "woman",
    "FREQcount": "22166"
  },
  {
    "Word": "yourself",
    "FREQcount": "22151"
  },
  {
    "Word": "today",
    "FREQcount": "22124"
  },
  {
    "Word": "looking",
    "FREQcount": "22066"
  },
  {
    "Word": "wasn",
    "FREQcount": "21984"
  },
  {
    "Word": "mom",
    "FREQcount": "21950"
  },
  {
    "Word": "friend",
    "FREQcount": "21384"
  },
  {
    "Word": "move",
    "FREQcount": "21325"
  },
  {
    "Word": "same",
    "FREQcount": "21276"
  },
  {
    "Word": "job",
    "FREQcount": "21063"
  },
  {
    "Word": "tonight",
    "FREQcount": "21047"
  },
  {
    "Word": "went",
    "FREQcount": "20987"
  },
  {
    "Word": "son",
    "FREQcount": "20949"
  },
  {
    "Word": "best",
    "FREQcount": "20623"
  },
  {
    "Word": "saw",
    "FREQcount": "20527"
  },
  {
    "Word": "found",
    "FREQcount": "20196"
  },
  {
    "Word": "pretty",
    "FREQcount": "20003"
  },
  {
    "Word": "ready",
    "FREQcount": "19778"
  },
  {
    "Word": "heard",
    "FREQcount": "19775"
  },
  {
    "Word": "whole",
    "FREQcount": "19660"
  },
  {
    "Word": "seen",
    "FREQcount": "19633"
  },
  {
    "Word": "together",
    "FREQcount": "19553"
  },
  {
    "Word": "fuck",
    "FREQcount": "19307"
  },
  {
    "Word": "minute",
    "FREQcount": "19252"
  },
  {
    "Word": "men",
    "FREQcount": "19011"
  },
  {
    "Word": "head",
    "FREQcount": "18947"
  },
  {
    "Word": "matter",
    "FREQcount": "18900"
  },
  {
    "Word": "haven",
    "FREQcount": "18844"
  },
  {
    "Word": "knew",
    "FREQcount": "18817"
  },
  {
    "Word": "excuse",
    "FREQcount": "18773"
  },
  {
    "Word": "many",
    "FREQcount": "18331"
  },
  {
    "Word": "idea",
    "FREQcount": "18311"
  },
  {
    "Word": "without",
    "FREQcount": "18087"
  },
  {
    "Word": "play",
    "FREQcount": "18081"
  },
  {
    "Word": "family",
    "FREQcount": "18067"
  },
  {
    "Word": "meet",
    "FREQcount": "17966"
  },
  {
    "Word": "most",
    "FREQcount": "17889"
  },
  {
    "Word": "run",
    "FREQcount": "17878"
  },
  {
    "Word": "while",
    "FREQcount": "17821"
  },
  {
    "Word": "wife",
    "FREQcount": "17795"
  },
  {
    "Word": "once",
    "FREQcount": "17589"
  },
  {
    "Word": "live",
    "FREQcount": "17574"
  },
  {
    "Word": "somebody",
    "FREQcount": "17571"
  },
  {
    "Word": "everybody",
    "FREQcount": "17555"
  },
  {
    "Word": "used",
    "FREQcount": "17551"
  },
  {
    "Word": "use",
    "FREQcount": "17536"
  },
  {
    "Word": "myself",
    "FREQcount": "17470"
  },
  {
    "Word": "took",
    "FREQcount": "17454"
  },
  {
    "Word": "yet",
    "FREQcount": "17428"
  },
  {
    "Word": "start",
    "FREQcount": "17345"
  },
  {
    "Word": "called",
    "FREQcount": "17341"
  },
  {
    "Word": "couldn",
    "FREQcount": "17336"
  },
  {
    "Word": "kid",
    "FREQcount": "17299"
  },
  {
    "Word": "tomorrow",
    "FREQcount": "17134"
  },
  {
    "Word": "happy",
    "FREQcount": "16993"
  },
  {
    "Word": "school",
    "FREQcount": "16989"
  },
  {
    "Word": "problem",
    "FREQcount": "16833"
  },
  {
    "Word": "watch",
    "FREQcount": "16831"
  },
  {
    "Word": "bring",
    "FREQcount": "16685"
  },
  {
    "Word": "fucking",
    "FREQcount": "16603"
  },
  {
    "Word": "actually",
    "FREQcount": "16439"
  },
  {
    "Word": "business",
    "FREQcount": "16371"
  },
  {
    "Word": "says",
    "FREQcount": "16356"
  },
  {
    "Word": "hope",
    "FREQcount": "16352"
  },
  {
    "Word": "open",
    "FREQcount": "16341"
  },
  {
    "Word": "already",
    "FREQcount": "16246"
  },
  {
    "Word": "since",
    "FREQcount": "16064"
  },
  {
    "Word": "looks",
    "FREQcount": "15886"
  },
  {
    "Word": "sit",
    "FREQcount": "15879"
  },
  {
    "Word": "mrs",
    "FREQcount": "15858"
  },
  {
    "Word": "cause",
    "FREQcount": "15812"
  },
  {
    "Word": "alone",
    "FREQcount": "15735"
  },
  {
    "Word": "hard",
    "FREQcount": "15700"
  },
  {
    "Word": "wants",
    "FREQcount": "15655"
  },
  {
    "Word": "stuff",
    "FREQcount": "15653"
  },
  {
    "Word": "turn",
    "FREQcount": "15630"
  },
  {
    "Word": "days",
    "FREQcount": "15592"
  },
  {
    "Word": "friends",
    "FREQcount": "15578"
  },
  {
    "Word": "until",
    "FREQcount": "15426"
  },
  {
    "Word": "few",
    "FREQcount": "15393"
  },
  {
    "Word": "kids",
    "FREQcount": "15356"
  },
  {
    "Word": "honey",
    "FREQcount": "15325"
  },
  {
    "Word": "dr",
    "FREQcount": "15194"
  },
  {
    "Word": "gone",
    "FREQcount": "15135"
  },
  {
    "Word": "both",
    "FREQcount": "15062"
  },
  {
    "Word": "door",
    "FREQcount": "14895"
  },
  {
    "Word": "later",
    "FREQcount": "14889"
  },
  {
    "Word": "saying",
    "FREQcount": "14874"
  },
  {
    "Word": "such",
    "FREQcount": "14852"
  },
  {
    "Word": "killed",
    "FREQcount": "14792"
  },
  {
    "Word": "having",
    "FREQcount": "14752"
  },
  {
    "Word": "face",
    "FREQcount": "14747"
  },
  {
    "Word": "worry",
    "FREQcount": "14638"
  },
  {
    "Word": "ago",
    "FREQcount": "14592"
  },
  {
    "Word": "five",
    "FREQcount": "14558"
  },
  {
    "Word": "second",
    "FREQcount": "14513"
  },
  {
    "Word": "brother",
    "FREQcount": "14481"
  },
  {
    "Word": "damn",
    "FREQcount": "14460"
  },
  {
    "Word": "case",
    "FREQcount": "14403"
  },
  {
    "Word": "thinking",
    "FREQcount": "14353"
  },
  {
    "Word": "probably",
    "FREQcount": "14323"
  },
  {
    "Word": "beautiful",
    "FREQcount": "14266"
  },
  {
    "Word": "hand",
    "FREQcount": "14262"
  },
  {
    "Word": "check",
    "FREQcount": "14228"
  },
  {
    "Word": "year",
    "FREQcount": "14174"
  },
  {
    "Word": "forget",
    "FREQcount": "14130"
  },
  {
    "Word": "hit",
    "FREQcount": "14025"
  },
  {
    "Word": "lost",
    "FREQcount": "13974"
  },
  {
    "Word": "minutes",
    "FREQcount": "13924"
  },
  {
    "Word": "crazy",
    "FREQcount": "13886"
  },
  {
    "Word": "late",
    "FREQcount": "13756"
  },
  {
    "Word": "phone",
    "FREQcount": "13756"
  },
  {
    "Word": "nobody",
    "FREQcount": "13599"
  },
  {
    "Word": "end",
    "FREQcount": "13559"
  },
  {
    "Word": "easy",
    "FREQcount": "13551"
  },
  {
    "Word": "doctor",
    "FREQcount": "13461"
  },
  {
    "Word": "shut",
    "FREQcount": "13455"
  },
  {
    "Word": "under",
    "FREQcount": "13358"
  },
  {
    "Word": "part",
    "FREQcount": "13337"
  },
  {
    "Word": "deal",
    "FREQcount": "13330"
  },
  {
    "Word": "die",
    "FREQcount": "13318"
  },
  {
    "Word": "soon",
    "FREQcount": "13140"
  },
  {
    "Word": "four",
    "FREQcount": "13045"
  },
  {
    "Word": "anyone",
    "FREQcount": "13018"
  },
  {
    "Word": "pay",
    "FREQcount": "12985"
  },
  {
    "Word": "happen",
    "FREQcount": "12968"
  },
  {
    "Word": "true",
    "FREQcount": "12921"
  },
  {
    "Word": "each",
    "FREQcount": "12916"
  },
  {
    "Word": "supposed",
    "FREQcount": "12865"
  },
  {
    "Word": "em",
    "FREQcount": "12849"
  },
  {
    "Word": "eat",
    "FREQcount": "12846"
  },
  {
    "Word": "jack",
    "FREQcount": "12831"
  },
  {
    "Word": "mine",
    "FREQcount": "12800"
  },
  {
    "Word": "working",
    "FREQcount": "12775"
  },
  {
    "Word": "town",
    "FREQcount": "12644"
  },
  {
    "Word": "afraid",
    "FREQcount": "12631"
  },
  {
    "Word": "drink",
    "FREQcount": "12617"
  },
  {
    "Word": "exactly",
    "FREQcount": "12607"
  },
  {
    "Word": "whatever",
    "FREQcount": "12584"
  },
  {
    "Word": "hurt",
    "FREQcount": "12564"
  },
  {
    "Word": "knows",
    "FREQcount": "12492"
  },
  {
    "Word": "heart",
    "FREQcount": "12453"
  },
  {
    "Word": "gave",
    "FREQcount": "12428"
  },
  {
    "Word": "young",
    "FREQcount": "12402"
  },
  {
    "Word": "everyone",
    "FREQcount": "12324"
  },
  {
    "Word": "chance",
    "FREQcount": "12303"
  },
  {
    "Word": "read",
    "FREQcount": "12302"
  },
  {
    "Word": "makes",
    "FREQcount": "12296"
  },
  {
    "Word": "number",
    "FREQcount": "12288"
  },
  {
    "Word": "taking",
    "FREQcount": "12263"
  },
  {
    "Word": "change",
    "FREQcount": "12258"
  },
  {
    "Word": "anyway",
    "FREQcount": "12164"
  },
  {
    "Word": "week",
    "FREQcount": "12164"
  },
  {
    "Word": "married",
    "FREQcount": "12163"
  },
  {
    "Word": "hands",
    "FREQcount": "12063"
  },
  {
    "Word": "point",
    "FREQcount": "12063"
  },
  {
    "Word": "police",
    "FREQcount": "12044"
  },
  {
    "Word": "word",
    "FREQcount": "12013"
  },
  {
    "Word": "fun",
    "FREQcount": "12010"
  },
  {
    "Word": "wish",
    "FREQcount": "11991"
  },
  {
    "Word": "bit",
    "FREQcount": "11987"
  },
  {
    "Word": "aren",
    "FREQcount": "11946"
  },
  {
    "Word": "game",
    "FREQcount": "11926"
  },
  {
    "Word": "party",
    "FREQcount": "11890"
  },
  {
    "Word": "set",
    "FREQcount": "11805"
  },
  {
    "Word": "cut",
    "FREQcount": "11718"
  },
  {
    "Word": "comes",
    "FREQcount": "11656"
  },
  {
    "Word": "sleep",
    "FREQcount": "11625"
  },
  {
    "Word": "shot",
    "FREQcount": "11599"
  },
  {
    "Word": "anybody",
    "FREQcount": "11573"
  },
  {
    "Word": "ass",
    "FREQcount": "11545"
  },
  {
    "Word": "stand",
    "FREQcount": "11536"
  },
  {
    "Word": "water",
    "FREQcount": "11478"
  },
  {
    "Word": "boys",
    "FREQcount": "11432"
  },
  {
    "Word": "trouble",
    "FREQcount": "11401"
  },
  {
    "Word": "dear",
    "FREQcount": "11395"
  },
  {
    "Word": "couple",
    "FREQcount": "11394"
  },
  {
    "Word": "gets",
    "FREQcount": "11364"
  },
  {
    "Word": "making",
    "FREQcount": "11349"
  },
  {
    "Word": "eyes",
    "FREQcount": "11299"
  },
  {
    "Word": "break",
    "FREQcount": "11275"
  },
  {
    "Word": "story",
    "FREQcount": "11260"
  },
  {
    "Word": "far",
    "FREQcount": "11259"
  },
  {
    "Word": "times",
    "FREQcount": "11221"
  },
  {
    "Word": "um",
    "FREQcount": "11197"
  },
  {
    "Word": "close",
    "FREQcount": "11191"
  },
  {
    "Word": "means",
    "FREQcount": "11136"
  },
  {
    "Word": "funny",
    "FREQcount": "11127"
  },
  {
    "Word": "goes",
    "FREQcount": "11081"
  },
  {
    "Word": "lady",
    "FREQcount": "11071"
  },
  {
    "Word": "death",
    "FREQcount": "11051"
  },
  {
    "Word": "asked",
    "FREQcount": "11029"
  },
  {
    "Word": "walk",
    "FREQcount": "11009"
  },
  {
    "Word": "fire",
    "FREQcount": "10990"
  },
  {
    "Word": "hours",
    "FREQcount": "10959"
  },
  {
    "Word": "hate",
    "FREQcount": "10944"
  },
  {
    "Word": "gun",
    "FREQcount": "10873"
  },
  {
    "Word": "rest",
    "FREQcount": "10861"
  },
  {
    "Word": "person",
    "FREQcount": "10857"
  },
  {
    "Word": "inside",
    "FREQcount": "10775"
  },
  {
    "Word": "waiting",
    "FREQcount": "10767"
  },
  {
    "Word": "different",
    "FREQcount": "10686"
  },
  {
    "Word": "girls",
    "FREQcount": "10626"
  },
  {
    "Word": "captain",
    "FREQcount": "10622"
  },
  {
    "Word": "least",
    "FREQcount": "10596"
  },
  {
    "Word": "important",
    "FREQcount": "10587"
  },
  {
    "Word": "ah",
    "FREQcount": "10535"
  },
  {
    "Word": "also",
    "FREQcount": "10528"
  },
  {
    "Word": "line",
    "FREQcount": "10515"
  },
  {
    "Word": "yours",
    "FREQcount": "10441"
  },
  {
    "Word": "office",
    "FREQcount": "10399"
  },
  {
    "Word": "dinner",
    "FREQcount": "10336"
  },
  {
    "Word": "quite",
    "FREQcount": "10332"
  },
  {
    "Word": "against",
    "FREQcount": "10288"
  },
  {
    "Word": "fight",
    "FREQcount": "10255"
  },
  {
    "Word": "side",
    "FREQcount": "10247"
  },
  {
    "Word": "six",
    "FREQcount": "10176"
  },
  {
    "Word": "half",
    "FREQcount": "10156"
  },
  {
    "Word": "pick",
    "FREQcount": "10118"
  },
  {
    "Word": "question",
    "FREQcount": "10116"
  },
  {
    "Word": "ahead",
    "FREQcount": "10115"
  },
  {
    "Word": "michael",
    "FREQcount": "10115"
  },
  {
    "Word": "cool",
    "FREQcount": "9990"
  },
  {
    "Word": "women",
    "FREQcount": "9978"
  },
  {
    "Word": "body",
    "FREQcount": "9972"
  },
  {
    "Word": "high",
    "FREQcount": "9945"
  },
  {
    "Word": "husband",
    "FREQcount": "9935"
  },
  {
    "Word": "john",
    "FREQcount": "9877"
  },
  {
    "Word": "reason",
    "FREQcount": "9858"
  },
  {
    "Word": "almost",
    "FREQcount": "9857"
  },
  {
    "Word": "dog",
    "FREQcount": "9835"
  },
  {
    "Word": "buy",
    "FREQcount": "9814"
  },
  {
    "Word": "truth",
    "FREQcount": "9801"
  },
  {
    "Word": "met",
    "FREQcount": "9758"
  },
  {
    "Word": "telling",
    "FREQcount": "9730"
  },
  {
    "Word": "hot",
    "FREQcount": "9682"
  },
  {
    "Word": "o",
    "FREQcount": "9598"
  },
  {
    "Word": "anymore",
    "FREQcount": "9597"
  },
  {
    "Word": "behind",
    "FREQcount": "9581"
  },
  {
    "Word": "started",
    "FREQcount": "9566"
  },
  {
    "Word": "speak",
    "FREQcount": "9546"
  },
  {
    "Word": "bed",
    "FREQcount": "9543"
  },
  {
    "Word": "moment",
    "FREQcount": "9539"
  },
  {
    "Word": "tried",
    "FREQcount": "9529"
  },
  {
    "Word": "blood",
    "FREQcount": "9492"
  },
  {
    "Word": "ma",
    "FREQcount": "9476"
  },
  {
    "Word": "shall",
    "FREQcount": "9441"
  },
  {
    "Word": "daddy",
    "FREQcount": "9439"
  },
  {
    "Word": "stupid",
    "FREQcount": "9405"
  },
  {
    "Word": "along",
    "FREQcount": "9330"
  },
  {
    "Word": "either",
    "FREQcount": "9308"
  },
  {
    "Word": "though",
    "FREQcount": "9279"
  },
  {
    "Word": "front",
    "FREQcount": "9259"
  },
  {
    "Word": "sister",
    "FREQcount": "9207"
  },
  {
    "Word": "bye",
    "FREQcount": "9184"
  },
  {
    "Word": "send",
    "FREQcount": "9169"
  },
  {
    "Word": "welcome",
    "FREQcount": "9140"
  },
  {
    "Word": "sometimes",
    "FREQcount": "9129"
  },
  {
    "Word": "trust",
    "FREQcount": "9087"
  },
  {
    "Word": "free",
    "FREQcount": "9054"
  },
  {
    "Word": "book",
    "FREQcount": "9026"
  },
  {
    "Word": "answer",
    "FREQcount": "8986"
  },
  {
    "Word": "between",
    "FREQcount": "8932"
  },
  {
    "Word": "children",
    "FREQcount": "8930"
  },
  {
    "Word": "war",
    "FREQcount": "8912"
  },
  {
    "Word": "hurry",
    "FREQcount": "8856"
  },
  {
    "Word": "fact",
    "FREQcount": "8801"
  },
  {
    "Word": "brought",
    "FREQcount": "8786"
  },
  {
    "Word": "bet",
    "FREQcount": "8763"
  },
  {
    "Word": "clear",
    "FREQcount": "8763"
  },
  {
    "Word": "its",
    "FREQcount": "8757"
  },
  {
    "Word": "white",
    "FREQcount": "8744"
  },
  {
    "Word": "glad",
    "FREQcount": "8740"
  },
  {
    "Word": "daughter",
    "FREQcount": "8739"
  },
  {
    "Word": "outside",
    "FREQcount": "8671"
  },
  {
    "Word": "city",
    "FREQcount": "8624"
  },
  {
    "Word": "bitch",
    "FREQcount": "8609"
  },
  {
    "Word": "feeling",
    "FREQcount": "8577"
  },
  {
    "Word": "black",
    "FREQcount": "8565"
  },
  {
    "Word": "seems",
    "FREQcount": "8545"
  },
  {
    "Word": "full",
    "FREQcount": "8512"
  },
  {
    "Word": "till",
    "FREQcount": "8503"
  },
  {
    "Word": "sick",
    "FREQcount": "8437"
  },
  {
    "Word": "light",
    "FREQcount": "8425"
  },
  {
    "Word": "shoot",
    "FREQcount": "8412"
  },
  {
    "Word": "news",
    "FREQcount": "8399"
  },
  {
    "Word": "lose",
    "FREQcount": "8382"
  },
  {
    "Word": "wonderful",
    "FREQcount": "8364"
  },
  {
    "Word": "months",
    "FREQcount": "8314"
  },
  {
    "Word": "save",
    "FREQcount": "8278"
  },
  {
    "Word": "hour",
    "FREQcount": "8277"
  },
  {
    "Word": "country",
    "FREQcount": "8254"
  },
  {
    "Word": "jesus",
    "FREQcount": "8220"
  },
  {
    "Word": "needs",
    "FREQcount": "8198"
  },
  {
    "Word": "wow",
    "FREQcount": "8160"
  },
  {
    "Word": "able",
    "FREQcount": "8155"
  },
  {
    "Word": "frank",
    "FREQcount": "8129"
  },
  {
    "Word": "perfect",
    "FREQcount": "8091"
  },
  {
    "Word": "shouldn",
    "FREQcount": "8083"
  },
  {
    "Word": "running",
    "FREQcount": "8054"
  },
  {
    "Word": "child",
    "FREQcount": "8040"
  },
  {
    "Word": "whoa",
    "FREQcount": "8023"
  },
  {
    "Word": "died",
    "FREQcount": "8018"
  },
  {
    "Word": "order",
    "FREQcount": "7985"
  },
  {
    "Word": "living",
    "FREQcount": "7983"
  },
  {
    "Word": "sounds",
    "FREQcount": "7970"
  },
  {
    "Word": "alive",
    "FREQcount": "7878"
  },
  {
    "Word": "food",
    "FREQcount": "7876"
  },
  {
    "Word": "gentlemen",
    "FREQcount": "7874"
  },
  {
    "Word": "luck",
    "FREQcount": "7840"
  },
  {
    "Word": "hair",
    "FREQcount": "7831"
  },
  {
    "Word": "drive",
    "FREQcount": "7810"
  },
  {
    "Word": "promise",
    "FREQcount": "7809"
  },
  {
    "Word": "sex",
    "FREQcount": "7761"
  },
  {
    "Word": "music",
    "FREQcount": "7734"
  },
  {
    "Word": "ya",
    "FREQcount": "7664"
  },
  {
    "Word": "power",
    "FREQcount": "7600"
  },
  {
    "Word": "sort",
    "FREQcount": "7584"
  },
  {
    "Word": "special",
    "FREQcount": "7577"
  },
  {
    "Word": "serious",
    "FREQcount": "7566"
  },
  {
    "Word": "street",
    "FREQcount": "7557"
  },
  {
    "Word": "red",
    "FREQcount": "7551"
  },
  {
    "Word": "dance",
    "FREQcount": "7550"
  },
  {
    "Word": "hang",
    "FREQcount": "7535"
  },
  {
    "Word": "touch",
    "FREQcount": "7534"
  },
  {
    "Word": "team",
    "FREQcount": "7528"
  },
  {
    "Word": "playing",
    "FREQcount": "7515"
  },
  {
    "Word": "company",
    "FREQcount": "7507"
  },
  {
    "Word": "george",
    "FREQcount": "7474"
  },
  {
    "Word": "pull",
    "FREQcount": "7469"
  },
  {
    "Word": "plan",
    "FREQcount": "7432"
  },
  {
    "Word": "sweet",
    "FREQcount": "7405"
  },
  {
    "Word": "ten",
    "FREQcount": "7395"
  },
  {
    "Word": "coffee",
    "FREQcount": "7371"
  },
  {
    "Word": "lucky",
    "FREQcount": "7316"
  },
  {
    "Word": "sound",
    "FREQcount": "7313"
  },
  {
    "Word": "safe",
    "FREQcount": "7303"
  },
  {
    "Word": "date",
    "FREQcount": "7218"
  },
  {
    "Word": "leaving",
    "FREQcount": "7211"
  },
  {
    "Word": "parents",
    "FREQcount": "7177"
  },
  {
    "Word": "president",
    "FREQcount": "7174"
  },
  {
    "Word": "himself",
    "FREQcount": "7168"
  },
  {
    "Word": "seem",
    "FREQcount": "7131"
  },
  {
    "Word": "lives",
    "FREQcount": "7124"
  },
  {
    "Word": "air",
    "FREQcount": "7090"
  },
  {
    "Word": "taken",
    "FREQcount": "7071"
  },
  {
    "Word": "york",
    "FREQcount": "7069"
  },
  {
    "Word": "picture",
    "FREQcount": "7061"
  },
  {
    "Word": "ladies",
    "FREQcount": "7054"
  },
  {
    "Word": "lord",
    "FREQcount": "7046"
  },
  {
    "Word": "sent",
    "FREQcount": "7038"
  },
  {
    "Word": "fast",
    "FREQcount": "7010"
  },
  {
    "Word": "happens",
    "FREQcount": "6996"
  },
  {
    "Word": "perhaps",
    "FREQcount": "6939"
  },
  {
    "Word": "catch",
    "FREQcount": "6911"
  },
  {
    "Word": "ride",
    "FREQcount": "6904"
  },
  {
    "Word": "win",
    "FREQcount": "6867"
  },
  {
    "Word": "kidding",
    "FREQcount": "6822"
  },
  {
    "Word": "top",
    "FREQcount": "6805"
  },
  {
    "Word": "scared",
    "FREQcount": "6803"
  },
  {
    "Word": "dream",
    "FREQcount": "6798"
  },
  {
    "Word": "sign",
    "FREQcount": "6797"
  },
  {
    "Word": "meeting",
    "FREQcount": "6752"
  },
  {
    "Word": "sense",
    "FREQcount": "6722"
  },
  {
    "Word": "beat",
    "FREQcount": "6716"
  },
  {
    "Word": "control",
    "FREQcount": "6662"
  },
  {
    "Word": "drop",
    "FREQcount": "6661"
  },
  {
    "Word": "cold",
    "FREQcount": "6638"
  },
  {
    "Word": "weeks",
    "FREQcount": "6637"
  },
  {
    "Word": "darling",
    "FREQcount": "6613"
  },
  {
    "Word": "figure",
    "FREQcount": "6598"
  },
  {
    "Word": "king",
    "FREQcount": "6592"
  },
  {
    "Word": "poor",
    "FREQcount": "6583"
  },
  {
    "Word": "throw",
    "FREQcount": "6570"
  },
  {
    "Word": "asking",
    "FREQcount": "6546"
  },
  {
    "Word": "joe",
    "FREQcount": "6532"
  },
  {
    "Word": "write",
    "FREQcount": "6467"
  },
  {
    "Word": "cannot",
    "FREQcount": "6465"
  },
  {
    "Word": "suppose",
    "FREQcount": "6416"
  },
  {
    "Word": "small",
    "FREQcount": "6373"
  },
  {
    "Word": "human",
    "FREQcount": "6363"
  },
  {
    "Word": "piece",
    "FREQcount": "6349"
  },
  {
    "Word": "boss",
    "FREQcount": "6339"
  },
  {
    "Word": "hospital",
    "FREQcount": "6334"
  },
  {
    "Word": "uncle",
    "FREQcount": "6327"
  },
  {
    "Word": "past",
    "FREQcount": "6312"
  },
  {
    "Word": "calling",
    "FREQcount": "6311"
  },
  {
    "Word": "known",
    "FREQcount": "6300"
  },
  {
    "Word": "follow",
    "FREQcount": "6283"
  },
  {
    "Word": "sam",
    "FREQcount": "6281"
  },
  {
    "Word": "movie",
    "FREQcount": "6271"
  },
  {
    "Word": "ha",
    "FREQcount": "6260"
  },
  {
    "Word": "christmas",
    "FREQcount": "6244"
  },
  {
    "Word": "straight",
    "FREQcount": "6244"
  },
  {
    "Word": "weren",
    "FREQcount": "6237"
  },
  {
    "Word": "words",
    "FREQcount": "6223"
  },
  {
    "Word": "clean",
    "FREQcount": "6183"
  },
  {
    "Word": "kiss",
    "FREQcount": "6179"
  },
  {
    "Word": "looked",
    "FREQcount": "6166"
  },
  {
    "Word": "feet",
    "FREQcount": "6157"
  },
  {
    "Word": "evening",
    "FREQcount": "6155"
  },
  {
    "Word": "million",
    "FREQcount": "6145"
  },
  {
    "Word": "lie",
    "FREQcount": "6133"
  },
  {
    "Word": "felt",
    "FREQcount": "6111"
  },
  {
    "Word": "moving",
    "FREQcount": "6104"
  },
  {
    "Word": "certainly",
    "FREQcount": "6067"
  },
  {
    "Word": "step",
    "FREQcount": "6052"
  },
  {
    "Word": "learn",
    "FREQcount": "6047"
  },
  {
    "Word": "fall",
    "FREQcount": "6044"
  },
  {
    "Word": "bill",
    "FREQcount": "6041"
  },
  {
    "Word": "questions",
    "FREQcount": "6016"
  },
  {
    "Word": "finally",
    "FREQcount": "5989"
  },
  {
    "Word": "takes",
    "FREQcount": "5986"
  },
  {
    "Word": "class",
    "FREQcount": "5985"
  },
  {
    "Word": "quiet",
    "FREQcount": "5978"
  },
  {
    "Word": "wonder",
    "FREQcount": "5966"
  },
  {
    "Word": "goodbye",
    "FREQcount": "5942"
  },
  {
    "Word": "law",
    "FREQcount": "5932"
  },
  {
    "Word": "become",
    "FREQcount": "5894"
  },
  {
    "Word": "general",
    "FREQcount": "5885"
  },
  {
    "Word": "worked",
    "FREQcount": "5877"
  },
  {
    "Word": "rather",
    "FREQcount": "5825"
  },
  {
    "Word": "possible",
    "FREQcount": "5816"
  },
  {
    "Word": "goddamn",
    "FREQcount": "5815"
  },
  {
    "Word": "unless",
    "FREQcount": "5798"
  },
  {
    "Word": "mad",
    "FREQcount": "5784"
  },
  {
    "Word": "absolutely",
    "FREQcount": "5769"
  },
  {
    "Word": "tired",
    "FREQcount": "5745"
  },
  {
    "Word": "murder",
    "FREQcount": "5717"
  },
  {
    "Word": "road",
    "FREQcount": "5709"
  },
  {
    "Word": "mike",
    "FREQcount": "5707"
  },
  {
    "Word": "eye",
    "FREQcount": "5701"
  },
  {
    "Word": "except",
    "FREQcount": "5696"
  },
  {
    "Word": "somewhere",
    "FREQcount": "5688"
  },
  {
    "Word": "explain",
    "FREQcount": "5670"
  },
  {
    "Word": "charlie",
    "FREQcount": "5668"
  },
  {
    "Word": "less",
    "FREQcount": "5666"
  },
  {
    "Word": "none",
    "FREQcount": "5641"
  },
  {
    "Word": "loved",
    "FREQcount": "5627"
  },
  {
    "Word": "giving",
    "FREQcount": "5613"
  },
  {
    "Word": "seeing",
    "FREQcount": "5591"
  },
  {
    "Word": "tom",
    "FREQcount": "5588"
  },
  {
    "Word": "secret",
    "FREQcount": "5585"
  },
  {
    "Word": "wear",
    "FREQcount": "5576"
  },
  {
    "Word": "worth",
    "FREQcount": "5569"
  },
  {
    "Word": "act",
    "FREQcount": "5565"
  },
  {
    "Word": "careful",
    "FREQcount": "5550"
  },
  {
    "Word": "quick",
    "FREQcount": "5542"
  },
  {
    "Word": "handle",
    "FREQcount": "5529"
  },
  {
    "Word": "pass",
    "FREQcount": "5514"
  },
  {
    "Word": "early",
    "FREQcount": "5510"
  },
  {
    "Word": "report",
    "FREQcount": "5508"
  },
  {
    "Word": "state",
    "FREQcount": "5500"
  },
  {
    "Word": "busy",
    "FREQcount": "5433"
  },
  {
    "Word": "turned",
    "FREQcount": "5388"
  },
  {
    "Word": "table",
    "FREQcount": "5387"
  },
  {
    "Word": "wake",
    "FREQcount": "5366"
  },
  {
    "Word": "works",
    "FREQcount": "5357"
  },
  {
    "Word": "broke",
    "FREQcount": "5355"
  },
  {
    "Word": "ball",
    "FREQcount": "5353"
  },
  {
    "Word": "major",
    "FREQcount": "5343"
  },
  {
    "Word": "seven",
    "FREQcount": "5327"
  },
  {
    "Word": "mouth",
    "FREQcount": "5325"
  },
  {
    "Word": "marry",
    "FREQcount": "5322"
  },
  {
    "Word": "meant",
    "FREQcount": "5316"
  },
  {
    "Word": "fault",
    "FREQcount": "5310"
  },
  {
    "Word": "lunch",
    "FREQcount": "5310"
  },
  {
    "Word": "al",
    "FREQcount": "5306"
  },
  {
    "Word": "lieutenant",
    "FREQcount": "5306"
  },
  {
    "Word": "expect",
    "FREQcount": "5299"
  },
  {
    "Word": "hmm",
    "FREQcount": "5291"
  },
  {
    "Word": "mama",
    "FREQcount": "5289"
  },
  {
    "Word": "future",
    "FREQcount": "5278"
  },
  {
    "Word": "paper",
    "FREQcount": "5271"
  },
  {
    "Word": "officer",
    "FREQcount": "5265"
  },
  {
    "Word": "hotel",
    "FREQcount": "5264"
  },
  {
    "Word": "buddy",
    "FREQcount": "5247"
  },
  {
    "Word": "agent",
    "FREQcount": "5235"
  },
  {
    "Word": "thinks",
    "FREQcount": "5235"
  },
  {
    "Word": "talked",
    "FREQcount": "5226"
  },
  {
    "Word": "blue",
    "FREQcount": "5222"
  },
  {
    "Word": "american",
    "FREQcount": "5213"
  },
  {
    "Word": "mistake",
    "FREQcount": "5200"
  },
  {
    "Word": "tv",
    "FREQcount": "5199"
  },
  {
    "Word": "david",
    "FREQcount": "5196"
  },
  {
    "Word": "ones",
    "FREQcount": "5177"
  },
  {
    "Word": "wedding",
    "FREQcount": "5173"
  },
  {
    "Word": "clothes",
    "FREQcount": "5158"
  },
  {
    "Word": "weird",
    "FREQcount": "5156"
  },
  {
    "Word": "changed",
    "FREQcount": "5148"
  },
  {
    "Word": "court",
    "FREQcount": "5137"
  },
  {
    "Word": "floor",
    "FREQcount": "5132"
  },
  {
    "Word": "watching",
    "FREQcount": "5081"
  },
  {
    "Word": "building",
    "FREQcount": "5078"
  },
  {
    "Word": "earth",
    "FREQcount": "5074"
  },
  {
    "Word": "dude",
    "FREQcount": "5071"
  },
  {
    "Word": "others",
    "FREQcount": "5061"
  },
  {
    "Word": "longer",
    "FREQcount": "5046"
  },
  {
    "Word": "finish",
    "FREQcount": "5045"
  },
  {
    "Word": "forgot",
    "FREQcount": "5045"
  },
  {
    "Word": "ship",
    "FREQcount": "5043"
  },
  {
    "Word": "club",
    "FREQcount": "5038"
  },
  {
    "Word": "attention",
    "FREQcount": "5032"
  },
  {
    "Word": "eight",
    "FREQcount": "5010"
  },
  {
    "Word": "worse",
    "FREQcount": "5002"
  },
  {
    "Word": "pain",
    "FREQcount": "4995"
  },
  {
    "Word": "ben",
    "FREQcount": "4994"
  },
  {
    "Word": "th",
    "FREQcount": "4989"
  },
  {
    "Word": "sing",
    "FREQcount": "4977"
  },
  {
    "Word": "blow",
    "FREQcount": "4976"
  },
  {
    "Word": "choice",
    "FREQcount": "4975"
  },
  {
    "Word": "ls",
    "FREQcount": "4967"
  },
  {
    "Word": "ray",
    "FREQcount": "4966"
  },
  {
    "Word": "birthday",
    "FREQcount": "4958"
  },
  {
    "Word": "stick",
    "FREQcount": "4953"
  },
  {
    "Word": "relax",
    "FREQcount": "4936"
  },
  {
    "Word": "yesterday",
    "FREQcount": "4935"
  },
  {
    "Word": "honor",
    "FREQcount": "4912"
  },
  {
    "Word": "colonel",
    "FREQcount": "4909"
  },
  {
    "Word": "smart",
    "FREQcount": "4909"
  },
  {
    "Word": "boat",
    "FREQcount": "4885"
  },
  {
    "Word": "plane",
    "FREQcount": "4872"
  },
  {
    "Word": "month",
    "FREQcount": "4854"
  },
  {
    "Word": "lovely",
    "FREQcount": "4853"
  },
  {
    "Word": "given",
    "FREQcount": "4851"
  },
  {
    "Word": "train",
    "FREQcount": "4848"
  },
  {
    "Word": "l",
    "FREQcount": "4841"
  },
  {
    "Word": "fair",
    "FREQcount": "4832"
  },
  {
    "Word": "worried",
    "FREQcount": "4831"
  },
  {
    "Word": "ooh",
    "FREQcount": "4827"
  },
  {
    "Word": "needed",
    "FREQcount": "4818"
  },
  {
    "Word": "sitting",
    "FREQcount": "4814"
  },
  {
    "Word": "security",
    "FREQcount": "4810"
  },
  {
    "Word": "cover",
    "FREQcount": "4808"
  },
  {
    "Word": "across",
    "FREQcount": "4801"
  },
  {
    "Word": "paul",
    "FREQcount": "4801"
  },
  {
    "Word": "bag",
    "FREQcount": "4796"
  },
  {
    "Word": "terrible",
    "FREQcount": "4795"
  },
  {
    "Word": "caught",
    "FREQcount": "4791"
  },
  {
    "Word": "song",
    "FREQcount": "4778"
  },
  {
    "Word": "spend",
    "FREQcount": "4757"
  },
  {
    "Word": "horse",
    "FREQcount": "4737"
  },
  {
    "Word": "ring",
    "FREQcount": "4730"
  },
  {
    "Word": "sell",
    "FREQcount": "4705"
  },
  {
    "Word": "return",
    "FREQcount": "4676"
  },
  {
    "Word": "c",
    "FREQcount": "4675"
  },
  {
    "Word": "personal",
    "FREQcount": "4675"
  },
  {
    "Word": "message",
    "FREQcount": "4667"
  },
  {
    "Word": "system",
    "FREQcount": "4667"
  },
  {
    "Word": "afternoon",
    "FREQcount": "4666"
  },
  {
    "Word": "bob",
    "FREQcount": "4666"
  },
  {
    "Word": "hasn",
    "FREQcount": "4625"
  },
  {
    "Word": "happening",
    "FREQcount": "4618"
  },
  {
    "Word": "tough",
    "FREQcount": "4616"
  },
  {
    "Word": "christ",
    "FREQcount": "4597"
  },
  {
    "Word": "peter",
    "FREQcount": "4596"
  },
  {
    "Word": "quit",
    "FREQcount": "4595"
  },
  {
    "Word": "count",
    "FREQcount": "4588"
  },
  {
    "Word": "box",
    "FREQcount": "4577"
  },
  {
    "Word": "missed",
    "FREQcount": "4568"
  },
  {
    "Word": "present",
    "FREQcount": "4562"
  },
  {
    "Word": "charge",
    "FREQcount": "4559"
  },
  {
    "Word": "kept",
    "FREQcount": "4559"
  },
  {
    "Word": "information",
    "FREQcount": "4557"
  },
  {
    "Word": "fool",
    "FREQcount": "4556"
  },
  {
    "Word": "simple",
    "FREQcount": "4555"
  },
  {
    "Word": "middle",
    "FREQcount": "4549"
  },
  {
    "Word": "calm",
    "FREQcount": "4541"
  },
  {
    "Word": "surprise",
    "FREQcount": "4534"
  },
  {
    "Word": "forever",
    "FREQcount": "4529"
  },
  {
    "Word": "decided",
    "FREQcount": "4521"
  },
  {
    "Word": "dark",
    "FREQcount": "4519"
  },
  {
    "Word": "anywhere",
    "FREQcount": "4501"
  },
  {
    "Word": "miles",
    "FREQcount": "4500"
  },
  {
    "Word": "swear",
    "FREQcount": "4496"
  },
  {
    "Word": "land",
    "FREQcount": "4494"
  },
  {
    "Word": "mary",
    "FREQcount": "4492"
  },
  {
    "Word": "missing",
    "FREQcount": "4484"
  },
  {
    "Word": "cute",
    "FREQcount": "4475"
  },
  {
    "Word": "lying",
    "FREQcount": "4472"
  },
  {
    "Word": "master",
    "FREQcount": "4450"
  },
  {
    "Word": "dress",
    "FREQcount": "4447"
  },
  {
    "Word": "key",
    "FREQcount": "4430"
  },
  {
    "Word": "strong",
    "FREQcount": "4430"
  },
  {
    "Word": "fix",
    "FREQcount": "4426"
  },
  {
    "Word": "interesting",
    "FREQcount": "4421"
  },
  {
    "Word": "wearing",
    "FREQcount": "4410"
  },
  {
    "Word": "johnny",
    "FREQcount": "4408"
  },
  {
    "Word": "strange",
    "FREQcount": "4408"
  },
  {
    "Word": "rock",
    "FREQcount": "4394"
  },
  {
    "Word": "voice",
    "FREQcount": "4394"
  },
  {
    "Word": "cop",
    "FREQcount": "4393"
  },
  {
    "Word": "window",
    "FREQcount": "4386"
  },
  {
    "Word": "bar",
    "FREQcount": "4385"
  },
  {
    "Word": "totally",
    "FREQcount": "4377"
  },
  {
    "Word": "interested",
    "FREQcount": "4374"
  },
  {
    "Word": "appreciate",
    "FREQcount": "4373"
  },
  {
    "Word": "army",
    "FREQcount": "4370"
  },
  {
    "Word": "paid",
    "FREQcount": "4369"
  },
  {
    "Word": "short",
    "FREQcount": "4367"
  },
  {
    "Word": "record",
    "FREQcount": "4365"
  },
  {
    "Word": "bought",
    "FREQcount": "4362"
  },
  {
    "Word": "card",
    "FREQcount": "4357"
  },
  {
    "Word": "certain",
    "FREQcount": "4354"
  },
  {
    "Word": "y",
    "FREQcount": "4345"
  },
  {
    "Word": "college",
    "FREQcount": "4344"
  },
  {
    "Word": "evidence",
    "FREQcount": "4335"
  },
  {
    "Word": "fly",
    "FREQcount": "4335"
  },
  {
    "Word": "bank",
    "FREQcount": "4334"
  },
  {
    "Word": "besides",
    "FREQcount": "4328"
  },
  {
    "Word": "completely",
    "FREQcount": "4303"
  },
  {
    "Word": "ran",
    "FREQcount": "4296"
  },
  {
    "Word": "cops",
    "FREQcount": "4290"
  },
  {
    "Word": "b",
    "FREQcount": "4289"
  },
  {
    "Word": "test",
    "FREQcount": "4288"
  },
  {
    "Word": "history",
    "FREQcount": "4280"
  },
  {
    "Word": "finished",
    "FREQcount": "4269"
  },
  {
    "Word": "born",
    "FREQcount": "4268"
  },
  {
    "Word": "proud",
    "FREQcount": "4265"
  },
  {
    "Word": "fish",
    "FREQcount": "4258"
  },
  {
    "Word": "join",
    "FREQcount": "4255"
  },
  {
    "Word": "lead",
    "FREQcount": "4246"
  },
  {
    "Word": "smell",
    "FREQcount": "4240"
  },
  {
    "Word": "near",
    "FREQcount": "4238"
  },
  {
    "Word": "apartment",
    "FREQcount": "4235"
  },
  {
    "Word": "enjoy",
    "FREQcount": "4222"
  },
  {
    "Word": "letter",
    "FREQcount": "4213"
  },
  {
    "Word": "situation",
    "FREQcount": "4207"
  },
  {
    "Word": "trip",
    "FREQcount": "4202"
  },
  {
    "Word": "harry",
    "FREQcount": "4193"
  },
  {
    "Word": "mark",
    "FREQcount": "4183"
  },
  {
    "Word": "store",
    "FREQcount": "4178"
  },
  {
    "Word": "yo",
    "FREQcount": "4177"
  },
  {
    "Word": "amazing",
    "FREQcount": "4167"
  },
  {
    "Word": "star",
    "FREQcount": "4149"
  },
  {
    "Word": "danny",
    "FREQcount": "4148"
  },
  {
    "Word": "accident",
    "FREQcount": "4146"
  },
  {
    "Word": "il",
    "FREQcount": "4139"
  },
  {
    "Word": "imagine",
    "FREQcount": "4133"
  },
  {
    "Word": "doc",
    "FREQcount": "4122"
  },
  {
    "Word": "ought",
    "FREQcount": "4118"
  },
  {
    "Word": "pleasure",
    "FREQcount": "4118"
  },
  {
    "Word": "list",
    "FREQcount": "4110"
  },
  {
    "Word": "rich",
    "FREQcount": "4100"
  },
  {
    "Word": "calls",
    "FREQcount": "4097"
  },
  {
    "Word": "jimmy",
    "FREQcount": "4091"
  },
  {
    "Word": "service",
    "FREQcount": "4076"
  },
  {
    "Word": "entire",
    "FREQcount": "4070"
  },
  {
    "Word": "difference",
    "FREQcount": "4066"
  },
  {
    "Word": "judge",
    "FREQcount": "4063"
  },
  {
    "Word": "ice",
    "FREQcount": "4057"
  },
  {
    "Word": "lawyer",
    "FREQcount": "4055"
  },
  {
    "Word": "fat",
    "FREQcount": "4051"
  },
  {
    "Word": "alright",
    "FREQcount": "4044"
  },
  {
    "Word": "instead",
    "FREQcount": "4043"
  },
  {
    "Word": "age",
    "FREQcount": "4039"
  },
  {
    "Word": "station",
    "FREQcount": "4033"
  },
  {
    "Word": "realize",
    "FREQcount": "4032"
  },
  {
    "Word": "gold",
    "FREQcount": "4026"
  },
  {
    "Word": "j",
    "FREQcount": "4026"
  },
  {
    "Word": "seat",
    "FREQcount": "4018"
  },
  {
    "Word": "liked",
    "FREQcount": "4017"
  },
  {
    "Word": "hundred",
    "FREQcount": "4015"
  },
  {
    "Word": "summer",
    "FREQcount": "4012"
  },
  {
    "Word": "dollars",
    "FREQcount": "3998"
  },
  {
    "Word": "standing",
    "FREQcount": "3994"
  },
  {
    "Word": "angel",
    "FREQcount": "3992"
  },
  {
    "Word": "mess",
    "FREQcount": "3985"
  },
  {
    "Word": "america",
    "FREQcount": "3974"
  },
  {
    "Word": "chief",
    "FREQcount": "3973"
  },
  {
    "Word": "killing",
    "FREQcount": "3965"
  },
  {
    "Word": "radio",
    "FREQcount": "3936"
  },
  {
    "Word": "hungry",
    "FREQcount": "3931"
  },
  {
    "Word": "problems",
    "FREQcount": "3931"
  },
  {
    "Word": "marriage",
    "FREQcount": "3930"
  },
  {
    "Word": "brain",
    "FREQcount": "3928"
  },
  {
    "Word": "soul",
    "FREQcount": "3925"
  },
  {
    "Word": "forgive",
    "FREQcount": "3917"
  },
  {
    "Word": "drunk",
    "FREQcount": "3904"
  },
  {
    "Word": "henry",
    "FREQcount": "3904"
  },
  {
    "Word": "deep",
    "FREQcount": "3896"
  },
  {
    "Word": "figured",
    "FREQcount": "3893"
  },
  {
    "Word": "likes",
    "FREQcount": "3889"
  },
  {
    "Word": "girlfriend",
    "FREQcount": "3881"
  },
  {
    "Word": "folks",
    "FREQcount": "3878"
  },
  {
    "Word": "slow",
    "FREQcount": "3877"
  },
  {
    "Word": "private",
    "FREQcount": "3874"
  },
  {
    "Word": "during",
    "FREQcount": "3872"
  },
  {
    "Word": "ed",
    "FREQcount": "3858"
  },
  {
    "Word": "attack",
    "FREQcount": "3853"
  },
  {
    "Word": "beer",
    "FREQcount": "3850"
  },
  {
    "Word": "definitely",
    "FREQcount": "3848"
  },
  {
    "Word": "stopped",
    "FREQcount": "3844"
  },
  {
    "Word": "partner",
    "FREQcount": "3836"
  },
  {
    "Word": "walking",
    "FREQcount": "3826"
  },
  {
    "Word": "area",
    "FREQcount": "3821"
  },
  {
    "Word": "dangerous",
    "FREQcount": "3817"
  },
  {
    "Word": "offer",
    "FREQcount": "3810"
  },
  {
    "Word": "scene",
    "FREQcount": "3807"
  },
  {
    "Word": "third",
    "FREQcount": "3801"
  },
  {
    "Word": "upset",
    "FREQcount": "3800"
  },
  {
    "Word": "bus",
    "FREQcount": "3783"
  },
  {
    "Word": "owe",
    "FREQcount": "3782"
  },
  {
    "Word": "shoes",
    "FREQcount": "3782"
  },
  {
    "Word": "driving",
    "FREQcount": "3780"
  },
  {
    "Word": "english",
    "FREQcount": "3777"
  },
  {
    "Word": "richard",
    "FREQcount": "3765"
  },
  {
    "Word": "group",
    "FREQcount": "3762"
  },
  {
    "Word": "ln",
    "FREQcount": "3753"
  },
  {
    "Word": "kick",
    "FREQcount": "3744"
  },
  {
    "Word": "evil",
    "FREQcount": "3731"
  },
  {
    "Word": "joey",
    "FREQcount": "3727"
  },
  {
    "Word": "joke",
    "FREQcount": "3724"
  },
  {
    "Word": "fell",
    "FREQcount": "3723"
  },
  {
    "Word": "truck",
    "FREQcount": "3716"
  },
  {
    "Word": "teach",
    "FREQcount": "3715"
  },
  {
    "Word": "e",
    "FREQcount": "3702"
  },
  {
    "Word": "green",
    "FREQcount": "3696"
  },
  {
    "Word": "ground",
    "FREQcount": "3696"
  },
  {
    "Word": "loves",
    "FREQcount": "3695"
  },
  {
    "Word": "cash",
    "FREQcount": "3694"
  },
  {
    "Word": "forward",
    "FREQcount": "3689"
  },
  {
    "Word": "honest",
    "FREQcount": "3689"
  },
  {
    "Word": "boyfriend",
    "FREQcount": "3684"
  },
  {
    "Word": "park",
    "FREQcount": "3678"
  },
  {
    "Word": "position",
    "FREQcount": "3676"
  },
  {
    "Word": "single",
    "FREQcount": "3676"
  },
  {
    "Word": "respect",
    "FREQcount": "3644"
  },
  {
    "Word": "broken",
    "FREQcount": "3634"
  },
  {
    "Word": "crime",
    "FREQcount": "3633"
  },
  {
    "Word": "wrote",
    "FREQcount": "3629"
  },
  {
    "Word": "public",
    "FREQcount": "3625"
  },
  {
    "Word": "max",
    "FREQcount": "3620"
  },
  {
    "Word": "mommy",
    "FREQcount": "3617"
  },
  {
    "Word": "congratulations",
    "FREQcount": "3616"
  },
  {
    "Word": "grab",
    "FREQcount": "3614"
  },
  {
    "Word": "art",
    "FREQcount": "3611"
  },
  {
    "Word": "fighting",
    "FREQcount": "3611"
  },
  {
    "Word": "favor",
    "FREQcount": "3609"
  },
  {
    "Word": "upstairs",
    "FREQcount": "3607"
  },
  {
    "Word": "wall",
    "FREQcount": "3605"
  },
  {
    "Word": "force",
    "FREQcount": "3604"
  },
  {
    "Word": "seconds",
    "FREQcount": "3603"
  },
  {
    "Word": "jail",
    "FREQcount": "3602"
  },
  {
    "Word": "push",
    "FREQcount": "3598"
  },
  {
    "Word": "prove",
    "FREQcount": "3590"
  },
  {
    "Word": "normal",
    "FREQcount": "3589"
  },
  {
    "Word": "machine",
    "FREQcount": "3583"
  },
  {
    "Word": "protect",
    "FREQcount": "3583"
  },
  {
    "Word": "field",
    "FREQcount": "3580"
  },
  {
    "Word": "r",
    "FREQcount": "3579"
  },
  {
    "Word": "spent",
    "FREQcount": "3574"
  },
  {
    "Word": "feels",
    "FREQcount": "3569"
  },
  {
    "Word": "speaking",
    "FREQcount": "3565"
  },
  {
    "Word": "named",
    "FREQcount": "3564"
  },
  {
    "Word": "jump",
    "FREQcount": "3561"
  },
  {
    "Word": "saved",
    "FREQcount": "3558"
  },
  {
    "Word": "starting",
    "FREQcount": "3558"
  },
  {
    "Word": "nose",
    "FREQcount": "3557"
  },
  {
    "Word": "hide",
    "FREQcount": "3554"
  },
  {
    "Word": "church",
    "FREQcount": "3553"
  },
  {
    "Word": "sun",
    "FREQcount": "3553"
  },
  {
    "Word": "peace",
    "FREQcount": "3550"
  },
  {
    "Word": "professor",
    "FREQcount": "3548"
  },
  {
    "Word": "bobby",
    "FREQcount": "3547"
  },
  {
    "Word": "share",
    "FREQcount": "3545"
  },
  {
    "Word": "french",
    "FREQcount": "3541"
  },
  {
    "Word": "steve",
    "FREQcount": "3540"
  },
  {
    "Word": "bullshit",
    "FREQcount": "3537"
  },
  {
    "Word": "moved",
    "FREQcount": "3536"
  },
  {
    "Word": "picked",
    "FREQcount": "3534"
  },
  {
    "Word": "thousand",
    "FREQcount": "3534"
  },
  {
    "Word": "paris",
    "FREQcount": "3531"
  },
  {
    "Word": "holding",
    "FREQcount": "3530"
  },
  {
    "Word": "billy",
    "FREQcount": "3525"
  },
  {
    "Word": "fear",
    "FREQcount": "3523"
  },
  {
    "Word": "using",
    "FREQcount": "3520"
  },
  {
    "Word": "la",
    "FREQcount": "3518"
  },
  {
    "Word": "tape",
    "FREQcount": "3511"
  },
  {
    "Word": "tony",
    "FREQcount": "3503"
  },
  {
    "Word": "suit",
    "FREQcount": "3499"
  },
  {
    "Word": "pictures",
    "FREQcount": "3477"
  },
  {
    "Word": "holy",
    "FREQcount": "3475"
  },
  {
    "Word": "putting",
    "FREQcount": "3467"
  },
  {
    "Word": "involved",
    "FREQcount": "3465"
  },
  {
    "Word": "gas",
    "FREQcount": "3457"
  },
  {
    "Word": "books",
    "FREQcount": "3456"
  },
  {
    "Word": "relationship",
    "FREQcount": "3452"
  },
  {
    "Word": "neither",
    "FREQcount": "3451"
  },
  {
    "Word": "nine",
    "FREQcount": "3441"
  },
  {
    "Word": "pop",
    "FREQcount": "3441"
  },
  {
    "Word": "rules",
    "FREQcount": "3438"
  },
  {
    "Word": "bother",
    "FREQcount": "3436"
  },
  {
    "Word": "especially",
    "FREQcount": "3428"
  },
  {
    "Word": "nervous",
    "FREQcount": "3425"
  },
  {
    "Word": "whether",
    "FREQcount": "3424"
  },
  {
    "Word": "dying",
    "FREQcount": "3416"
  },
  {
    "Word": "stuck",
    "FREQcount": "3399"
  },
  {
    "Word": "round",
    "FREQcount": "3393"
  },
  {
    "Word": "dirty",
    "FREQcount": "3389"
  },
  {
    "Word": "cat",
    "FREQcount": "3383"
  },
  {
    "Word": "breakfast",
    "FREQcount": "3381"
  },
  {
    "Word": "idiot",
    "FREQcount": "3377"
  },
  {
    "Word": "space",
    "FREQcount": "3369"
  },
  {
    "Word": "lived",
    "FREQcount": "3368"
  },
  {
    "Word": "prison",
    "FREQcount": "3368"
  },
  {
    "Word": "carry",
    "FREQcount": "3361"
  },
  {
    "Word": "james",
    "FREQcount": "3358"
  },
  {
    "Word": "bastard",
    "FREQcount": "3348"
  },
  {
    "Word": "cry",
    "FREQcount": "3348"
  },
  {
    "Word": "p",
    "FREQcount": "3345"
  },
  {
    "Word": "smoke",
    "FREQcount": "3337"
  },
  {
    "Word": "arm",
    "FREQcount": "3336"
  },
  {
    "Word": "film",
    "FREQcount": "3328"
  },
  {
    "Word": "government",
    "FREQcount": "3327"
  },
  {
    "Word": "tree",
    "FREQcount": "3315"
  },
  {
    "Word": "foot",
    "FREQcount": "3311"
  },
  {
    "Word": "contact",
    "FREQcount": "3305"
  },
  {
    "Word": "knock",
    "FREQcount": "3299"
  },
  {
    "Word": "agree",
    "FREQcount": "3298"
  },
  {
    "Word": "pardon",
    "FREQcount": "3297"
  },
  {
    "Word": "gift",
    "FREQcount": "3290"
  },
  {
    "Word": "gives",
    "FREQcount": "3290"
  },
  {
    "Word": "south",
    "FREQcount": "3288"
  },
  {
    "Word": "dreams",
    "FREQcount": "3285"
  },
  {
    "Word": "jim",
    "FREQcount": "3277"
  },
  {
    "Word": "hat",
    "FREQcount": "3273"
  },
  {
    "Word": "board",
    "FREQcount": "3272"
  },
  {
    "Word": "sake",
    "FREQcount": "3272"
  },
  {
    "Word": "sweetheart",
    "FREQcount": "3272"
  },
  {
    "Word": "seriously",
    "FREQcount": "3270"
  },
  {
    "Word": "north",
    "FREQcount": "3258"
  },
  {
    "Word": "department",
    "FREQcount": "3256"
  },
  {
    "Word": "patient",
    "FREQcount": "3246"
  },
  {
    "Word": "awful",
    "FREQcount": "3234"
  },
  {
    "Word": "sad",
    "FREQcount": "3232"
  },
  {
    "Word": "wondering",
    "FREQcount": "3231"
  },
  {
    "Word": "roll",
    "FREQcount": "3227"
  },
  {
    "Word": "robert",
    "FREQcount": "3222"
  },
  {
    "Word": "beginning",
    "FREQcount": "3219"
  },
  {
    "Word": "grand",
    "FREQcount": "3214"
  },
  {
    "Word": "usually",
    "FREQcount": "3214"
  },
  {
    "Word": "sergeant",
    "FREQcount": "3210"
  },
  {
    "Word": "killer",
    "FREQcount": "3206"
  },
  {
    "Word": "laugh",
    "FREQcount": "3206"
  },
  {
    "Word": "doubt",
    "FREQcount": "3205"
  },
  {
    "Word": "listening",
    "FREQcount": "3205"
  },
  {
    "Word": "upon",
    "FREQcount": "3199"
  },
  {
    "Word": "double",
    "FREQcount": "3198"
  },
  {
    "Word": "twice",
    "FREQcount": "3191"
  },
  {
    "Word": "whose",
    "FREQcount": "3187"
  },
  {
    "Word": "outta",
    "FREQcount": "3185"
  },
  {
    "Word": "plenty",
    "FREQcount": "3178"
  },
  {
    "Word": "guilty",
    "FREQcount": "3177"
  },
  {
    "Word": "jerry",
    "FREQcount": "3173"
  },
  {
    "Word": "promised",
    "FREQcount": "3169"
  },
  {
    "Word": "fired",
    "FREQcount": "3159"
  },
  {
    "Word": "race",
    "FREQcount": "3157"
  },
  {
    "Word": "crap",
    "FREQcount": "3151"
  },
  {
    "Word": "chicken",
    "FREQcount": "3148"
  },
  {
    "Word": "bathroom",
    "FREQcount": "3145"
  },
  {
    "Word": "asshole",
    "FREQcount": "3142"
  },
  {
    "Word": "spot",
    "FREQcount": "3140"
  },
  {
    "Word": "reading",
    "FREQcount": "3133"
  },
  {
    "Word": "orders",
    "FREQcount": "3130"
  },
  {
    "Word": "weekend",
    "FREQcount": "3118"
  },
  {
    "Word": "detective",
    "FREQcount": "3117"
  },
  {
    "Word": "action",
    "FREQcount": "3115"
  },
  {
    "Word": "sheriff",
    "FREQcount": "3115"
  },
  {
    "Word": "eating",
    "FREQcount": "3102"
  },
  {
    "Word": "glass",
    "FREQcount": "3096"
  },
  {
    "Word": "type",
    "FREQcount": "3093"
  },
  {
    "Word": "guns",
    "FREQcount": "3092"
  },
  {
    "Word": "experience",
    "FREQcount": "3088"
  },
  {
    "Word": "west",
    "FREQcount": "3088"
  },
  {
    "Word": "obviously",
    "FREQcount": "3082"
  },
  {
    "Word": "wine",
    "FREQcount": "3078"
  },
  {
    "Word": "luke",
    "FREQcount": "3071"
  },
  {
    "Word": "press",
    "FREQcount": "3070"
  },
  {
    "Word": "difficult",
    "FREQcount": "3068"
  },
  {
    "Word": "lots",
    "FREQcount": "3068"
  },
  {
    "Word": "brown",
    "FREQcount": "3066"
  },
  {
    "Word": "nick",
    "FREQcount": "3062"
  },
  {
    "Word": "rid",
    "FREQcount": "3052"
  },
  {
    "Word": "sea",
    "FREQcount": "3052"
  },
  {
    "Word": "arms",
    "FREQcount": "3050"
  },
  {
    "Word": "flight",
    "FREQcount": "3044"
  },
  {
    "Word": "staying",
    "FREQcount": "3040"
  },
  {
    "Word": "arrest",
    "FREQcount": "3037"
  },
  {
    "Word": "neck",
    "FREQcount": "3035"
  },
  {
    "Word": "grow",
    "FREQcount": "3034"
  },
  {
    "Word": "mention",
    "FREQcount": "3033"
  },
  {
    "Word": "favorite",
    "FREQcount": "3032"
  },
  {
    "Word": "wind",
    "FREQcount": "3028"
  },
  {
    "Word": "sleeping",
    "FREQcount": "3027"
  },
  {
    "Word": "notice",
    "FREQcount": "3022"
  },
  {
    "Word": "admit",
    "FREQcount": "3019"
  },
  {
    "Word": "extra",
    "FREQcount": "3017"
  },
  {
    "Word": "within",
    "FREQcount": "3017"
  },
  {
    "Word": "low",
    "FREQcount": "3016"
  },
  {
    "Word": "impossible",
    "FREQcount": "3015"
  },
  {
    "Word": "gay",
    "FREQcount": "3013"
  },
  {
    "Word": "computer",
    "FREQcount": "3011"
  },
  {
    "Word": "angry",
    "FREQcount": "3008"
  },
  {
    "Word": "bunch",
    "FREQcount": "3003"
  },
  {
    "Word": "blame",
    "FREQcount": "2998"
  },
  {
    "Word": "pants",
    "FREQcount": "2996"
  },
  {
    "Word": "visit",
    "FREQcount": "2993"
  },
  {
    "Word": "clock",
    "FREQcount": "2990"
  },
  {
    "Word": "tea",
    "FREQcount": "2990"
  },
  {
    "Word": "fellow",
    "FREQcount": "2987"
  },
  {
    "Word": "kitchen",
    "FREQcount": "2974"
  },
  {
    "Word": "lay",
    "FREQcount": "2970"
  },
  {
    "Word": "hole",
    "FREQcount": "2969"
  },
  {
    "Word": "guard",
    "FREQcount": "2968"
  },
  {
    "Word": "learned",
    "FREQcount": "2964"
  },
  {
    "Word": "smile",
    "FREQcount": "2958"
  },
  {
    "Word": "feelings",
    "FREQcount": "2938"
  },
  {
    "Word": "fit",
    "FREQcount": "2937"
  },
  {
    "Word": "pal",
    "FREQcount": "2937"
  },
  {
    "Word": "bear",
    "FREQcount": "2928"
  },
  {
    "Word": "often",
    "FREQcount": "2925"
  },
  {
    "Word": "wild",
    "FREQcount": "2923"
  },
  {
    "Word": "silly",
    "FREQcount": "2912"
  },
  {
    "Word": "camera",
    "FREQcount": "2907"
  },
  {
    "Word": "begin",
    "FREQcount": "2906"
  },
  {
    "Word": "ow",
    "FREQcount": "2903"
  },
  {
    "Word": "reach",
    "FREQcount": "2903"
  },
  {
    "Word": "beach",
    "FREQcount": "2888"
  },
  {
    "Word": "larry",
    "FREQcount": "2888"
  },
  {
    "Word": "heaven",
    "FREQcount": "2887"
  },
  {
    "Word": "lock",
    "FREQcount": "2885"
  },
  {
    "Word": "leg",
    "FREQcount": "2882"
  },
  {
    "Word": "quickly",
    "FREQcount": "2881"
  },
  {
    "Word": "lights",
    "FREQcount": "2877"
  },
  {
    "Word": "kelly",
    "FREQcount": "2876"
  },
  {
    "Word": "worst",
    "FREQcount": "2874"
  },
  {
    "Word": "shooting",
    "FREQcount": "2871"
  },
  {
    "Word": "played",
    "FREQcount": "2870"
  },
  {
    "Word": "plans",
    "FREQcount": "2867"
  },
  {
    "Word": "bucks",
    "FREQcount": "2866"
  },
  {
    "Word": "suddenly",
    "FREQcount": "2854"
  },
  {
    "Word": "writing",
    "FREQcount": "2852"
  },
  {
    "Word": "track",
    "FREQcount": "2843"
  },
  {
    "Word": "teacher",
    "FREQcount": "2842"
  },
  {
    "Word": "ridiculous",
    "FREQcount": "2836"
  },
  {
    "Word": "legs",
    "FREQcount": "2835"
  },
  {
    "Word": "river",
    "FREQcount": "2829"
  },
  {
    "Word": "dare",
    "FREQcount": "2826"
  },
  {
    "Word": "burn",
    "FREQcount": "2816"
  },
  {
    "Word": "aunt",
    "FREQcount": "2815"
  },
  {
    "Word": "raise",
    "FREQcount": "2815"
  },
  {
    "Word": "n",
    "FREQcount": "2810"
  },
  {
    "Word": "shh",
    "FREQcount": "2810"
  },
  {
    "Word": "rory",
    "FREQcount": "2809"
  },
  {
    "Word": "decision",
    "FREQcount": "2808"
  },
  {
    "Word": "surprised",
    "FREQcount": "2808"
  },
  {
    "Word": "cross",
    "FREQcount": "2807"
  },
  {
    "Word": "cost",
    "FREQcount": "2801"
  },
  {
    "Word": "queen",
    "FREQcount": "2789"
  },
  {
    "Word": "fresh",
    "FREQcount": "2780"
  },
  {
    "Word": "innocent",
    "FREQcount": "2780"
  },
  {
    "Word": "emergency",
    "FREQcount": "2776"
  },
  {
    "Word": "dancing",
    "FREQcount": "2774"
  },
  {
    "Word": "medical",
    "FREQcount": "2774"
  },
  {
    "Word": "cell",
    "FREQcount": "2772"
  },
  {
    "Word": "gotten",
    "FREQcount": "2768"
  },
  {
    "Word": "seemed",
    "FREQcount": "2767"
  },
  {
    "Word": "bigger",
    "FREQcount": "2765"
  },
  {
    "Word": "states",
    "FREQcount": "2759"
  },
  {
    "Word": "closed",
    "FREQcount": "2758"
  },
  {
    "Word": "names",
    "FREQcount": "2746"
  },
  {
    "Word": "walked",
    "FREQcount": "2737"
  },
  {
    "Word": "bomb",
    "FREQcount": "2736"
  },
  {
    "Word": "hanging",
    "FREQcount": "2735"
  },
  {
    "Word": "note",
    "FREQcount": "2731"
  },
  {
    "Word": "shop",
    "FREQcount": "2731"
  },
  {
    "Word": "sweetie",
    "FREQcount": "2731"
  },
  {
    "Word": "nuts",
    "FREQcount": "2729"
  },
  {
    "Word": "band",
    "FREQcount": "2724"
  },
  {
    "Word": "losing",
    "FREQcount": "2722"
  },
  {
    "Word": "price",
    "FREQcount": "2722"
  },
  {
    "Word": "steal",
    "FREQcount": "2720"
  },
  {
    "Word": "waste",
    "FREQcount": "2716"
  },
  {
    "Word": "client",
    "FREQcount": "2715"
  },
  {
    "Word": "stole",
    "FREQcount": "2711"
  },
  {
    "Word": "code",
    "FREQcount": "2709"
  },
  {
    "Word": "crying",
    "FREQcount": "2709"
  },
  {
    "Word": "pressure",
    "FREQcount": "2709"
  },
  {
    "Word": "places",
    "FREQcount": "2706"
  },
  {
    "Word": "dogs",
    "FREQcount": "2704"
  },
  {
    "Word": "rose",
    "FREQcount": "2704"
  },
  {
    "Word": "dick",
    "FREQcount": "2703"
  },
  {
    "Word": "accept",
    "FREQcount": "2692"
  },
  {
    "Word": "further",
    "FREQcount": "2690"
  },
  {
    "Word": "aah",
    "FREQcount": "2688"
  },
  {
    "Word": "excellent",
    "FREQcount": "2688"
  },
  {
    "Word": "magic",
    "FREQcount": "2687"
  },
  {
    "Word": "drinking",
    "FREQcount": "2685"
  },
  {
    "Word": "keeps",
    "FREQcount": "2681"
  },
  {
    "Word": "corner",
    "FREQcount": "2679"
  },
  {
    "Word": "consider",
    "FREQcount": "2676"
  },
  {
    "Word": "ourselves",
    "FREQcount": "2676"
  },
  {
    "Word": "acting",
    "FREQcount": "2675"
  },
  {
    "Word": "herself",
    "FREQcount": "2675"
  },
  {
    "Word": "locked",
    "FREQcount": "2670"
  },
  {
    "Word": "laughing",
    "FREQcount": "2667"
  },
  {
    "Word": "address",
    "FREQcount": "2666"
  },
  {
    "Word": "copy",
    "FREQcount": "2666"
  },
  {
    "Word": "tells",
    "FREQcount": "2665"
  },
  {
    "Word": "warm",
    "FREQcount": "2659"
  },
  {
    "Word": "sold",
    "FREQcount": "2655"
  },
  {
    "Word": "pregnant",
    "FREQcount": "2653"
  },
  {
    "Word": "hall",
    "FREQcount": "2649"
  },
  {
    "Word": "treat",
    "FREQcount": "2646"
  },
  {
    "Word": "everywhere",
    "FREQcount": "2641"
  },
  {
    "Word": "van",
    "FREQcount": "2641"
  },
  {
    "Word": "papers",
    "FREQcount": "2638"
  },
  {
    "Word": "complete",
    "FREQcount": "2636"
  },
  {
    "Word": "cup",
    "FREQcount": "2634"
  },
  {
    "Word": "level",
    "FREQcount": "2633"
  },
  {
    "Word": "ways",
    "FREQcount": "2633"
  },
  {
    "Word": "passed",
    "FREQcount": "2631"
  },
  {
    "Word": "witness",
    "FREQcount": "2621"
  },
  {
    "Word": "eh",
    "FREQcount": "2619"
  },
  {
    "Word": "taste",
    "FREQcount": "2617"
  },
  {
    "Word": "motherfucker",
    "FREQcount": "2616"
  },
  {
    "Word": "hardly",
    "FREQcount": "2613"
  },
  {
    "Word": "camp",
    "FREQcount": "2612"
  },
  {
    "Word": "keeping",
    "FREQcount": "2608"
  },
  {
    "Word": "charles",
    "FREQcount": "2606"
  },
  {
    "Word": "keys",
    "FREQcount": "2601"
  },
  {
    "Word": "beg",
    "FREQcount": "2600"
  },
  {
    "Word": "yep",
    "FREQcount": "2600"
  },
  {
    "Word": "duty",
    "FREQcount": "2599"
  },
  {
    "Word": "ms",
    "FREQcount": "2599"
  },
  {
    "Word": "interest",
    "FREQcount": "2598"
  },
  {
    "Word": "tight",
    "FREQcount": "2597"
  },
  {
    "Word": "bottle",
    "FREQcount": "2588"
  },
  {
    "Word": "helping",
    "FREQcount": "2588"
  },
  {
    "Word": "support",
    "FREQcount": "2587"
  },
  {
    "Word": "leo",
    "FREQcount": "2580"
  },
  {
    "Word": "f",
    "FREQcount": "2579"
  },
  {
    "Word": "flying",
    "FREQcount": "2579"
  },
  {
    "Word": "decide",
    "FREQcount": "2571"
  },
  {
    "Word": "united",
    "FREQcount": "2564"
  },
  {
    "Word": "st",
    "FREQcount": "2562"
  },
  {
    "Word": "turns",
    "FREQcount": "2552"
  },
  {
    "Word": "moon",
    "FREQcount": "2548"
  },
  {
    "Word": "bottom",
    "FREQcount": "2546"
  },
  {
    "Word": "hoping",
    "FREQcount": "2544"
  },
  {
    "Word": "conversation",
    "FREQcount": "2543"
  },
  {
    "Word": "san",
    "FREQcount": "2543"
  },
  {
    "Word": "hero",
    "FREQcount": "2542"
  },
  {
    "Word": "asleep",
    "FREQcount": "2541"
  },
  {
    "Word": "roger",
    "FREQcount": "2540"
  },
  {
    "Word": "final",
    "FREQcount": "2533"
  },
  {
    "Word": "continue",
    "FREQcount": "2527"
  },
  {
    "Word": "east",
    "FREQcount": "2527"
  },
  {
    "Word": "match",
    "FREQcount": "2521"
  },
  {
    "Word": "apologize",
    "FREQcount": "2518"
  },
  {
    "Word": "trial",
    "FREQcount": "2518"
  },
  {
    "Word": "spirit",
    "FREQcount": "2517"
  },
  {
    "Word": "willing",
    "FREQcount": "2512"
  },
  {
    "Word": "chair",
    "FREQcount": "2511"
  },
  {
    "Word": "u",
    "FREQcount": "2506"
  },
  {
    "Word": "risk",
    "FREQcount": "2501"
  },
  {
    "Word": "study",
    "FREQcount": "2501"
  },
  {
    "Word": "amy",
    "FREQcount": "2498"
  },
  {
    "Word": "possibly",
    "FREQcount": "2494"
  },
  {
    "Word": "rain",
    "FREQcount": "2494"
  },
  {
    "Word": "above",
    "FREQcount": "2493"
  },
  {
    "Word": "cousin",
    "FREQcount": "2491"
  },
  {
    "Word": "pulled",
    "FREQcount": "2488"
  },
  {
    "Word": "cream",
    "FREQcount": "2484"
  },
  {
    "Word": "dropped",
    "FREQcount": "2482"
  },
  {
    "Word": "excited",
    "FREQcount": "2479"
  },
  {
    "Word": "memory",
    "FREQcount": "2477"
  },
  {
    "Word": "breathe",
    "FREQcount": "2474"
  },
  {
    "Word": "enemy",
    "FREQcount": "2474"
  },
  {
    "Word": "huge",
    "FREQcount": "2467"
  },
  {
    "Word": "search",
    "FREQcount": "2467"
  },
  {
    "Word": "drugs",
    "FREQcount": "2464"
  },
  {
    "Word": "greatest",
    "FREQcount": "2464"
  },
  {
    "Word": "beauty",
    "FREQcount": "2460"
  },
  {
    "Word": "lately",
    "FREQcount": "2459"
  },
  {
    "Word": "tommy",
    "FREQcount": "2459"
  },
  {
    "Word": "rule",
    "FREQcount": "2455"
  },
  {
    "Word": "build",
    "FREQcount": "2452"
  },
  {
    "Word": "choose",
    "FREQcount": "2451"
  },
  {
    "Word": "cards",
    "FREQcount": "2449"
  },
  {
    "Word": "lee",
    "FREQcount": "2449"
  },
  {
    "Word": "advice",
    "FREQcount": "2447"
  },
  {
    "Word": "immediately",
    "FREQcount": "2446"
  },
  {
    "Word": "teeth",
    "FREQcount": "2440"
  },
  {
    "Word": "became",
    "FREQcount": "2435"
  },
  {
    "Word": "victim",
    "FREQcount": "2434"
  },
  {
    "Word": "coach",
    "FREQcount": "2429"
  },
  {
    "Word": "friday",
    "FREQcount": "2429"
  },
  {
    "Word": "flowers",
    "FREQcount": "2427"
  },
  {
    "Word": "showed",
    "FREQcount": "2425"
  },
  {
    "Word": "crew",
    "FREQcount": "2424"
  },
  {
    "Word": "saturday",
    "FREQcount": "2423"
  },
  {
    "Word": "driver",
    "FREQcount": "2416"
  },
  {
    "Word": "apparently",
    "FREQcount": "2415"
  },
  {
    "Word": "heavy",
    "FREQcount": "2412"
  },
  {
    "Word": "trick",
    "FREQcount": "2411"
  },
  {
    "Word": "empty",
    "FREQcount": "2409"
  },
  {
    "Word": "comfortable",
    "FREQcount": "2408"
  },
  {
    "Word": "destroy",
    "FREQcount": "2406"
  },
  {
    "Word": "brothers",
    "FREQcount": "2400"
  },
  {
    "Word": "mission",
    "FREQcount": "2400"
  },
  {
    "Word": "plus",
    "FREQcount": "2399"
  },
  {
    "Word": "apart",
    "FREQcount": "2398"
  },
  {
    "Word": "pool",
    "FREQcount": "2396"
  },
  {
    "Word": "dumb",
    "FREQcount": "2395"
  },
  {
    "Word": "dressed",
    "FREQcount": "2394"
  },
  {
    "Word": "helped",
    "FREQcount": "2388"
  },
  {
    "Word": "knife",
    "FREQcount": "2387"
  },
  {
    "Word": "checked",
    "FREQcount": "2382"
  },
  {
    "Word": "santa",
    "FREQcount": "2381"
  },
  {
    "Word": "weapon",
    "FREQcount": "2379"
  },
  {
    "Word": "restaurant",
    "FREQcount": "2373"
  },
  {
    "Word": "shirt",
    "FREQcount": "2365"
  },
  {
    "Word": "faith",
    "FREQcount": "2363"
  },
  {
    "Word": "gee",
    "FREQcount": "2362"
  },
  {
    "Word": "simply",
    "FREQcount": "2362"
  },
  {
    "Word": "dig",
    "FREQcount": "2357"
  },
  {
    "Word": "size",
    "FREQcount": "2353"
  },
  {
    "Word": "stars",
    "FREQcount": "2353"
  },
  {
    "Word": "london",
    "FREQcount": "2347"
  },
  {
    "Word": "movies",
    "FREQcount": "2346"
  },
  {
    "Word": "necessary",
    "FREQcount": "2345"
  },
  {
    "Word": "themselves",
    "FREQcount": "2343"
  },
  {
    "Word": "blind",
    "FREQcount": "2337"
  },
  {
    "Word": "credit",
    "FREQcount": "2337"
  },
  {
    "Word": "center",
    "FREQcount": "2335"
  },
  {
    "Word": "starts",
    "FREQcount": "2335"
  },
  {
    "Word": "bridge",
    "FREQcount": "2331"
  },
  {
    "Word": "practice",
    "FREQcount": "2330"
  },
  {
    "Word": "closer",
    "FREQcount": "2329"
  },
  {
    "Word": "discuss",
    "FREQcount": "2329"
  },
  {
    "Word": "cars",
    "FREQcount": "2327"
  },
  {
    "Word": "mister",
    "FREQcount": "2326"
  },
  {
    "Word": "grandma",
    "FREQcount": "2325"
  },
  {
    "Word": "cook",
    "FREQcount": "2324"
  },
  {
    "Word": "stage",
    "FREQcount": "2324"
  },
  {
    "Word": "strike",
    "FREQcount": "2324"
  },
  {
    "Word": "ticket",
    "FREQcount": "2324"
  },
  {
    "Word": "animal",
    "FREQcount": "2320"
  },
  {
    "Word": "bird",
    "FREQcount": "2318"
  },
  {
    "Word": "leaves",
    "FREQcount": "2316"
  },
  {
    "Word": "sight",
    "FREQcount": "2311"
  },
  {
    "Word": "following",
    "FREQcount": "2310"
  },
  {
    "Word": "somehow",
    "FREQcount": "2310"
  },
  {
    "Word": "knowing",
    "FREQcount": "2307"
  },
  {
    "Word": "drug",
    "FREQcount": "2306"
  },
  {
    "Word": "career",
    "FREQcount": "2305"
  },
  {
    "Word": "nature",
    "FREQcount": "2303"
  },
  {
    "Word": "however",
    "FREQcount": "2299"
  },
  {
    "Word": "prince",
    "FREQcount": "2299"
  },
  {
    "Word": "cake",
    "FREQcount": "2298"
  },
  {
    "Word": "responsible",
    "FREQcount": "2298"
  },
  {
    "Word": "famous",
    "FREQcount": "2296"
  },
  {
    "Word": "nurse",
    "FREQcount": "2294"
  },
  {
    "Word": "correct",
    "FREQcount": "2292"
  },
  {
    "Word": "breath",
    "FREQcount": "2291"
  },
  {
    "Word": "fucked",
    "FREQcount": "2291"
  },
  {
    "Word": "games",
    "FREQcount": "2287"
  },
  {
    "Word": "allowed",
    "FREQcount": "2286"
  },
  {
    "Word": "sky",
    "FREQcount": "2285"
  },
  {
    "Word": "bringing",
    "FREQcount": "2282"
  },
  {
    "Word": "hearing",
    "FREQcount": "2281"
  },
  {
    "Word": "singing",
    "FREQcount": "2281"
  },
  {
    "Word": "account",
    "FREQcount": "2280"
  },
  {
    "Word": "common",
    "FREQcount": "2275"
  },
  {
    "Word": "due",
    "FREQcount": "2275"
  },
  {
    "Word": "afford",
    "FREQcount": "2266"
  },
  {
    "Word": "chinese",
    "FREQcount": "2266"
  },
  {
    "Word": "tie",
    "FREQcount": "2266"
  },
  {
    "Word": "bright",
    "FREQcount": "2265"
  },
  {
    "Word": "allow",
    "FREQcount": "2263"
  },
  {
    "Word": "belong",
    "FREQcount": "2263"
  },
  {
    "Word": "concerned",
    "FREQcount": "2261"
  },
  {
    "Word": "escape",
    "FREQcount": "2258"
  },
  {
    "Word": "suspect",
    "FREQcount": "2254"
  },
  {
    "Word": "written",
    "FREQcount": "2247"
  },
  {
    "Word": "file",
    "FREQcount": "2246"
  },
  {
    "Word": "skin",
    "FREQcount": "2246"
  },
  {
    "Word": "jake",
    "FREQcount": "2245"
  },
  {
    "Word": "madam",
    "FREQcount": "2244"
  },
  {
    "Word": "fill",
    "FREQcount": "2241"
  },
  {
    "Word": "operation",
    "FREQcount": "2241"
  },
  {
    "Word": "desk",
    "FREQcount": "2239"
  },
  {
    "Word": "aye",
    "FREQcount": "2236"
  },
  {
    "Word": "taught",
    "FREQcount": "2236"
  },
  {
    "Word": "pack",
    "FREQcount": "2235"
  },
  {
    "Word": "lied",
    "FREQcount": "2234"
  },
  {
    "Word": "faster",
    "FREQcount": "2233"
  },
  {
    "Word": "deserve",
    "FREQcount": "2230"
  },
  {
    "Word": "ted",
    "FREQcount": "2228"
  },
  {
    "Word": "danger",
    "FREQcount": "2227"
  },
  {
    "Word": "meat",
    "FREQcount": "2226"
  },
  {
    "Word": "command",
    "FREQcount": "2225"
  },
  {
    "Word": "stories",
    "FREQcount": "2215"
  },
  {
    "Word": "tickets",
    "FREQcount": "2211"
  },
  {
    "Word": "hiding",
    "FREQcount": "2207"
  },
  {
    "Word": "paying",
    "FREQcount": "2207"
  },
  {
    "Word": "perfectly",
    "FREQcount": "2206"
  },
  {
    "Word": "sunday",
    "FREQcount": "2206"
  },
  {
    "Word": "whoever",
    "FREQcount": "2203"
  },
  {
    "Word": "beyond",
    "FREQcount": "2200"
  },
  {
    "Word": "sarah",
    "FREQcount": "2200"
  },
  {
    "Word": "dave",
    "FREQcount": "2199"
  },
  {
    "Word": "student",
    "FREQcount": "2195"
  },
  {
    "Word": "jane",
    "FREQcount": "2192"
  },
  {
    "Word": "dry",
    "FREQcount": "2184"
  },
  {
    "Word": "jury",
    "FREQcount": "2181"
  },
  {
    "Word": "form",
    "FREQcount": "2180"
  },
  {
    "Word": "main",
    "FREQcount": "2179"
  },
  {
    "Word": "heads",
    "FREQcount": "2177"
  },
  {
    "Word": "program",
    "FREQcount": "2174"
  },
  {
    "Word": "papa",
    "FREQcount": "2172"
  },
  {
    "Word": "martin",
    "FREQcount": "2170"
  },
  {
    "Word": "fred",
    "FREQcount": "2169"
  },
  {
    "Word": "g",
    "FREQcount": "2169"
  },
  {
    "Word": "milk",
    "FREQcount": "2169"
  },
  {
    "Word": "held",
    "FREQcount": "2165"
  },
  {
    "Word": "horrible",
    "FREQcount": "2164"
  },
  {
    "Word": "kinda",
    "FREQcount": "2163"
  },
  {
    "Word": "feed",
    "FREQcount": "2162"
  },
  {
    "Word": "de",
    "FREQcount": "2161"
  },
  {
    "Word": "natural",
    "FREQcount": "2160"
  },
  {
    "Word": "grace",
    "FREQcount": "2157"
  },
  {
    "Word": "battle",
    "FREQcount": "2155"
  },
  {
    "Word": "breaking",
    "FREQcount": "2155"
  },
  {
    "Word": "phoebe",
    "FREQcount": "2150"
  },
  {
    "Word": "ugly",
    "FREQcount": "2150"
  },
  {
    "Word": "coat",
    "FREQcount": "2146"
  },
  {
    "Word": "although",
    "FREQcount": "2143"
  },
  {
    "Word": "settle",
    "FREQcount": "2143"
  },
  {
    "Word": "opinion",
    "FREQcount": "2142"
  },
  {
    "Word": "washington",
    "FREQcount": "2142"
  },
  {
    "Word": "ho",
    "FREQcount": "2141"
  },
  {
    "Word": "terrific",
    "FREQcount": "2138"
  },
  {
    "Word": "according",
    "FREQcount": "2135"
  },
  {
    "Word": "gentleman",
    "FREQcount": "2135"
  },
  {
    "Word": "older",
    "FREQcount": "2135"
  },
  {
    "Word": "lucy",
    "FREQcount": "2132"
  },
  {
    "Word": "loose",
    "FREQcount": "2131"
  },
  {
    "Word": "noticed",
    "FREQcount": "2131"
  },
  {
    "Word": "local",
    "FREQcount": "2128"
  },
  {
    "Word": "lonely",
    "FREQcount": "2125"
  },
  {
    "Word": "shame",
    "FREQcount": "2120"
  },
  {
    "Word": "otherwise",
    "FREQcount": "2119"
  },
  {
    "Word": "shows",
    "FREQcount": "2117"
  },
  {
    "Word": "large",
    "FREQcount": "2114"
  },
  {
    "Word": "devil",
    "FREQcount": "2108"
  },
  {
    "Word": "video",
    "FREQcount": "2105"
  },
  {
    "Word": "speed",
    "FREQcount": "2104"
  },
  {
    "Word": "military",
    "FREQcount": "2103"
  },
  {
    "Word": "chicago",
    "FREQcount": "2102"
  },
  {
    "Word": "built",
    "FREQcount": "2099"
  },
  {
    "Word": "shower",
    "FREQcount": "2097"
  },
  {
    "Word": "oil",
    "FREQcount": "2095"
  },
  {
    "Word": "opportunity",
    "FREQcount": "2091"
  },
  {
    "Word": "chest",
    "FREQcount": "2090"
  },
  {
    "Word": "horses",
    "FREQcount": "2087"
  },
  {
    "Word": "biggest",
    "FREQcount": "2085"
  },
  {
    "Word": "threw",
    "FREQcount": "2082"
  },
  {
    "Word": "bite",
    "FREQcount": "2080"
  },
  {
    "Word": "eric",
    "FREQcount": "2080"
  },
  {
    "Word": "aw",
    "FREQcount": "2079"
  },
  {
    "Word": "wash",
    "FREQcount": "2077"
  },
  {
    "Word": "stone",
    "FREQcount": "2072"
  },
  {
    "Word": "block",
    "FREQcount": "2067"
  },
  {
    "Word": "records",
    "FREQcount": "2066"
  },
  {
    "Word": "indeed",
    "FREQcount": "2065"
  },
  {
    "Word": "weapons",
    "FREQcount": "2065"
  },
  {
    "Word": "invited",
    "FREQcount": "2064"
  },
  {
    "Word": "draw",
    "FREQcount": "2061"
  },
  {
    "Word": "turning",
    "FREQcount": "2061"
  },
  {
    "Word": "attorney",
    "FREQcount": "2060"
  },
  {
    "Word": "pretend",
    "FREQcount": "2056"
  },
  {
    "Word": "health",
    "FREQcount": "2054"
  },
  {
    "Word": "vegas",
    "FREQcount": "2054"
  },
  {
    "Word": "balls",
    "FREQcount": "2048"
  },
  {
    "Word": "heat",
    "FREQcount": "2044"
  },
  {
    "Word": "manager",
    "FREQcount": "2038"
  },
  {
    "Word": "guest",
    "FREQcount": "2037"
  },
  {
    "Word": "loud",
    "FREQcount": "2031"
  },
  {
    "Word": "fantastic",
    "FREQcount": "2029"
  },
  {
    "Word": "itself",
    "FREQcount": "2029"
  },
  {
    "Word": "cares",
    "FREQcount": "2023"
  },
  {
    "Word": "shake",
    "FREQcount": "2021"
  },
  {
    "Word": "lab",
    "FREQcount": "2020"
  },
  {
    "Word": "numbers",
    "FREQcount": "2020"
  },
  {
    "Word": "princess",
    "FREQcount": "2019"
  },
  {
    "Word": "island",
    "FREQcount": "2018"
  },
  {
    "Word": "easier",
    "FREQcount": "2012"
  },
  {
    "Word": "color",
    "FREQcount": "2011"
  },
  {
    "Word": "earlier",
    "FREQcount": "2010"
  },
  {
    "Word": "bell",
    "FREQcount": "2006"
  },
  {
    "Word": "naked",
    "FREQcount": "2002"
  },
  {
    "Word": "suggest",
    "FREQcount": "2001"
  },
  {
    "Word": "wet",
    "FREQcount": "2000"
  },
  {
    "Word": "pig",
    "FREQcount": "1996"
  },
  {
    "Word": "letting",
    "FREQcount": "1995"
  },
  {
    "Word": "nowhere",
    "FREQcount": "1995"
  },
  {
    "Word": "merry",
    "FREQcount": "1994"
  },
  {
    "Word": "animals",
    "FREQcount": "1993"
  },
  {
    "Word": "weli",
    "FREQcount": "1993"
  },
  {
    "Word": "cheese",
    "FREQcount": "1991"
  },
  {
    "Word": "ideas",
    "FREQcount": "1987"
  },
  {
    "Word": "downstairs",
    "FREQcount": "1985"
  },
  {
    "Word": "soldier",
    "FREQcount": "1985"
  },
  {
    "Word": "monster",
    "FREQcount": "1982"
  },
  {
    "Word": "several",
    "FREQcount": "1978"
  },
  {
    "Word": "planet",
    "FREQcount": "1975"
  },
  {
    "Word": "dean",
    "FREQcount": "1974"
  },
  {
    "Word": "fellas",
    "FREQcount": "1973"
  },
  {
    "Word": "insane",
    "FREQcount": "1973"
  },
  {
    "Word": "california",
    "FREQcount": "1972"
  },
  {
    "Word": "walter",
    "FREQcount": "1972"
  },
  {
    "Word": "eggs",
    "FREQcount": "1971"
  },
  {
    "Word": "spoke",
    "FREQcount": "1970"
  },
  {
    "Word": "butt",
    "FREQcount": "1967"
  },
  {
    "Word": "murdered",
    "FREQcount": "1967"
  },
  {
    "Word": "view",
    "FREQcount": "1965"
  },
  {
    "Word": "bloody",
    "FREQcount": "1962"
  },
  {
    "Word": "lines",
    "FREQcount": "1960"
  },
  {
    "Word": "opening",
    "FREQcount": "1960"
  },
  {
    "Word": "insurance",
    "FREQcount": "1955"
  },
  {
    "Word": "pete",
    "FREQcount": "1954"
  },
  {
    "Word": "split",
    "FREQcount": "1954"
  },
  {
    "Word": "jealous",
    "FREQcount": "1952"
  },
  {
    "Word": "bullet",
    "FREQcount": "1950"
  },
  {
    "Word": "arrived",
    "FREQcount": "1949"
  },
  {
    "Word": "character",
    "FREQcount": "1946"
  },
  {
    "Word": "national",
    "FREQcount": "1946"
  },
  {
    "Word": "screaming",
    "FREQcount": "1945"
  },
  {
    "Word": "airport",
    "FREQcount": "1940"
  },
  {
    "Word": "speech",
    "FREQcount": "1940"
  },
  {
    "Word": "hook",
    "FREQcount": "1938"
  },
  {
    "Word": "condition",
    "FREQcount": "1936"
  },
  {
    "Word": "target",
    "FREQcount": "1936"
  },
  {
    "Word": "finding",
    "FREQcount": "1935"
  },
  {
    "Word": "serve",
    "FREQcount": "1935"
  },
  {
    "Word": "er",
    "FREQcount": "1932"
  },
  {
    "Word": "incredible",
    "FREQcount": "1928"
  },
  {
    "Word": "player",
    "FREQcount": "1926"
  },
  {
    "Word": "signal",
    "FREQcount": "1926"
  },
  {
    "Word": "sugar",
    "FREQcount": "1926"
  },
  {
    "Word": "helen",
    "FREQcount": "1923"
  },
  {
    "Word": "total",
    "FREQcount": "1920"
  },
  {
    "Word": "selling",
    "FREQcount": "1919"
  },
  {
    "Word": "hill",
    "FREQcount": "1915"
  },
  {
    "Word": "football",
    "FREQcount": "1914"
  },
  {
    "Word": "page",
    "FREQcount": "1912"
  },
  {
    "Word": "screw",
    "FREQcount": "1912"
  },
  {
    "Word": "justice",
    "FREQcount": "1910"
  },
  {
    "Word": "letters",
    "FREQcount": "1910"
  },
  {
    "Word": "hurts",
    "FREQcount": "1907"
  },
  {
    "Word": "project",
    "FREQcount": "1907"
  },
  {
    "Word": "rough",
    "FREQcount": "1907"
  },
  {
    "Word": "crowd",
    "FREQcount": "1906"
  },
  {
    "Word": "meaning",
    "FREQcount": "1904"
  },
  {
    "Word": "planning",
    "FREQcount": "1902"
  },
  {
    "Word": "pair",
    "FREQcount": "1900"
  },
  {
    "Word": "science",
    "FREQcount": "1900"
  },
  {
    "Word": "sees",
    "FREQcount": "1899"
  },
  {
    "Word": "usual",
    "FREQcount": "1899"
  },
  {
    "Word": "adam",
    "FREQcount": "1890"
  },
  {
    "Word": "emily",
    "FREQcount": "1889"
  },
  {
    "Word": "sooner",
    "FREQcount": "1888"
  },
  {
    "Word": "commander",
    "FREQcount": "1887"
  },
  {
    "Word": "ordered",
    "FREQcount": "1885"
  },
  {
    "Word": "subject",
    "FREQcount": "1885"
  },
  {
    "Word": "lies",
    "FREQcount": "1883"
  },
  {
    "Word": "remind",
    "FREQcount": "1883"
  },
  {
    "Word": "strength",
    "FREQcount": "1883"
  },
  {
    "Word": "mail",
    "FREQcount": "1879"
  },
  {
    "Word": "dan",
    "FREQcount": "1878"
  },
  {
    "Word": "paint",
    "FREQcount": "1877"
  },
  {
    "Word": "freak",
    "FREQcount": "1874"
  },
  {
    "Word": "bedroom",
    "FREQcount": "1872"
  },
  {
    "Word": "neighborhood",
    "FREQcount": "1871"
  },
  {
    "Word": "onto",
    "FREQcount": "1871"
  },
  {
    "Word": "finger",
    "FREQcount": "1870"
  },
  {
    "Word": "personally",
    "FREQcount": "1870"
  },
  {
    "Word": "spell",
    "FREQcount": "1869"
  },
  {
    "Word": "tim",
    "FREQcount": "1867"
  },
  {
    "Word": "ghost",
    "FREQcount": "1866"
  },
  {
    "Word": "majesty",
    "FREQcount": "1863"
  },
  {
    "Word": "peg",
    "FREQcount": "1857"
  },
  {
    "Word": "smith",
    "FREQcount": "1856"
  },
  {
    "Word": "doctors",
    "FREQcount": "1855"
  },
  {
    "Word": "fake",
    "FREQcount": "1853"
  },
  {
    "Word": "release",
    "FREQcount": "1851"
  },
  {
    "Word": "weight",
    "FREQcount": "1850"
  },
  {
    "Word": "cheap",
    "FREQcount": "1848"
  },
  {
    "Word": "market",
    "FREQcount": "1848"
  },
  {
    "Word": "pray",
    "FREQcount": "1847"
  },
  {
    "Word": "expecting",
    "FREQcount": "1846"
  },
  {
    "Word": "unit",
    "FREQcount": "1845"
  },
  {
    "Word": "signed",
    "FREQcount": "1839"
  },
  {
    "Word": "falling",
    "FREQcount": "1837"
  },
  {
    "Word": "throat",
    "FREQcount": "1837"
  },
  {
    "Word": "lake",
    "FREQcount": "1836"
  },
  {
    "Word": "nor",
    "FREQcount": "1835"
  },
  {
    "Word": "susan",
    "FREQcount": "1835"
  },
  {
    "Word": "director",
    "FREQcount": "1834"
  },
  {
    "Word": "realized",
    "FREQcount": "1834"
  },
  {
    "Word": "agreed",
    "FREQcount": "1832"
  },
  {
    "Word": "phil",
    "FREQcount": "1830"
  },
  {
    "Word": "truly",
    "FREQcount": "1830"
  },
  {
    "Word": "brilliant",
    "FREQcount": "1826"
  },
  {
    "Word": "cab",
    "FREQcount": "1826"
  },
  {
    "Word": "powers",
    "FREQcount": "1826"
  },
  {
    "Word": "candy",
    "FREQcount": "1825"
  },
  {
    "Word": "junior",
    "FREQcount": "1825"
  },
  {
    "Word": "prepared",
    "FREQcount": "1825"
  },
  {
    "Word": "legal",
    "FREQcount": "1821"
  },
  {
    "Word": "pocket",
    "FREQcount": "1821"
  },
  {
    "Word": "scott",
    "FREQcount": "1821"
  },
  {
    "Word": "aware",
    "FREQcount": "1818"
  },
  {
    "Word": "roof",
    "FREQcount": "1818"
  },
  {
    "Word": "jason",
    "FREQcount": "1816"
  },
  {
    "Word": "babe",
    "FREQcount": "1814"
  },
  {
    "Word": "brian",
    "FREQcount": "1813"
  },
  {
    "Word": "radar",
    "FREQcount": "1811"
  },
  {
    "Word": "slept",
    "FREQcount": "1810"
  },
  {
    "Word": "bud",
    "FREQcount": "1808"
  },
  {
    "Word": "responsibility",
    "FREQcount": "1806"
  },
  {
    "Word": "mountain",
    "FREQcount": "1805"
  },
  {
    "Word": "base",
    "FREQcount": "1804"
  },
  {
    "Word": "ours",
    "FREQcount": "1801"
  },
  {
    "Word": "firm",
    "FREQcount": "1799"
  },
  {
    "Word": "england",
    "FREQcount": "1796"
  },
  {
    "Word": "trade",
    "FREQcount": "1795"
  },
  {
    "Word": "whom",
    "FREQcount": "1795"
  },
  {
    "Word": "romantic",
    "FREQcount": "1794"
  },
  {
    "Word": "fan",
    "FREQcount": "1792"
  },
  {
    "Word": "liar",
    "FREQcount": "1792"
  },
  {
    "Word": "training",
    "FREQcount": "1792"
  },
  {
    "Word": "brings",
    "FREQcount": "1791"
  },
  {
    "Word": "powerful",
    "FREQcount": "1791"
  },
  {
    "Word": "language",
    "FREQcount": "1790"
  },
  {
    "Word": "sending",
    "FREQcount": "1790"
  },
  {
    "Word": "whenever",
    "FREQcount": "1790"
  },
  {
    "Word": "purpose",
    "FREQcount": "1789"
  },
  {
    "Word": "whoo",
    "FREQcount": "1789"
  },
  {
    "Word": "believed",
    "FREQcount": "1788"
  },
  {
    "Word": "bless",
    "FREQcount": "1788"
  },
  {
    "Word": "nope",
    "FREQcount": "1783"
  },
  {
    "Word": "pieces",
    "FREQcount": "1783"
  },
  {
    "Word": "arrested",
    "FREQcount": "1781"
  },
  {
    "Word": "noise",
    "FREQcount": "1779"
  },
  {
    "Word": "suck",
    "FREQcount": "1779"
  },
  {
    "Word": "fancy",
    "FREQcount": "1777"
  },
  {
    "Word": "exciting",
    "FREQcount": "1776"
  },
  {
    "Word": "genius",
    "FREQcount": "1773"
  },
  {
    "Word": "forgotten",
    "FREQcount": "1771"
  },
  {
    "Word": "introduce",
    "FREQcount": "1771"
  },
  {
    "Word": "annie",
    "FREQcount": "1769"
  },
  {
    "Word": "rent",
    "FREQcount": "1762"
  },
  {
    "Word": "familiar",
    "FREQcount": "1760"
  },
  {
    "Word": "criminal",
    "FREQcount": "1758"
  },
  {
    "Word": "doors",
    "FREQcount": "1755"
  },
  {
    "Word": "proof",
    "FREQcount": "1754"
  },
  {
    "Word": "vote",
    "FREQcount": "1751"
  },
  {
    "Word": "com",
    "FREQcount": "1750"
  },
  {
    "Word": "recognize",
    "FREQcount": "1750"
  },
  {
    "Word": "stolen",
    "FREQcount": "1750"
  },
  {
    "Word": "suicide",
    "FREQcount": "1747"
  },
  {
    "Word": "weather",
    "FREQcount": "1746"
  },
  {
    "Word": "drinks",
    "FREQcount": "1744"
  },
  {
    "Word": "medicine",
    "FREQcount": "1744"
  },
  {
    "Word": "k",
    "FREQcount": "1743"
  },
  {
    "Word": "issue",
    "FREQcount": "1741"
  },
  {
    "Word": "lift",
    "FREQcount": "1741"
  },
  {
    "Word": "followed",
    "FREQcount": "1739"
  },
  {
    "Word": "anna",
    "FREQcount": "1738"
  },
  {
    "Word": "buried",
    "FREQcount": "1738"
  },
  {
    "Word": "mood",
    "FREQcount": "1736"
  },
  {
    "Word": "male",
    "FREQcount": "1731"
  },
  {
    "Word": "among",
    "FREQcount": "1729"
  },
  {
    "Word": "television",
    "FREQcount": "1729"
  },
  {
    "Word": "nights",
    "FREQcount": "1727"
  },
  {
    "Word": "regular",
    "FREQcount": "1727"
  },
  {
    "Word": "opened",
    "FREQcount": "1726"
  },
  {
    "Word": "someday",
    "FREQcount": "1726"
  },
  {
    "Word": "stomach",
    "FREQcount": "1725"
  },
  {
    "Word": "yellow",
    "FREQcount": "1724"
  },
  {
    "Word": "ate",
    "FREQcount": "1722"
  },
  {
    "Word": "county",
    "FREQcount": "1722"
  },
  {
    "Word": "buck",
    "FREQcount": "1721"
  },
  {
    "Word": "nearly",
    "FREQcount": "1721"
  },
  {
    "Word": "crane",
    "FREQcount": "1714"
  },
  {
    "Word": "scare",
    "FREQcount": "1712"
  },
  {
    "Word": "village",
    "FREQcount": "1712"
  },
  {
    "Word": "prepare",
    "FREQcount": "1711"
  },
  {
    "Word": "matters",
    "FREQcount": "1710"
  },
  {
    "Word": "monkey",
    "FREQcount": "1709"
  },
  {
    "Word": "pizza",
    "FREQcount": "1709"
  },
  {
    "Word": "assume",
    "FREQcount": "1707"
  },
  {
    "Word": "heading",
    "FREQcount": "1707"
  },
  {
    "Word": "sudden",
    "FREQcount": "1707"
  },
  {
    "Word": "toast",
    "FREQcount": "1707"
  },
  {
    "Word": "ears",
    "FREQcount": "1705"
  },
  {
    "Word": "fella",
    "FREQcount": "1705"
  },
  {
    "Word": "babies",
    "FREQcount": "1704"
  },
  {
    "Word": "jacket",
    "FREQcount": "1704"
  },
  {
    "Word": "lane",
    "FREQcount": "1704"
  },
  {
    "Word": "social",
    "FREQcount": "1703"
  },
  {
    "Word": "thoughts",
    "FREQcount": "1703"
  },
  {
    "Word": "travel",
    "FREQcount": "1702"
  },
  {
    "Word": "sometime",
    "FREQcount": "1699"
  },
  {
    "Word": "monday",
    "FREQcount": "1698"
  },
  {
    "Word": "property",
    "FREQcount": "1698"
  },
  {
    "Word": "expected",
    "FREQcount": "1696"
  },
  {
    "Word": "fingers",
    "FREQcount": "1696"
  },
  {
    "Word": "bodies",
    "FREQcount": "1694"
  },
  {
    "Word": "remain",
    "FREQcount": "1694"
  },
  {
    "Word": "secretary",
    "FREQcount": "1694"
  },
  {
    "Word": "funeral",
    "FREQcount": "1693"
  },
  {
    "Word": "magazine",
    "FREQcount": "1693"
  },
  {
    "Word": "sexual",
    "FREQcount": "1693"
  },
  {
    "Word": "senator",
    "FREQcount": "1691"
  },
  {
    "Word": "jerk",
    "FREQcount": "1690"
  },
  {
    "Word": "dating",
    "FREQcount": "1689"
  },
  {
    "Word": "glasses",
    "FREQcount": "1689"
  },
  {
    "Word": "freedom",
    "FREQcount": "1688"
  },
  {
    "Word": "research",
    "FREQcount": "1688"
  },
  {
    "Word": "arthur",
    "FREQcount": "1687"
  },
  {
    "Word": "add",
    "FREQcount": "1686"
  },
  {
    "Word": "damage",
    "FREQcount": "1686"
  },
  {
    "Word": "handsome",
    "FREQcount": "1684"
  },
  {
    "Word": "repeat",
    "FREQcount": "1684"
  },
  {
    "Word": "hired",
    "FREQcount": "1683"
  },
  {
    "Word": "buying",
    "FREQcount": "1679"
  },
  {
    "Word": "prefer",
    "FREQcount": "1679"
  },
  {
    "Word": "society",
    "FREQcount": "1679"
  },
  {
    "Word": "energy",
    "FREQcount": "1678"
  },
  {
    "Word": "alan",
    "FREQcount": "1676"
  },
  {
    "Word": "crack",
    "FREQcount": "1675"
  },
  {
    "Word": "chase",
    "FREQcount": "1673"
  },
  {
    "Word": "vacation",
    "FREQcount": "1673"
  },
  {
    "Word": "mulder",
    "FREQcount": "1671"
  },
  {
    "Word": "carter",
    "FREQcount": "1669"
  },
  {
    "Word": "divorce",
    "FREQcount": "1669"
  },
  {
    "Word": "stayed",
    "FREQcount": "1668"
  },
  {
    "Word": "ally",
    "FREQcount": "1666"
  },
  {
    "Word": "jackson",
    "FREQcount": "1666"
  },
  {
    "Word": "defense",
    "FREQcount": "1665"
  },
  {
    "Word": "rat",
    "FREQcount": "1663"
  },
  {
    "Word": "grandpa",
    "FREQcount": "1661"
  },
  {
    "Word": "grant",
    "FREQcount": "1660"
  },
  {
    "Word": "began",
    "FREQcount": "1658"
  },
  {
    "Word": "picking",
    "FREQcount": "1658"
  },
  {
    "Word": "checking",
    "FREQcount": "1656"
  },
  {
    "Word": "goodness",
    "FREQcount": "1655"
  },
  {
    "Word": "reasons",
    "FREQcount": "1655"
  },
  {
    "Word": "post",
    "FREQcount": "1654"
  },
  {
    "Word": "confused",
    "FREQcount": "1653"
  },
  {
    "Word": "william",
    "FREQcount": "1653"
  },
  {
    "Word": "unfortunately",
    "FREQcount": "1652"
  },
  {
    "Word": "surgery",
    "FREQcount": "1651"
  },
  {
    "Word": "telephone",
    "FREQcount": "1651"
  },
  {
    "Word": "contract",
    "FREQcount": "1650"
  },
  {
    "Word": "safety",
    "FREQcount": "1649"
  },
  {
    "Word": "tall",
    "FREQcount": "1649"
  },
  {
    "Word": "fixed",
    "FREQcount": "1647"
  },
  {
    "Word": "professional",
    "FREQcount": "1646"
  },
  {
    "Word": "lesson",
    "FREQcount": "1644"
  },
  {
    "Word": "assistant",
    "FREQcount": "1643"
  },
  {
    "Word": "tiny",
    "FREQcount": "1643"
  },
  {
    "Word": "points",
    "FREQcount": "1642"
  },
  {
    "Word": "freeze",
    "FREQcount": "1640"
  },
  {
    "Word": "understood",
    "FREQcount": "1639"
  },
  {
    "Word": "runs",
    "FREQcount": "1637"
  },
  {
    "Word": "thomas",
    "FREQcount": "1636"
  },
  {
    "Word": "license",
    "FREQcount": "1635"
  },
  {
    "Word": "model",
    "FREQcount": "1635"
  },
  {
    "Word": "gate",
    "FREQcount": "1634"
  },
  {
    "Word": "margaret",
    "FREQcount": "1633"
  },
  {
    "Word": "soft",
    "FREQcount": "1633"
  },
  {
    "Word": "ear",
    "FREQcount": "1632"
  },
  {
    "Word": "riding",
    "FREQcount": "1632"
  },
  {
    "Word": "staff",
    "FREQcount": "1632"
  },
  {
    "Word": "warning",
    "FREQcount": "1630"
  },
  {
    "Word": "engine",
    "FREQcount": "1626"
  },
  {
    "Word": "german",
    "FREQcount": "1624"
  },
  {
    "Word": "planned",
    "FREQcount": "1624"
  },
  {
    "Word": "map",
    "FREQcount": "1623"
  },
  {
    "Word": "swim",
    "FREQcount": "1622"
  },
  {
    "Word": "harm",
    "FREQcount": "1621"
  },
  {
    "Word": "square",
    "FREQcount": "1620"
  },
  {
    "Word": "silver",
    "FREQcount": "1619"
  },
  {
    "Word": "sydney",
    "FREQcount": "1619"
  },
  {
    "Word": "brave",
    "FREQcount": "1617"
  },
  {
    "Word": "access",
    "FREQcount": "1615"
  },
  {
    "Word": "positive",
    "FREQcount": "1613"
  },
  {
    "Word": "covered",
    "FREQcount": "1612"
  },
  {
    "Word": "female",
    "FREQcount": "1612"
  },
  {
    "Word": "someplace",
    "FREQcount": "1611"
  },
  {
    "Word": "streets",
    "FREQcount": "1611"
  },
  {
    "Word": "blew",
    "FREQcount": "1610"
  },
  {
    "Word": "weak",
    "FREQcount": "1607"
  },
  {
    "Word": "season",
    "FREQcount": "1605"
  },
  {
    "Word": "matt",
    "FREQcount": "1604"
  },
  {
    "Word": "rush",
    "FREQcount": "1602"
  },
  {
    "Word": "awesome",
    "FREQcount": "1600"
  },
  {
    "Word": "snow",
    "FREQcount": "1599"
  },
  {
    "Word": "spring",
    "FREQcount": "1597"
  },
  {
    "Word": "champagne",
    "FREQcount": "1596"
  },
  {
    "Word": "spread",
    "FREQcount": "1596"
  },
  {
    "Word": "bond",
    "FREQcount": "1595"
  },
  {
    "Word": "mayor",
    "FREQcount": "1595"
  },
  {
    "Word": "pounds",
    "FREQcount": "1595"
  },
  {
    "Word": "demon",
    "FREQcount": "1593"
  },
  {
    "Word": "winner",
    "FREQcount": "1592"
  },
  {
    "Word": "madame",
    "FREQcount": "1591"
  },
  {
    "Word": "lips",
    "FREQcount": "1590"
  },
  {
    "Word": "leader",
    "FREQcount": "1589"
  },
  {
    "Word": "tongue",
    "FREQcount": "1589"
  },
  {
    "Word": "bath",
    "FREQcount": "1587"
  },
  {
    "Word": "permission",
    "FREQcount": "1587"
  },
  {
    "Word": "showing",
    "FREQcount": "1587"
  },
  {
    "Word": "mm",
    "FREQcount": "1586"
  },
  {
    "Word": "monsieur",
    "FREQcount": "1585"
  },
  {
    "Word": "mexico",
    "FREQcount": "1580"
  },
  {
    "Word": "jones",
    "FREQcount": "1579"
  },
  {
    "Word": "storm",
    "FREQcount": "1574"
  },
  {
    "Word": "destroyed",
    "FREQcount": "1573"
  },
  {
    "Word": "spare",
    "FREQcount": "1573"
  },
  {
    "Word": "tour",
    "FREQcount": "1571"
  },
  {
    "Word": "headed",
    "FREQcount": "1570"
  },
  {
    "Word": "trees",
    "FREQcount": "1565"
  },
  {
    "Word": "students",
    "FREQcount": "1564"
  },
  {
    "Word": "ends",
    "FREQcount": "1563"
  },
  {
    "Word": "bones",
    "FREQcount": "1561"
  },
  {
    "Word": "burning",
    "FREQcount": "1561"
  },
  {
    "Word": "appointment",
    "FREQcount": "1559"
  },
  {
    "Word": "kicked",
    "FREQcount": "1559"
  },
  {
    "Word": "mentioned",
    "FREQcount": "1556"
  },
  {
    "Word": "piper",
    "FREQcount": "1554"
  },
  {
    "Word": "claire",
    "FREQcount": "1552"
  },
  {
    "Word": "score",
    "FREQcount": "1552"
  },
  {
    "Word": "angeles",
    "FREQcount": "1551"
  },
  {
    "Word": "shoe",
    "FREQcount": "1550"
  },
  {
    "Word": "johnson",
    "FREQcount": "1546"
  },
  {
    "Word": "ocean",
    "FREQcount": "1545"
  },
  {
    "Word": "harder",
    "FREQcount": "1544"
  },
  {
    "Word": "reality",
    "FREQcount": "1543"
  },
  {
    "Word": "shape",
    "FREQcount": "1542"
  },
  {
    "Word": "brad",
    "FREQcount": "1541"
  },
  {
    "Word": "jeff",
    "FREQcount": "1539"
  },
  {
    "Word": "kim",
    "FREQcount": "1538"
  },
  {
    "Word": "gang",
    "FREQcount": "1537"
  },
  {
    "Word": "survive",
    "FREQcount": "1537"
  },
  {
    "Word": "saving",
    "FREQcount": "1536"
  },
  {
    "Word": "cos",
    "FREQcount": "1535"
  },
  {
    "Word": "style",
    "FREQcount": "1534"
  },
  {
    "Word": "farm",
    "FREQcount": "1532"
  },
  {
    "Word": "shopping",
    "FREQcount": "1530"
  },
  {
    "Word": "clearly",
    "FREQcount": "1529"
  },
  {
    "Word": "sexy",
    "FREQcount": "1529"
  },
  {
    "Word": "answers",
    "FREQcount": "1527"
  },
  {
    "Word": "example",
    "FREQcount": "1527"
  },
  {
    "Word": "growing",
    "FREQcount": "1527"
  },
  {
    "Word": "laid",
    "FREQcount": "1527"
  },
  {
    "Word": "gosh",
    "FREQcount": "1525"
  },
  {
    "Word": "rings",
    "FREQcount": "1524"
  },
  {
    "Word": "alarm",
    "FREQcount": "1522"
  },
  {
    "Word": "plays",
    "FREQcount": "1521"
  },
  {
    "Word": "screwed",
    "FREQcount": "1519"
  },
  {
    "Word": "fortune",
    "FREQcount": "1518"
  },
  {
    "Word": "schedule",
    "FREQcount": "1518"
  },
  {
    "Word": "bleeding",
    "FREQcount": "1516"
  },
  {
    "Word": "enter",
    "FREQcount": "1516"
  },
  {
    "Word": "punch",
    "FREQcount": "1514"
  },
  {
    "Word": "ended",
    "FREQcount": "1511"
  },
  {
    "Word": "patients",
    "FREQcount": "1511"
  },
  {
    "Word": "rights",
    "FREQcount": "1510"
  },
  {
    "Word": "invite",
    "FREQcount": "1509"
  },
  {
    "Word": "obvious",
    "FREQcount": "1508"
  },
  {
    "Word": "charges",
    "FREQcount": "1506"
  },
  {
    "Word": "interview",
    "FREQcount": "1505"
  },
  {
    "Word": "touched",
    "FREQcount": "1505"
  },
  {
    "Word": "affair",
    "FREQcount": "1502"
  },
  {
    "Word": "parts",
    "FREQcount": "1501"
  },
  {
    "Word": "russian",
    "FREQcount": "1501"
  },
  {
    "Word": "unbelievable",
    "FREQcount": "1500"
  },
  {
    "Word": "wherever",
    "FREQcount": "1500"
  },
  {
    "Word": "chocolate",
    "FREQcount": "1499"
  },
  {
    "Word": "focus",
    "FREQcount": "1499"
  },
  {
    "Word": "sue",
    "FREQcount": "1498"
  },
  {
    "Word": "borrow",
    "FREQcount": "1495"
  },
  {
    "Word": "grade",
    "FREQcount": "1493"
  },
  {
    "Word": "grew",
    "FREQcount": "1493"
  },
  {
    "Word": "finds",
    "FREQcount": "1492"
  },
  {
    "Word": "cole",
    "FREQcount": "1491"
  },
  {
    "Word": "investigation",
    "FREQcount": "1491"
  },
  {
    "Word": "mate",
    "FREQcount": "1491"
  },
  {
    "Word": "statement",
    "FREQcount": "1491"
  },
  {
    "Word": "load",
    "FREQcount": "1490"
  },
  {
    "Word": "painting",
    "FREQcount": "1489"
  },
  {
    "Word": "throwing",
    "FREQcount": "1488"
  },
  {
    "Word": "community",
    "FREQcount": "1486"
  },
  {
    "Word": "ross",
    "FREQcount": "1486"
  },
  {
    "Word": "loss",
    "FREQcount": "1485"
  },
  {
    "Word": "waited",
    "FREQcount": "1485"
  },
  {
    "Word": "barely",
    "FREQcount": "1482"
  },
  {
    "Word": "woods",
    "FREQcount": "1482"
  },
  {
    "Word": "changes",
    "FREQcount": "1481"
  },
  {
    "Word": "details",
    "FREQcount": "1481"
  },
  {
    "Word": "yourselves",
    "FREQcount": "1479"
  },
  {
    "Word": "exist",
    "FREQcount": "1477"
  },
  {
    "Word": "toilet",
    "FREQcount": "1474"
  },
  {
    "Word": "chances",
    "FREQcount": "1472"
  },
  {
    "Word": "drove",
    "FREQcount": "1472"
  },
  {
    "Word": "meal",
    "FREQcount": "1472"
  },
  {
    "Word": "dump",
    "FREQcount": "1470"
  },
  {
    "Word": "disappeared",
    "FREQcount": "1469"
  },
  {
    "Word": "member",
    "FREQcount": "1468"
  },
  {
    "Word": "shock",
    "FREQcount": "1468"
  },
  {
    "Word": "discovered",
    "FREQcount": "1467"
  },
  {
    "Word": "failed",
    "FREQcount": "1467"
  },
  {
    "Word": "pie",
    "FREQcount": "1466"
  },
  {
    "Word": "carol",
    "FREQcount": "1465"
  },
  {
    "Word": "crash",
    "FREQcount": "1461"
  },
  {
    "Word": "martha",
    "FREQcount": "1461"
  },
  {
    "Word": "artist",
    "FREQcount": "1460"
  },
  {
    "Word": "sat",
    "FREQcount": "1459"
  },
  {
    "Word": "theory",
    "FREQcount": "1459"
  },
  {
    "Word": "depends",
    "FREQcount": "1457"
  },
  {
    "Word": "bags",
    "FREQcount": "1456"
  },
  {
    "Word": "joy",
    "FREQcount": "1456"
  },
  {
    "Word": "pleased",
    "FREQcount": "1455"
  },
  {
    "Word": "ruin",
    "FREQcount": "1455"
  },
  {
    "Word": "kissed",
    "FREQcount": "1454"
  },
  {
    "Word": "traffic",
    "FREQcount": "1454"
  },
  {
    "Word": "nonsense",
    "FREQcount": "1452"
  },
  {
    "Word": "pink",
    "FREQcount": "1452"
  },
  {
    "Word": "wise",
    "FREQcount": "1452"
  },
  {
    "Word": "carrying",
    "FREQcount": "1451"
  },
  {
    "Word": "burned",
    "FREQcount": "1448"
  },
  {
    "Word": "laura",
    "FREQcount": "1448"
  },
  {
    "Word": "midnight",
    "FREQcount": "1447"
  },
  {
    "Word": "shots",
    "FREQcount": "1447"
  },
  {
    "Word": "deliver",
    "FREQcount": "1446"
  },
  {
    "Word": "bread",
    "FREQcount": "1445"
  },
  {
    "Word": "officers",
    "FREQcount": "1442"
  },
  {
    "Word": "button",
    "FREQcount": "1441"
  },
  {
    "Word": "dealing",
    "FREQcount": "1440"
  },
  {
    "Word": "mac",
    "FREQcount": "1440"
  },
  {
    "Word": "original",
    "FREQcount": "1440"
  },
  {
    "Word": "hated",
    "FREQcount": "1439"
  },
  {
    "Word": "eve",
    "FREQcount": "1437"
  },
  {
    "Word": "source",
    "FREQcount": "1437"
  },
  {
    "Word": "cases",
    "FREQcount": "1436"
  },
  {
    "Word": "hung",
    "FREQcount": "1436"
  },
  {
    "Word": "received",
    "FREQcount": "1436"
  },
  {
    "Word": "subtitles",
    "FREQcount": "1435"
  },
  {
    "Word": "charming",
    "FREQcount": "1434"
  },
  {
    "Word": "switch",
    "FREQcount": "1434"
  },
  {
    "Word": "decent",
    "FREQcount": "1433"
  },
  {
    "Word": "nah",
    "FREQcount": "1433"
  },
  {
    "Word": "below",
    "FREQcount": "1430"
  },
  {
    "Word": "texas",
    "FREQcount": "1429"
  },
  {
    "Word": "desert",
    "FREQcount": "1427"
  },
  {
    "Word": "hollywood",
    "FREQcount": "1427"
  },
  {
    "Word": "process",
    "FREQcount": "1427"
  },
  {
    "Word": "expensive",
    "FREQcount": "1425"
  },
  {
    "Word": "belongs",
    "FREQcount": "1423"
  },
  {
    "Word": "particular",
    "FREQcount": "1423"
  },
  {
    "Word": "higher",
    "FREQcount": "1420"
  },
  {
    "Word": "moves",
    "FREQcount": "1420"
  },
  {
    "Word": "breathing",
    "FREQcount": "1417"
  },
  {
    "Word": "grandmother",
    "FREQcount": "1417"
  },
  {
    "Word": "lower",
    "FREQcount": "1417"
  },
  {
    "Word": "period",
    "FREQcount": "1417"
  },
  {
    "Word": "h",
    "FREQcount": "1414"
  },
  {
    "Word": "pride",
    "FREQcount": "1411"
  },
  {
    "Word": "dollar",
    "FREQcount": "1410"
  },
  {
    "Word": "thousands",
    "FREQcount": "1410"
  },
  {
    "Word": "witch",
    "FREQcount": "1410"
  },
  {
    "Word": "soldiers",
    "FREQcount": "1409"
  },
  {
    "Word": "tip",
    "FREQcount": "1409"
  },
  {
    "Word": "jobs",
    "FREQcount": "1408"
  },
  {
    "Word": "plant",
    "FREQcount": "1408"
  },
  {
    "Word": "sports",
    "FREQcount": "1407"
  },
  {
    "Word": "surely",
    "FREQcount": "1407"
  },
  {
    "Word": "bust",
    "FREQcount": "1406"
  },
  {
    "Word": "birth",
    "FREQcount": "1405"
  },
  {
    "Word": "including",
    "FREQcount": "1405"
  },
  {
    "Word": "joint",
    "FREQcount": "1405"
  },
  {
    "Word": "logan",
    "FREQcount": "1404"
  },
  {
    "Word": "bull",
    "FREQcount": "1403"
  },
  {
    "Word": "wire",
    "FREQcount": "1403"
  },
  {
    "Word": "brains",
    "FREQcount": "1401"
  },
  {
    "Word": "rise",
    "FREQcount": "1399"
  },
  {
    "Word": "towards",
    "FREQcount": "1399"
  },
  {
    "Word": "boring",
    "FREQcount": "1398"
  },
  {
    "Word": "karen",
    "FREQcount": "1397"
  },
  {
    "Word": "ashamed",
    "FREQcount": "1396"
  },
  {
    "Word": "lt",
    "FREQcount": "1396"
  },
  {
    "Word": "sisters",
    "FREQcount": "1395"
  },
  {
    "Word": "section",
    "FREQcount": "1394"
  },
  {
    "Word": "v",
    "FREQcount": "1394"
  },
  {
    "Word": "facts",
    "FREQcount": "1393"
  },
  {
    "Word": "carl",
    "FREQcount": "1391"
  },
  {
    "Word": "clever",
    "FREQcount": "1391"
  },
  {
    "Word": "smells",
    "FREQcount": "1391"
  },
  {
    "Word": "honestly",
    "FREQcount": "1390"
  },
  {
    "Word": "success",
    "FREQcount": "1390"
  },
  {
    "Word": "garage",
    "FREQcount": "1388"
  },
  {
    "Word": "connection",
    "FREQcount": "1386"
  },
  {
    "Word": "filled",
    "FREQcount": "1386"
  },
  {
    "Word": "physical",
    "FREQcount": "1386"
  },
  {
    "Word": "complicated",
    "FREQcount": "1385"
  },
  {
    "Word": "pulling",
    "FREQcount": "1384"
  },
  {
    "Word": "regret",
    "FREQcount": "1384"
  },
  {
    "Word": "closet",
    "FREQcount": "1381"
  },
  {
    "Word": "loser",
    "FREQcount": "1381"
  },
  {
    "Word": "france",
    "FREQcount": "1380"
  },
  {
    "Word": "giant",
    "FREQcount": "1380"
  },
  {
    "Word": "wheel",
    "FREQcount": "1380"
  },
  {
    "Word": "parking",
    "FREQcount": "1379"
  },
  {
    "Word": "policy",
    "FREQcount": "1378"
  },
  {
    "Word": "twenty",
    "FREQcount": "1378"
  },
  {
    "Word": "stranger",
    "FREQcount": "1377"
  },
  {
    "Word": "tear",
    "FREQcount": "1377"
  },
  {
    "Word": "wood",
    "FREQcount": "1377"
  },
  {
    "Word": "fate",
    "FREQcount": "1375"
  },
  {
    "Word": "maggie",
    "FREQcount": "1372"
  },
  {
    "Word": "juice",
    "FREQcount": "1371"
  },
  {
    "Word": "lily",
    "FREQcount": "1370"
  },
  {
    "Word": "governor",
    "FREQcount": "1369"
  },
  {
    "Word": "europe",
    "FREQcount": "1368"
  },
  {
    "Word": "knight",
    "FREQcount": "1365"
  },
  {
    "Word": "tied",
    "FREQcount": "1364"
  },
  {
    "Word": "faces",
    "FREQcount": "1363"
  },
  {
    "Word": "awake",
    "FREQcount": "1362"
  },
  {
    "Word": "fought",
    "FREQcount": "1362"
  },
  {
    "Word": "kitty",
    "FREQcount": "1362"
  },
  {
    "Word": "coast",
    "FREQcount": "1361"
  },
  {
    "Word": "pilot",
    "FREQcount": "1360"
  },
  {
    "Word": "miracle",
    "FREQcount": "1359"
  },
  {
    "Word": "aboard",
    "FREQcount": "1358"
  },
  {
    "Word": "files",
    "FREQcount": "1358"
  },
  {
    "Word": "lover",
    "FREQcount": "1358"
  },
  {
    "Word": "based",
    "FREQcount": "1357"
  },
  {
    "Word": "cigarette",
    "FREQcount": "1357"
  },
  {
    "Word": "disgusting",
    "FREQcount": "1357"
  },
  {
    "Word": "grateful",
    "FREQcount": "1355"
  },
  {
    "Word": "mighty",
    "FREQcount": "1355"
  },
  {
    "Word": "murderer",
    "FREQcount": "1355"
  },
  {
    "Word": "garden",
    "FREQcount": "1354"
  },
  {
    "Word": "watched",
    "FREQcount": "1353"
  },
  {
    "Word": "wound",
    "FREQcount": "1353"
  },
  {
    "Word": "alice",
    "FREQcount": "1352"
  },
  {
    "Word": "sally",
    "FREQcount": "1352"
  },
  {
    "Word": "linda",
    "FREQcount": "1350"
  },
  {
    "Word": "drag",
    "FREQcount": "1349"
  },
  {
    "Word": "forced",
    "FREQcount": "1349"
  },
  {
    "Word": "fourth",
    "FREQcount": "1349"
  },
  {
    "Word": "marie",
    "FREQcount": "1348"
  },
  {
    "Word": "scream",
    "FREQcount": "1347"
  },
  {
    "Word": "event",
    "FREQcount": "1345"
  },
  {
    "Word": "woke",
    "FREQcount": "1344"
  },
  {
    "Word": "actor",
    "FREQcount": "1343"
  },
  {
    "Word": "row",
    "FREQcount": "1343"
  },
  {
    "Word": "grave",
    "FREQcount": "1340"
  },
  {
    "Word": "changing",
    "FREQcount": "1339"
  },
  {
    "Word": "senior",
    "FREQcount": "1339"
  },
  {
    "Word": "curious",
    "FREQcount": "1337"
  },
  {
    "Word": "flat",
    "FREQcount": "1337"
  },
  {
    "Word": "winter",
    "FREQcount": "1337"
  },
  {
    "Word": "badly",
    "FREQcount": "1336"
  },
  {
    "Word": "priest",
    "FREQcount": "1336"
  },
  {
    "Word": "rick",
    "FREQcount": "1336"
  },
  {
    "Word": "scary",
    "FREQcount": "1336"
  },
  {
    "Word": "shoulder",
    "FREQcount": "1336"
  },
  {
    "Word": "super",
    "FREQcount": "1336"
  },
  {
    "Word": "disease",
    "FREQcount": "1335"
  },
  {
    "Word": "sword",
    "FREQcount": "1335"
  },
  {
    "Word": "chick",
    "FREQcount": "1334"
  },
  {
    "Word": "smoking",
    "FREQcount": "1334"
  },
  {
    "Word": "closing",
    "FREQcount": "1333"
  },
  {
    "Word": "offered",
    "FREQcount": "1333"
  },
  {
    "Word": "concern",
    "FREQcount": "1332"
  },
  {
    "Word": "talent",
    "FREQcount": "1332"
  },
  {
    "Word": "garbage",
    "FREQcount": "1331"
  },
  {
    "Word": "attitude",
    "FREQcount": "1330"
  },
  {
    "Word": "mostly",
    "FREQcount": "1330"
  },
  {
    "Word": "bone",
    "FREQcount": "1329"
  },
  {
    "Word": "egg",
    "FREQcount": "1328"
  },
  {
    "Word": "friendly",
    "FREQcount": "1328"
  },
  {
    "Word": "recently",
    "FREQcount": "1328"
  },
  {
    "Word": "basically",
    "FREQcount": "1327"
  },
  {
    "Word": "engaged",
    "FREQcount": "1327"
  },
  {
    "Word": "quarter",
    "FREQcount": "1327"
  },
  {
    "Word": "thee",
    "FREQcount": "1327"
  },
  {
    "Word": "rooms",
    "FREQcount": "1326"
  },
  {
    "Word": "amen",
    "FREQcount": "1325"
  },
  {
    "Word": "passing",
    "FREQcount": "1325"
  },
  {
    "Word": "swing",
    "FREQcount": "1325"
  },
  {
    "Word": "available",
    "FREQcount": "1323"
  },
  {
    "Word": "louis",
    "FREQcount": "1321"
  },
  {
    "Word": "marshall",
    "FREQcount": "1321"
  },
  {
    "Word": "bike",
    "FREQcount": "1320"
  },
  {
    "Word": "birds",
    "FREQcount": "1320"
  },
  {
    "Word": "knees",
    "FREQcount": "1320"
  },
  {
    "Word": "slip",
    "FREQcount": "1320"
  },
  {
    "Word": "hunt",
    "FREQcount": "1319"
  },
  {
    "Word": "caused",
    "FREQcount": "1318"
  },
  {
    "Word": "taxi",
    "FREQcount": "1318"
  },
  {
    "Word": "stood",
    "FREQcount": "1315"
  },
  {
    "Word": "likely",
    "FREQcount": "1314"
  },
  {
    "Word": "object",
    "FREQcount": "1314"
  },
  {
    "Word": "hates",
    "FREQcount": "1313"
  },
  {
    "Word": "percent",
    "FREQcount": "1313"
  },
  {
    "Word": "pierce",
    "FREQcount": "1313"
  },
  {
    "Word": "japanese",
    "FREQcount": "1312"
  },
  {
    "Word": "raised",
    "FREQcount": "1312"
  },
  {
    "Word": "guests",
    "FREQcount": "1311"
  },
  {
    "Word": "desperate",
    "FREQcount": "1310"
  },
  {
    "Word": "dirt",
    "FREQcount": "1310"
  },
  {
    "Word": "navy",
    "FREQcount": "1310"
  },
  {
    "Word": "pussy",
    "FREQcount": "1309"
  },
  {
    "Word": "negative",
    "FREQcount": "1308"
  },
  {
    "Word": "plate",
    "FREQcount": "1308"
  },
  {
    "Word": "cooking",
    "FREQcount": "1307"
  },
  {
    "Word": "data",
    "FREQcount": "1306"
  },
  {
    "Word": "distance",
    "FREQcount": "1306"
  },
  {
    "Word": "tank",
    "FREQcount": "1306"
  },
  {
    "Word": "request",
    "FREQcount": "1304"
  },
  {
    "Word": "golf",
    "FREQcount": "1302"
  },
  {
    "Word": "hire",
    "FREQcount": "1302"
  },
  {
    "Word": "knowledge",
    "FREQcount": "1302"
  },
  {
    "Word": "ruined",
    "FREQcount": "1302"
  },
  {
    "Word": "cow",
    "FREQcount": "1301"
  },
  {
    "Word": "dawn",
    "FREQcount": "1301"
  },
  {
    "Word": "falls",
    "FREQcount": "1301"
  },
  {
    "Word": "pissed",
    "FREQcount": "1300"
  },
  {
    "Word": "stock",
    "FREQcount": "1300"
  },
  {
    "Word": "equipment",
    "FREQcount": "1298"
  },
  {
    "Word": "ann",
    "FREQcount": "1296"
  },
  {
    "Word": "conference",
    "FREQcount": "1296"
  },
  {
    "Word": "reports",
    "FREQcount": "1296"
  },
  {
    "Word": "rescue",
    "FREQcount": "1296"
  },
  {
    "Word": "claim",
    "FREQcount": "1295"
  },
  {
    "Word": "holmes",
    "FREQcount": "1295"
  },
  {
    "Word": "sale",
    "FREQcount": "1295"
  },
  {
    "Word": "audience",
    "FREQcount": "1294"
  },
  {
    "Word": "silence",
    "FREQcount": "1294"
  },
  {
    "Word": "americans",
    "FREQcount": "1293"
  },
  {
    "Word": "warn",
    "FREQcount": "1293"
  },
  {
    "Word": "hank",
    "FREQcount": "1291"
  },
  {
    "Word": "mercy",
    "FREQcount": "1291"
  },
  {
    "Word": "jesse",
    "FREQcount": "1290"
  },
  {
    "Word": "create",
    "FREQcount": "1289"
  },
  {
    "Word": "francisco",
    "FREQcount": "1289"
  },
  {
    "Word": "proper",
    "FREQcount": "1289"
  },
  {
    "Word": "universe",
    "FREQcount": "1289"
  },
  {
    "Word": "baseball",
    "FREQcount": "1288"
  },
  {
    "Word": "harold",
    "FREQcount": "1286"
  },
  {
    "Word": "hercules",
    "FREQcount": "1285"
  },
  {
    "Word": "soup",
    "FREQcount": "1285"
  },
  {
    "Word": "british",
    "FREQcount": "1283"
  },
  {
    "Word": "outfit",
    "FREQcount": "1280"
  },
  {
    "Word": "slowly",
    "FREQcount": "1279"
  },
  {
    "Word": "yard",
    "FREQcount": "1278"
  },
  {
    "Word": "drew",
    "FREQcount": "1277"
  },
  {
    "Word": "duke",
    "FREQcount": "1277"
  },
  {
    "Word": "jackie",
    "FREQcount": "1276"
  },
  {
    "Word": "grown",
    "FREQcount": "1275"
  },
  {
    "Word": "loving",
    "FREQcount": "1275"
  },
  {
    "Word": "valley",
    "FREQcount": "1275"
  },
  {
    "Word": "robin",
    "FREQcount": "1272"
  },
  {
    "Word": "pure",
    "FREQcount": "1271"
  },
  {
    "Word": "rate",
    "FREQcount": "1271"
  },
  {
    "Word": "bro",
    "FREQcount": "1270"
  },
  {
    "Word": "dies",
    "FREQcount": "1270"
  },
  {
    "Word": "celebrate",
    "FREQcount": "1268"
  },
  {
    "Word": "china",
    "FREQcount": "1268"
  },
  {
    "Word": "piano",
    "FREQcount": "1268"
  },
  {
    "Word": "simon",
    "FREQcount": "1268"
  },
  {
    "Word": "pills",
    "FREQcount": "1266"
  },
  {
    "Word": "uniform",
    "FREQcount": "1266"
  },
  {
    "Word": "stealing",
    "FREQcount": "1265"
  },
  {
    "Word": "spending",
    "FREQcount": "1264"
  },
  {
    "Word": "doll",
    "FREQcount": "1263"
  },
  {
    "Word": "duck",
    "FREQcount": "1263"
  },
  {
    "Word": "location",
    "FREQcount": "1263"
  },
  {
    "Word": "returned",
    "FREQcount": "1263"
  },
  {
    "Word": "amount",
    "FREQcount": "1262"
  },
  {
    "Word": "central",
    "FREQcount": "1262"
  },
  {
    "Word": "healthy",
    "FREQcount": "1262"
  },
  {
    "Word": "knocked",
    "FREQcount": "1261"
  },
  {
    "Word": "pen",
    "FREQcount": "1261"
  },
  {
    "Word": "reached",
    "FREQcount": "1261"
  },
  {
    "Word": "walls",
    "FREQcount": "1261"
  },
  {
    "Word": "steps",
    "FREQcount": "1259"
  },
  {
    "Word": "younger",
    "FREQcount": "1257"
  },
  {
    "Word": "attractive",
    "FREQcount": "1256"
  },
  {
    "Word": "notes",
    "FREQcount": "1255"
  },
  {
    "Word": "fail",
    "FREQcount": "1254"
  },
  {
    "Word": "beast",
    "FREQcount": "1252"
  },
  {
    "Word": "path",
    "FREQcount": "1252"
  },
  {
    "Word": "poison",
    "FREQcount": "1252"
  },
  {
    "Word": "wanting",
    "FREQcount": "1251"
  },
  {
    "Word": "naturally",
    "FREQcount": "1250"
  },
  {
    "Word": "happiness",
    "FREQcount": "1249"
  },
  {
    "Word": "anytime",
    "FREQcount": "1248"
  },
  {
    "Word": "gary",
    "FREQcount": "1248"
  },
  {
    "Word": "sucks",
    "FREQcount": "1248"
  },
  {
    "Word": "betty",
    "FREQcount": "1246"
  },
  {
    "Word": "eventually",
    "FREQcount": "1246"
  },
  {
    "Word": "channel",
    "FREQcount": "1245"
  },
  {
    "Word": "elevator",
    "FREQcount": "1245"
  },
  {
    "Word": "thy",
    "FREQcount": "1243"
  },
  {
    "Word": "belt",
    "FREQcount": "1242"
  },
  {
    "Word": "grandfather",
    "FREQcount": "1241"
  },
  {
    "Word": "secure",
    "FREQcount": "1241"
  },
  {
    "Word": "avoid",
    "FREQcount": "1239"
  },
  {
    "Word": "penny",
    "FREQcount": "1239"
  },
  {
    "Word": "laughs",
    "FREQcount": "1238"
  },
  {
    "Word": "thief",
    "FREQcount": "1238"
  },
  {
    "Word": "guards",
    "FREQcount": "1237"
  },
  {
    "Word": "bay",
    "FREQcount": "1236"
  },
  {
    "Word": "bride",
    "FREQcount": "1235"
  },
  {
    "Word": "pathetic",
    "FREQcount": "1234"
  },
  {
    "Word": "mirror",
    "FREQcount": "1233"
  },
  {
    "Word": "partners",
    "FREQcount": "1232"
  },
  {
    "Word": "thursday",
    "FREQcount": "1232"
  },
  {
    "Word": "becomes",
    "FREQcount": "1231"
  },
  {
    "Word": "dozen",
    "FREQcount": "1231"
  },
  {
    "Word": "ellen",
    "FREQcount": "1229"
  },
  {
    "Word": "kyle",
    "FREQcount": "1229"
  },
  {
    "Word": "direction",
    "FREQcount": "1228"
  },
  {
    "Word": "gorgeous",
    "FREQcount": "1227"
  },
  {
    "Word": "direct",
    "FREQcount": "1226"
  },
  {
    "Word": "odd",
    "FREQcount": "1226"
  },
  {
    "Word": "theater",
    "FREQcount": "1226"
  },
  {
    "Word": "boston",
    "FREQcount": "1225"
  },
  {
    "Word": "committed",
    "FREQcount": "1225"
  },
  {
    "Word": "led",
    "FREQcount": "1225"
  },
  {
    "Word": "march",
    "FREQcount": "1225"
  },
  {
    "Word": "members",
    "FREQcount": "1224"
  },
  {
    "Word": "morgan",
    "FREQcount": "1224"
  },
  {
    "Word": "official",
    "FREQcount": "1224"
  },
  {
    "Word": "puts",
    "FREQcount": "1224"
  },
  {
    "Word": "attacked",
    "FREQcount": "1219"
  },
  {
    "Word": "effect",
    "FREQcount": "1219"
  },
  {
    "Word": "tail",
    "FREQcount": "1219"
  },
  {
    "Word": "treated",
    "FREQcount": "1219"
  },
  {
    "Word": "pa",
    "FREQcount": "1218"
  },
  {
    "Word": "vision",
    "FREQcount": "1218"
  },
  {
    "Word": "secrets",
    "FREQcount": "1217"
  },
  {
    "Word": "dust",
    "FREQcount": "1216"
  },
  {
    "Word": "talks",
    "FREQcount": "1216"
  },
  {
    "Word": "trap",
    "FREQcount": "1216"
  },
  {
    "Word": "wide",
    "FREQcount": "1214"
  },
  {
    "Word": "honour",
    "FREQcount": "1213"
  },
  {
    "Word": "sharp",
    "FREQcount": "1213"
  },
  {
    "Word": "aside",
    "FREQcount": "1212"
  },
  {
    "Word": "deck",
    "FREQcount": "1212"
  },
  {
    "Word": "stairs",
    "FREQcount": "1212"
  },
  {
    "Word": "guts",
    "FREQcount": "1211"
  },
  {
    "Word": "extremely",
    "FREQcount": "1210"
  },
  {
    "Word": "lousy",
    "FREQcount": "1210"
  },
  {
    "Word": "unusual",
    "FREQcount": "1210"
  },
  {
    "Word": "newspaper",
    "FREQcount": "1208"
  },
  {
    "Word": "apple",
    "FREQcount": "1207"
  },
  {
    "Word": "courage",
    "FREQcount": "1207"
  },
  {
    "Word": "tuesday",
    "FREQcount": "1206"
  },
  {
    "Word": "terribly",
    "FREQcount": "1205"
  },
  {
    "Word": "fishing",
    "FREQcount": "1204"
  },
  {
    "Word": "piss",
    "FREQcount": "1203"
  },
  {
    "Word": "university",
    "FREQcount": "1203"
  },
  {
    "Word": "carefully",
    "FREQcount": "1202"
  },
  {
    "Word": "hitting",
    "FREQcount": "1200"
  },
  {
    "Word": "pulse",
    "FREQcount": "1200"
  },
  {
    "Word": "writer",
    "FREQcount": "1200"
  },
  {
    "Word": "edge",
    "FREQcount": "1199"
  },
  {
    "Word": "illegal",
    "FREQcount": "1199"
  },
  {
    "Word": "pity",
    "FREQcount": "1199"
  },
  {
    "Word": "couch",
    "FREQcount": "1197"
  },
  {
    "Word": "protection",
    "FREQcount": "1197"
  },
  {
    "Word": "tests",
    "FREQcount": "1197"
  },
  {
    "Word": "staring",
    "FREQcount": "1196"
  },
  {
    "Word": "victims",
    "FREQcount": "1196"
  },
  {
    "Word": "created",
    "FREQcount": "1195"
  },
  {
    "Word": "screen",
    "FREQcount": "1193"
  },
  {
    "Word": "appear",
    "FREQcount": "1192"
  },
  {
    "Word": "winning",
    "FREQcount": "1192"
  },
  {
    "Word": "precious",
    "FREQcount": "1191"
  },
  {
    "Word": "studio",
    "FREQcount": "1190"
  },
  {
    "Word": "windows",
    "FREQcount": "1190"
  },
  {
    "Word": "kissing",
    "FREQcount": "1189"
  },
  {
    "Word": "rob",
    "FREQcount": "1188"
  },
  {
    "Word": "golden",
    "FREQcount": "1187"
  },
  {
    "Word": "wilson",
    "FREQcount": "1187"
  },
  {
    "Word": "frightened",
    "FREQcount": "1186"
  },
  {
    "Word": "sandy",
    "FREQcount": "1186"
  },
  {
    "Word": "owner",
    "FREQcount": "1185"
  },
  {
    "Word": "royal",
    "FREQcount": "1185"
  },
  {
    "Word": "da",
    "FREQcount": "1183"
  },
  {
    "Word": "intend",
    "FREQcount": "1183"
  },
  {
    "Word": "considered",
    "FREQcount": "1182"
  },
  {
    "Word": "parties",
    "FREQcount": "1182"
  },
  {
    "Word": "burns",
    "FREQcount": "1180"
  },
  {
    "Word": "cast",
    "FREQcount": "1180"
  },
  {
    "Word": "prisoner",
    "FREQcount": "1180"
  },
  {
    "Word": "frasier",
    "FREQcount": "1179"
  },
  {
    "Word": "popular",
    "FREQcount": "1177"
  },
  {
    "Word": "destiny",
    "FREQcount": "1175"
  },
  {
    "Word": "robbery",
    "FREQcount": "1175"
  },
  {
    "Word": "federal",
    "FREQcount": "1173"
  },
  {
    "Word": "silent",
    "FREQcount": "1173"
  },
  {
    "Word": "violence",
    "FREQcount": "1173"
  },
  {
    "Word": "hearts",
    "FREQcount": "1172"
  },
  {
    "Word": "mystery",
    "FREQcount": "1171"
  },
  {
    "Word": "nerve",
    "FREQcount": "1171"
  },
  {
    "Word": "circumstances",
    "FREQcount": "1170"
  },
  {
    "Word": "library",
    "FREQcount": "1170"
  },
  {
    "Word": "toward",
    "FREQcount": "1169"
  },
  {
    "Word": "busted",
    "FREQcount": "1168"
  },
  {
    "Word": "becoming",
    "FREQcount": "1167"
  },
  {
    "Word": "rocks",
    "FREQcount": "1167"
  },
  {
    "Word": "embarrassing",
    "FREQcount": "1165"
  },
  {
    "Word": "miller",
    "FREQcount": "1165"
  },
  {
    "Word": "photo",
    "FREQcount": "1165"
  },
  {
    "Word": "practically",
    "FREQcount": "1165"
  },
  {
    "Word": "tower",
    "FREQcount": "1165"
  },
  {
    "Word": "armed",
    "FREQcount": "1164"
  },
  {
    "Word": "friendship",
    "FREQcount": "1164"
  },
  {
    "Word": "maid",
    "FREQcount": "1164"
  },
  {
    "Word": "shift",
    "FREQcount": "1164"
  },
  {
    "Word": "wallet",
    "FREQcount": "1163"
  },
  {
    "Word": "package",
    "FREQcount": "1162"
  },
  {
    "Word": "flower",
    "FREQcount": "1161"
  },
  {
    "Word": "range",
    "FREQcount": "1161"
  },
  {
    "Word": "beating",
    "FREQcount": "1160"
  },
  {
    "Word": "elizabeth",
    "FREQcount": "1160"
  },
  {
    "Word": "cheers",
    "FREQcount": "1158"
  },
  {
    "Word": "results",
    "FREQcount": "1158"
  },
  {
    "Word": "rope",
    "FREQcount": "1158"
  },
  {
    "Word": "steady",
    "FREQcount": "1158"
  },
  {
    "Word": "cleaning",
    "FREQcount": "1157"
  },
  {
    "Word": "barbara",
    "FREQcount": "1154"
  },
  {
    "Word": "exact",
    "FREQcount": "1154"
  },
  {
    "Word": "image",
    "FREQcount": "1154"
  },
  {
    "Word": "maria",
    "FREQcount": "1154"
  },
  {
    "Word": "turkey",
    "FREQcount": "1153"
  },
  {
    "Word": "vehicle",
    "FREQcount": "1153"
  },
  {
    "Word": "easily",
    "FREQcount": "1151"
  },
  {
    "Word": "jungle",
    "FREQcount": "1151"
  },
  {
    "Word": "nasty",
    "FREQcount": "1151"
  },
  {
    "Word": "pot",
    "FREQcount": "1149"
  },
  {
    "Word": "sensitive",
    "FREQcount": "1149"
  },
  {
    "Word": "suffer",
    "FREQcount": "1148"
  },
  {
    "Word": "millions",
    "FREQcount": "1147"
  },
  {
    "Word": "remembered",
    "FREQcount": "1146"
  },
  {
    "Word": "trash",
    "FREQcount": "1146"
  },
  {
    "Word": "thou",
    "FREQcount": "1144"
  },
  {
    "Word": "ambulance",
    "FREQcount": "1143"
  },
  {
    "Word": "behavior",
    "FREQcount": "1142"
  },
  {
    "Word": "nightmare",
    "FREQcount": "1142"
  },
  {
    "Word": "prize",
    "FREQcount": "1142"
  },
  {
    "Word": "per",
    "FREQcount": "1141"
  },
  {
    "Word": "snake",
    "FREQcount": "1140"
  },
  {
    "Word": "tears",
    "FREQcount": "1140"
  },
  {
    "Word": "cancer",
    "FREQcount": "1139"
  },
  {
    "Word": "families",
    "FREQcount": "1139"
  },
  {
    "Word": "orange",
    "FREQcount": "1138"
  },
  {
    "Word": "terms",
    "FREQcount": "1138"
  },
  {
    "Word": "foreign",
    "FREQcount": "1137"
  },
  {
    "Word": "media",
    "FREQcount": "1137"
  },
  {
    "Word": "donna",
    "FREQcount": "1136"
  },
  {
    "Word": "wasting",
    "FREQcount": "1135"
  },
  {
    "Word": "memories",
    "FREQcount": "1132"
  },
  {
    "Word": "songs",
    "FREQcount": "1132"
  },
  {
    "Word": "spanish",
    "FREQcount": "1130"
  },
  {
    "Word": "material",
    "FREQcount": "1129"
  },
  {
    "Word": "charlotte",
    "FREQcount": "1128"
  },
  {
    "Word": "expert",
    "FREQcount": "1128"
  },
  {
    "Word": "cutting",
    "FREQcount": "1126"
  },
  {
    "Word": "advantage",
    "FREQcount": "1125"
  },
  {
    "Word": "flesh",
    "FREQcount": "1125"
  },
  {
    "Word": "rude",
    "FREQcount": "1125"
  },
  {
    "Word": "disappointed",
    "FREQcount": "1124"
  },
  {
    "Word": "inspector",
    "FREQcount": "1124"
  },
  {
    "Word": "committee",
    "FREQcount": "1123"
  },
  {
    "Word": "guarantee",
    "FREQcount": "1123"
  },
  {
    "Word": "signs",
    "FREQcount": "1123"
  },
  {
    "Word": "terry",
    "FREQcount": "1123"
  },
  {
    "Word": "kinds",
    "FREQcount": "1121"
  },
  {
    "Word": "punk",
    "FREQcount": "1121"
  },
  {
    "Word": "downtown",
    "FREQcount": "1118"
  },
  {
    "Word": "sandwich",
    "FREQcount": "1118"
  },
  {
    "Word": "marks",
    "FREQcount": "1117"
  },
  {
    "Word": "understanding",
    "FREQcount": "1117"
  },
  {
    "Word": "daniel",
    "FREQcount": "1116"
  },
  {
    "Word": "mistakes",
    "FREQcount": "1116"
  },
  {
    "Word": "political",
    "FREQcount": "1115"
  },
  {
    "Word": "sweat",
    "FREQcount": "1115"
  },
  {
    "Word": "cents",
    "FREQcount": "1114"
  },
  {
    "Word": "panic",
    "FREQcount": "1114"
  },
  {
    "Word": "performance",
    "FREQcount": "1113"
  },
  {
    "Word": "plain",
    "FREQcount": "1113"
  },
  {
    "Word": "boom",
    "FREQcount": "1112"
  },
  {
    "Word": "stops",
    "FREQcount": "1112"
  },
  {
    "Word": "parker",
    "FREQcount": "1111"
  },
  {
    "Word": "union",
    "FREQcount": "1111"
  },
  {
    "Word": "seats",
    "FREQcount": "1110"
  },
  {
    "Word": "cable",
    "FREQcount": "1108"
  },
  {
    "Word": "fruit",
    "FREQcount": "1108"
  },
  {
    "Word": "hundreds",
    "FREQcount": "1108"
  },
  {
    "Word": "mum",
    "FREQcount": "1108"
  },
  {
    "Word": "objection",
    "FREQcount": "1108"
  },
  {
    "Word": "separate",
    "FREQcount": "1107"
  },
  {
    "Word": "kong",
    "FREQcount": "1106"
  },
  {
    "Word": "ancient",
    "FREQcount": "1105"
  },
  {
    "Word": "underwear",
    "FREQcount": "1105"
  },
  {
    "Word": "fox",
    "FREQcount": "1102"
  },
  {
    "Word": "lewis",
    "FREQcount": "1102"
  },
  {
    "Word": "moments",
    "FREQcount": "1101"
  },
  {
    "Word": "cliff",
    "FREQcount": "1100"
  },
  {
    "Word": "castle",
    "FREQcount": "1099"
  },
  {
    "Word": "rolling",
    "FREQcount": "1099"
  },
  {
    "Word": "setting",
    "FREQcount": "1099"
  },
  {
    "Word": "w",
    "FREQcount": "1099"
  },
  {
    "Word": "delicious",
    "FREQcount": "1098"
  },
  {
    "Word": "circle",
    "FREQcount": "1097"
  },
  {
    "Word": "value",
    "FREQcount": "1097"
  },
  {
    "Word": "bills",
    "FREQcount": "1096"
  },
  {
    "Word": "chuck",
    "FREQcount": "1096"
  },
  {
    "Word": "glory",
    "FREQcount": "1096"
  },
  {
    "Word": "miserable",
    "FREQcount": "1096"
  },
  {
    "Word": "squad",
    "FREQcount": "1096"
  },
  {
    "Word": "counting",
    "FREQcount": "1095"
  },
  {
    "Word": "manage",
    "FREQcount": "1095"
  },
  {
    "Word": "bowl",
    "FREQcount": "1094"
  },
  {
    "Word": "victory",
    "FREQcount": "1094"
  },
  {
    "Word": "zero",
    "FREQcount": "1094"
  },
  {
    "Word": "embarrassed",
    "FREQcount": "1093"
  },
  {
    "Word": "stands",
    "FREQcount": "1093"
  },
  {
    "Word": "willie",
    "FREQcount": "1093"
  },
  {
    "Word": "creature",
    "FREQcount": "1092"
  },
  {
    "Word": "basketball",
    "FREQcount": "1091"
  },
  {
    "Word": "deny",
    "FREQcount": "1091"
  },
  {
    "Word": "mixed",
    "FREQcount": "1090"
  },
  {
    "Word": "continues",
    "FREQcount": "1089"
  },
  {
    "Word": "route",
    "FREQcount": "1089"
  },
  {
    "Word": "bruce",
    "FREQcount": "1088"
  },
  {
    "Word": "nancy",
    "FREQcount": "1087"
  },
  {
    "Word": "rare",
    "FREQcount": "1087"
  },
  {
    "Word": "yelling",
    "FREQcount": "1087"
  },
  {
    "Word": "holiday",
    "FREQcount": "1086"
  },
  {
    "Word": "andrew",
    "FREQcount": "1085"
  },
  {
    "Word": "hidden",
    "FREQcount": "1085"
  },
  {
    "Word": "ill",
    "FREQcount": "1085"
  },
  {
    "Word": "directly",
    "FREQcount": "1084"
  },
  {
    "Word": "helps",
    "FREQcount": "1084"
  },
  {
    "Word": "progress",
    "FREQcount": "1084"
  },
  {
    "Word": "remove",
    "FREQcount": "1084"
  },
  {
    "Word": "wave",
    "FREQcount": "1084"
  },
  {
    "Word": "gods",
    "FREQcount": "1083"
  },
  {
    "Word": "authority",
    "FREQcount": "1082"
  },
  {
    "Word": "chain",
    "FREQcount": "1082"
  },
  {
    "Word": "emotional",
    "FREQcount": "1081"
  },
  {
    "Word": "highly",
    "FREQcount": "1081"
  },
  {
    "Word": "hunting",
    "FREQcount": "1081"
  },
  {
    "Word": "wore",
    "FREQcount": "1081"
  },
  {
    "Word": "shadow",
    "FREQcount": "1080"
  },
  {
    "Word": "false",
    "FREQcount": "1078"
  },
  {
    "Word": "jumped",
    "FREQcount": "1078"
  },
  {
    "Word": "gray",
    "FREQcount": "1077"
  },
  {
    "Word": "estate",
    "FREQcount": "1076"
  },
  {
    "Word": "skip",
    "FREQcount": "1076"
  },
  {
    "Word": "whore",
    "FREQcount": "1076"
  },
  {
    "Word": "horn",
    "FREQcount": "1075"
  },
  {
    "Word": "agents",
    "FREQcount": "1074"
  },
  {
    "Word": "appears",
    "FREQcount": "1074"
  },
  {
    "Word": "basement",
    "FREQcount": "1074"
  },
  {
    "Word": "jess",
    "FREQcount": "1074"
  },
  {
    "Word": "minds",
    "FREQcount": "1072"
  },
  {
    "Word": "pleasant",
    "FREQcount": "1072"
  },
  {
    "Word": "clients",
    "FREQcount": "1071"
  },
  {
    "Word": "mile",
    "FREQcount": "1071"
  },
  {
    "Word": "approach",
    "FREQcount": "1070"
  },
  {
    "Word": "refuse",
    "FREQcount": "1070"
  },
  {
    "Word": "disappear",
    "FREQcount": "1069"
  },
  {
    "Word": "bug",
    "FREQcount": "1068"
  },
  {
    "Word": "district",
    "FREQcount": "1068"
  },
  {
    "Word": "rabbit",
    "FREQcount": "1068"
  },
  {
    "Word": "speaks",
    "FREQcount": "1068"
  },
  {
    "Word": "champion",
    "FREQcount": "1067"
  },
  {
    "Word": "jeez",
    "FREQcount": "1067"
  },
  {
    "Word": "competition",
    "FREQcount": "1066"
  },
  {
    "Word": "proceed",
    "FREQcount": "1066"
  },
  {
    "Word": "stopping",
    "FREQcount": "1066"
  },
  {
    "Word": "watson",
    "FREQcount": "1066"
  },
  {
    "Word": "anne",
    "FREQcount": "1065"
  },
  {
    "Word": "forces",
    "FREQcount": "1064"
  },
  {
    "Word": "leading",
    "FREQcount": "1064"
  },
  {
    "Word": "presence",
    "FREQcount": "1064"
  },
  {
    "Word": "century",
    "FREQcount": "1063"
  },
  {
    "Word": "cure",
    "FREQcount": "1063"
  },
  {
    "Word": "rita",
    "FREQcount": "1063"
  },
  {
    "Word": "capable",
    "FREQcount": "1062"
  },
  {
    "Word": "convinced",
    "FREQcount": "1061"
  },
  {
    "Word": "swell",
    "FREQcount": "1061"
  },
  {
    "Word": "warrant",
    "FREQcount": "1060"
  },
  {
    "Word": "wayne",
    "FREQcount": "1060"
  },
  {
    "Word": "threat",
    "FREQcount": "1059"
  },
  {
    "Word": "therefore",
    "FREQcount": "1058"
  },
  {
    "Word": "zack",
    "FREQcount": "1056"
  },
  {
    "Word": "bury",
    "FREQcount": "1054"
  },
  {
    "Word": "ruth",
    "FREQcount": "1054"
  },
  {
    "Word": "april",
    "FREQcount": "1053"
  },
  {
    "Word": "diamond",
    "FREQcount": "1053"
  },
  {
    "Word": "services",
    "FREQcount": "1053"
  },
  {
    "Word": "shine",
    "FREQcount": "1053"
  },
  {
    "Word": "bat",
    "FREQcount": "1052"
  },
  {
    "Word": "monica",
    "FREQcount": "1052"
  },
  {
    "Word": "alert",
    "FREQcount": "1051"
  },
  {
    "Word": "chip",
    "FREQcount": "1051"
  },
  {
    "Word": "edward",
    "FREQcount": "1051"
  },
  {
    "Word": "x",
    "FREQcount": "1051"
  },
  {
    "Word": "jenny",
    "FREQcount": "1050"
  },
  {
    "Word": "transfer",
    "FREQcount": "1048"
  },
  {
    "Word": "sentence",
    "FREQcount": "1047"
  },
  {
    "Word": "thrown",
    "FREQcount": "1047"
  },
  {
    "Word": "fabulous",
    "FREQcount": "1046"
  },
  {
    "Word": "nation",
    "FREQcount": "1045"
  },
  {
    "Word": "pushed",
    "FREQcount": "1045"
  },
  {
    "Word": "butter",
    "FREQcount": "1042"
  },
  {
    "Word": "earl",
    "FREQcount": "1042"
  },
  {
    "Word": "jokes",
    "FREQcount": "1040"
  },
  {
    "Word": "reporter",
    "FREQcount": "1040"
  },
  {
    "Word": "booth",
    "FREQcount": "1039"
  },
  {
    "Word": "casino",
    "FREQcount": "1039"
  },
  {
    "Word": "josh",
    "FREQcount": "1039"
  },
  {
    "Word": "potter",
    "FREQcount": "1039"
  },
  {
    "Word": "successful",
    "FREQcount": "1037"
  },
  {
    "Word": "learning",
    "FREQcount": "1036"
  },
  {
    "Word": "awfully",
    "FREQcount": "1035"
  },
  {
    "Word": "possibility",
    "FREQcount": "1035"
  },
  {
    "Word": "sand",
    "FREQcount": "1035"
  },
  {
    "Word": "bow",
    "FREQcount": "1034"
  },
  {
    "Word": "cage",
    "FREQcount": "1034"
  },
  {
    "Word": "desire",
    "FREQcount": "1034"
  },
  {
    "Word": "nigger",
    "FREQcount": "1034"
  },
  {
    "Word": "wolf",
    "FREQcount": "1034"
  },
  {
    "Word": "units",
    "FREQcount": "1032"
  },
  {
    "Word": "wing",
    "FREQcount": "1032"
  },
  {
    "Word": "exchange",
    "FREQcount": "1031"
  },
  {
    "Word": "trapped",
    "FREQcount": "1030"
  },
  {
    "Word": "bored",
    "FREQcount": "1029"
  },
  {
    "Word": "pet",
    "FREQcount": "1029"
  },
  {
    "Word": "thin",
    "FREQcount": "1029"
  },
  {
    "Word": "drama",
    "FREQcount": "1028"
  },
  {
    "Word": "rip",
    "FREQcount": "1028"
  },
  {
    "Word": "series",
    "FREQcount": "1028"
  },
  {
    "Word": "hills",
    "FREQcount": "1027"
  },
  {
    "Word": "homework",
    "FREQcount": "1027"
  },
  {
    "Word": "carried",
    "FREQcount": "1026"
  },
  {
    "Word": "entirely",
    "FREQcount": "1026"
  },
  {
    "Word": "zone",
    "FREQcount": "1026"
  },
  {
    "Word": "explanation",
    "FREQcount": "1023"
  },
  {
    "Word": "spy",
    "FREQcount": "1023"
  },
  {
    "Word": "assure",
    "FREQcount": "1021"
  },
  {
    "Word": "failure",
    "FREQcount": "1021"
  },
  {
    "Word": "collect",
    "FREQcount": "1020"
  },
  {
    "Word": "hits",
    "FREQcount": "1020"
  },
  {
    "Word": "bang",
    "FREQcount": "1019"
  },
  {
    "Word": "joseph",
    "FREQcount": "1019"
  },
  {
    "Word": "swimming",
    "FREQcount": "1019"
  },
  {
    "Word": "launch",
    "FREQcount": "1018"
  },
  {
    "Word": "print",
    "FREQcount": "1018"
  },
  {
    "Word": "delivery",
    "FREQcount": "1017"
  },
  {
    "Word": "fever",
    "FREQcount": "1017"
  },
  {
    "Word": "jordan",
    "FREQcount": "1017"
  },
  {
    "Word": "journey",
    "FREQcount": "1017"
  },
  {
    "Word": "useless",
    "FREQcount": "1017"
  },
  {
    "Word": "photos",
    "FREQcount": "1016"
  },
  {
    "Word": "kills",
    "FREQcount": "1015"
  },
  {
    "Word": "sport",
    "FREQcount": "1015"
  },
  {
    "Word": "barry",
    "FREQcount": "1013"
  },
  {
    "Word": "challenge",
    "FREQcount": "1013"
  },
  {
    "Word": "loan",
    "FREQcount": "1013"
  },
  {
    "Word": "shore",
    "FREQcount": "1013"
  },
  {
    "Word": "routine",
    "FREQcount": "1012"
  },
  {
    "Word": "soda",
    "FREQcount": "1012"
  },
  {
    "Word": "spoken",
    "FREQcount": "1012"
  },
  {
    "Word": "clark",
    "FREQcount": "1010"
  },
  {
    "Word": "mask",
    "FREQcount": "1010"
  },
  {
    "Word": "teaching",
    "FREQcount": "1010"
  },
  {
    "Word": "teli",
    "FREQcount": "1010"
  },
  {
    "Word": "trunk",
    "FREQcount": "1010"
  },
  {
    "Word": "leads",
    "FREQcount": "1009"
  },
  {
    "Word": "passion",
    "FREQcount": "1008"
  },
  {
    "Word": "purse",
    "FREQcount": "1008"
  },
  {
    "Word": "result",
    "FREQcount": "1008"
  },
  {
    "Word": "argue",
    "FREQcount": "1007"
  },
  {
    "Word": "climb",
    "FREQcount": "1007"
  },
  {
    "Word": "served",
    "FREQcount": "1007"
  },
  {
    "Word": "seth",
    "FREQcount": "1007"
  },
  {
    "Word": "cats",
    "FREQcount": "1006"
  },
  {
    "Word": "beef",
    "FREQcount": "1005"
  },
  {
    "Word": "witnesses",
    "FREQcount": "1005"
  },
  {
    "Word": "barney",
    "FREQcount": "1003"
  },
  {
    "Word": "recall",
    "FREQcount": "1003"
  },
  {
    "Word": "wings",
    "FREQcount": "1003"
  },
  {
    "Word": "cabin",
    "FREQcount": "1002"
  },
  {
    "Word": "mental",
    "FREQcount": "1002"
  },
  {
    "Word": "ships",
    "FREQcount": "1002"
  },
  {
    "Word": "script",
    "FREQcount": "1000"
  },
  {
    "Word": "article",
    "FREQcount": "998"
  },
  {
    "Word": "solid",
    "FREQcount": "998"
  },
  {
    "Word": "vic",
    "FREQcount": "998"
  },
  {
    "Word": "education",
    "FREQcount": "996"
  },
  {
    "Word": "salt",
    "FREQcount": "995"
  },
  {
    "Word": "solve",
    "FREQcount": "994"
  },
  {
    "Word": "confidence",
    "FREQcount": "993"
  },
  {
    "Word": "frankly",
    "FREQcount": "992"
  },
  {
    "Word": "metal",
    "FREQcount": "992"
  },
  {
    "Word": "receive",
    "FREQcount": "992"
  },
  {
    "Word": "wounded",
    "FREQcount": "992"
  },
  {
    "Word": "agency",
    "FREQcount": "991"
  },
  {
    "Word": "anger",
    "FREQcount": "991"
  },
  {
    "Word": "escaped",
    "FREQcount": "991"
  },
  {
    "Word": "settled",
    "FREQcount": "991"
  },
  {
    "Word": "suffering",
    "FREQcount": "991"
  },
  {
    "Word": "detail",
    "FREQcount": "989"
  },
  {
    "Word": "pipe",
    "FREQcount": "989"
  },
  {
    "Word": "trace",
    "FREQcount": "989"
  },
  {
    "Word": "supper",
    "FREQcount": "988"
  },
  {
    "Word": "wins",
    "FREQcount": "988"
  },
  {
    "Word": "effort",
    "FREQcount": "987"
  },
  {
    "Word": "spit",
    "FREQcount": "987"
  },
  {
    "Word": "studying",
    "FREQcount": "987"
  },
  {
    "Word": "hug",
    "FREQcount": "986"
  },
  {
    "Word": "enemies",
    "FREQcount": "985"
  },
  {
    "Word": "treatment",
    "FREQcount": "985"
  },
  {
    "Word": "commit",
    "FREQcount": "984"
  },
  {
    "Word": "dragon",
    "FREQcount": "984"
  },
  {
    "Word": "intelligence",
    "FREQcount": "983"
  },
  {
    "Word": "reputation",
    "FREQcount": "983"
  },
  {
    "Word": "troops",
    "FREQcount": "983"
  },
  {
    "Word": "custody",
    "FREQcount": "982"
  },
  {
    "Word": "gimme",
    "FREQcount": "982"
  },
  {
    "Word": "ability",
    "FREQcount": "980"
  },
  {
    "Word": "site",
    "FREQcount": "980"
  },
  {
    "Word": "fifth",
    "FREQcount": "979"
  },
  {
    "Word": "palace",
    "FREQcount": "979"
  },
  {
    "Word": "trail",
    "FREQcount": "979"
  },
  {
    "Word": "pushing",
    "FREQcount": "978"
  },
  {
    "Word": "boots",
    "FREQcount": "977"
  },
  {
    "Word": "hop",
    "FREQcount": "977"
  },
  {
    "Word": "stays",
    "FREQcount": "977"
  },
  {
    "Word": "owns",
    "FREQcount": "976"
  },
  {
    "Word": "attempt",
    "FREQcount": "975"
  },
  {
    "Word": "houses",
    "FREQcount": "975"
  },
  {
    "Word": "lawyers",
    "FREQcount": "975"
  },
  {
    "Word": "mouse",
    "FREQcount": "975"
  },
  {
    "Word": "bout",
    "FREQcount": "974"
  },
  {
    "Word": "ease",
    "FREQcount": "974"
  },
  {
    "Word": "hurting",
    "FREQcount": "974"
  },
  {
    "Word": "stronger",
    "FREQcount": "974"
  },
  {
    "Word": "chloe",
    "FREQcount": "973"
  },
  {
    "Word": "considering",
    "FREQcount": "973"
  },
  {
    "Word": "ordinary",
    "FREQcount": "973"
  },
  {
    "Word": "presents",
    "FREQcount": "973"
  },
  {
    "Word": "customers",
    "FREQcount": "972"
  },
  {
    "Word": "impressed",
    "FREQcount": "972"
  },
  {
    "Word": "laundry",
    "FREQcount": "972"
  },
  {
    "Word": "ripped",
    "FREQcount": "972"
  },
  {
    "Word": "treasure",
    "FREQcount": "972"
  },
  {
    "Word": "revenge",
    "FREQcount": "971"
  },
  {
    "Word": "bravo",
    "FREQcount": "970"
  },
  {
    "Word": "odds",
    "FREQcount": "970"
  },
  {
    "Word": "tricks",
    "FREQcount": "969"
  },
  {
    "Word": "cowboy",
    "FREQcount": "968"
  },
  {
    "Word": "nuclear",
    "FREQcount": "968"
  },
  {
    "Word": "rome",
    "FREQcount": "968"
  },
  {
    "Word": "motion",
    "FREQcount": "967"
  },
  {
    "Word": "kirk",
    "FREQcount": "964"
  },
  {
    "Word": "mall",
    "FREQcount": "964"
  },
  {
    "Word": "virus",
    "FREQcount": "964"
  },
  {
    "Word": "forest",
    "FREQcount": "963"
  },
  {
    "Word": "reverend",
    "FREQcount": "963"
  },
  {
    "Word": "june",
    "FREQcount": "962"
  },
  {
    "Word": "noel",
    "FREQcount": "962"
  },
  {
    "Word": "sounded",
    "FREQcount": "962"
  },
  {
    "Word": "trained",
    "FREQcount": "962"
  },
  {
    "Word": "el",
    "FREQcount": "961"
  },
  {
    "Word": "scratch",
    "FREQcount": "961"
  },
  {
    "Word": "virgin",
    "FREQcount": "961"
  },
  {
    "Word": "breaks",
    "FREQcount": "960"
  },
  {
    "Word": "fifty",
    "FREQcount": "960"
  },
  {
    "Word": "potential",
    "FREQcount": "960"
  },
  {
    "Word": "twelve",
    "FREQcount": "960"
  },
  {
    "Word": "defend",
    "FREQcount": "959"
  },
  {
    "Word": "contest",
    "FREQcount": "958"
  },
  {
    "Word": "africa",
    "FREQcount": "957"
  },
  {
    "Word": "fashion",
    "FREQcount": "957"
  },
  {
    "Word": "plastic",
    "FREQcount": "957"
  },
  {
    "Word": "cap",
    "FREQcount": "956"
  },
  {
    "Word": "mickey",
    "FREQcount": "956"
  },
  {
    "Word": "convince",
    "FREQcount": "955"
  },
  {
    "Word": "interrupt",
    "FREQcount": "955"
  },
  {
    "Word": "latest",
    "FREQcount": "955"
  },
  {
    "Word": "lincoln",
    "FREQcount": "955"
  },
  {
    "Word": "issues",
    "FREQcount": "954"
  },
  {
    "Word": "joan",
    "FREQcount": "954"
  },
  {
    "Word": "arrive",
    "FREQcount": "953"
  },
  {
    "Word": "cheer",
    "FREQcount": "953"
  },
  {
    "Word": "catherine",
    "FREQcount": "952"
  },
  {
    "Word": "chose",
    "FREQcount": "952"
  },
  {
    "Word": "supply",
    "FREQcount": "952"
  },
  {
    "Word": "surveillance",
    "FREQcount": "952"
  },
  {
    "Word": "ignore",
    "FREQcount": "951"
  },
  {
    "Word": "mountains",
    "FREQcount": "951"
  },
  {
    "Word": "nail",
    "FREQcount": "951"
  },
  {
    "Word": "league",
    "FREQcount": "950"
  },
  {
    "Word": "vice",
    "FREQcount": "950"
  },
  {
    "Word": "albert",
    "FREQcount": "949"
  },
  {
    "Word": "figures",
    "FREQcount": "949"
  },
  {
    "Word": "joking",
    "FREQcount": "949"
  },
  {
    "Word": "stanley",
    "FREQcount": "949"
  },
  {
    "Word": "thanksgiving",
    "FREQcount": "949"
  },
  {
    "Word": "cheating",
    "FREQcount": "948"
  },
  {
    "Word": "coincidence",
    "FREQcount": "948"
  },
  {
    "Word": "coke",
    "FREQcount": "948"
  },
  {
    "Word": "favour",
    "FREQcount": "948"
  },
  {
    "Word": "loaded",
    "FREQcount": "948"
  },
  {
    "Word": "messages",
    "FREQcount": "948"
  },
  {
    "Word": "quality",
    "FREQcount": "947"
  },
  {
    "Word": "title",
    "FREQcount": "947"
  },
  {
    "Word": "bunny",
    "FREQcount": "946"
  },
  {
    "Word": "division",
    "FREQcount": "946"
  },
  {
    "Word": "impression",
    "FREQcount": "946"
  },
  {
    "Word": "particularly",
    "FREQcount": "946"
  },
  {
    "Word": "reasonable",
    "FREQcount": "946"
  },
  {
    "Word": "vincent",
    "FREQcount": "946"
  },
  {
    "Word": "tiger",
    "FREQcount": "945"
  },
  {
    "Word": "se",
    "FREQcount": "944"
  },
  {
    "Word": "therapy",
    "FREQcount": "944"
  },
  {
    "Word": "bastards",
    "FREQcount": "943"
  },
  {
    "Word": "museum",
    "FREQcount": "942"
  },
  {
    "Word": "minister",
    "FREQcount": "941"
  },
  {
    "Word": "steel",
    "FREQcount": "941"
  },
  {
    "Word": "bound",
    "FREQcount": "940"
  },
  {
    "Word": "slave",
    "FREQcount": "940"
  },
  {
    "Word": "standard",
    "FREQcount": "940"
  },
  {
    "Word": "wishes",
    "FREQcount": "940"
  },
  {
    "Word": "anniversary",
    "FREQcount": "939"
  },
  {
    "Word": "dreaming",
    "FREQcount": "939"
  },
  {
    "Word": "yell",
    "FREQcount": "939"
  },
  {
    "Word": "florida",
    "FREQcount": "938"
  },
  {
    "Word": "firing",
    "FREQcount": "937"
  },
  {
    "Word": "reminds",
    "FREQcount": "937"
  },
  {
    "Word": "shy",
    "FREQcount": "937"
  },
  {
    "Word": "cruel",
    "FREQcount": "936"
  },
  {
    "Word": "hunter",
    "FREQcount": "936"
  },
  {
    "Word": "walks",
    "FREQcount": "936"
  },
  {
    "Word": "bible",
    "FREQcount": "935"
  },
  {
    "Word": "seek",
    "FREQcount": "934"
  },
  {
    "Word": "cancel",
    "FREQcount": "933"
  },
  {
    "Word": "chasing",
    "FREQcount": "933"
  },
  {
    "Word": "las",
    "FREQcount": "933"
  },
  {
    "Word": "pat",
    "FREQcount": "933"
  },
  {
    "Word": "prime",
    "FREQcount": "933"
  },
  {
    "Word": "former",
    "FREQcount": "932"
  },
  {
    "Word": "smooth",
    "FREQcount": "932"
  },
  {
    "Word": "socks",
    "FREQcount": "932"
  },
  {
    "Word": "wednesday",
    "FREQcount": "932"
  },
  {
    "Word": "dates",
    "FREQcount": "931"
  },
  {
    "Word": "judy",
    "FREQcount": "930"
  },
  {
    "Word": "modern",
    "FREQcount": "930"
  },
  {
    "Word": "surface",
    "FREQcount": "930"
  },
  {
    "Word": "curse",
    "FREQcount": "929"
  },
  {
    "Word": "lifetime",
    "FREQcount": "929"
  },
  {
    "Word": "role",
    "FREQcount": "929"
  },
  {
    "Word": "chosen",
    "FREQcount": "927"
  },
  {
    "Word": "eaten",
    "FREQcount": "927"
  },
  {
    "Word": "gym",
    "FREQcount": "927"
  },
  {
    "Word": "motel",
    "FREQcount": "927"
  },
  {
    "Word": "christopher",
    "FREQcount": "926"
  },
  {
    "Word": "collection",
    "FREQcount": "926"
  },
  {
    "Word": "device",
    "FREQcount": "926"
  },
  {
    "Word": "enjoyed",
    "FREQcount": "926"
  },
  {
    "Word": "russell",
    "FREQcount": "926"
  },
  {
    "Word": "heck",
    "FREQcount": "925"
  },
  {
    "Word": "pee",
    "FREQcount": "925"
  },
  {
    "Word": "hong",
    "FREQcount": "924"
  },
  {
    "Word": "noon",
    "FREQcount": "924"
  },
  {
    "Word": "jersey",
    "FREQcount": "923"
  },
  {
    "Word": "previously",
    "FREQcount": "923"
  },
  {
    "Word": "blowing",
    "FREQcount": "921"
  },
  {
    "Word": "sons",
    "FREQcount": "921"
  },
  {
    "Word": "reward",
    "FREQcount": "919"
  },
  {
    "Word": "degrees",
    "FREQcount": "918"
  },
  {
    "Word": "georgia",
    "FREQcount": "918"
  },
  {
    "Word": "lets",
    "FREQcount": "918"
  },
  {
    "Word": "bothering",
    "FREQcount": "917"
  },
  {
    "Word": "bars",
    "FREQcount": "916"
  },
  {
    "Word": "cameras",
    "FREQcount": "915"
  },
  {
    "Word": "dumped",
    "FREQcount": "915"
  },
  {
    "Word": "iron",
    "FREQcount": "915"
  },
  {
    "Word": "mitch",
    "FREQcount": "915"
  },
  {
    "Word": "devon",
    "FREQcount": "914"
  },
  {
    "Word": "express",
    "FREQcount": "914"
  },
  {
    "Word": "saint",
    "FREQcount": "914"
  },
  {
    "Word": "cookies",
    "FREQcount": "913"
  },
  {
    "Word": "janet",
    "FREQcount": "913"
  },
  {
    "Word": "sacrifice",
    "FREQcount": "913"
  },
  {
    "Word": "assignment",
    "FREQcount": "912"
  },
  {
    "Word": "tunnel",
    "FREQcount": "912"
  },
  {
    "Word": "highway",
    "FREQcount": "911"
  },
  {
    "Word": "guide",
    "FREQcount": "910"
  },
  {
    "Word": "insist",
    "FREQcount": "910"
  },
  {
    "Word": "slide",
    "FREQcount": "909"
  },
  {
    "Word": "victor",
    "FREQcount": "909"
  },
  {
    "Word": "oscar",
    "FREQcount": "908"
  },
  {
    "Word": "specific",
    "FREQcount": "908"
  },
  {
    "Word": "wrap",
    "FREQcount": "908"
  },
  {
    "Word": "cleaned",
    "FREQcount": "907"
  },
  {
    "Word": "prom",
    "FREQcount": "906"
  },
  {
    "Word": "wagon",
    "FREQcount": "906"
  },
  {
    "Word": "cigarettes",
    "FREQcount": "905"
  },
  {
    "Word": "lack",
    "FREQcount": "905"
  },
  {
    "Word": "defendant",
    "FREQcount": "904"
  },
  {
    "Word": "exercise",
    "FREQcount": "904"
  },
  {
    "Word": "jean",
    "FREQcount": "904"
  },
  {
    "Word": "packed",
    "FREQcount": "904"
  },
  {
    "Word": "bullets",
    "FREQcount": "901"
  },
  {
    "Word": "cheat",
    "FREQcount": "901"
  },
  {
    "Word": "kit",
    "FREQcount": "900"
  },
  {
    "Word": "marshal",
    "FREQcount": "900"
  },
  {
    "Word": "background",
    "FREQcount": "899"
  },
  {
    "Word": "ringing",
    "FREQcount": "899"
  },
  {
    "Word": "clue",
    "FREQcount": "898"
  },
  {
    "Word": "damned",
    "FREQcount": "898"
  },
  {
    "Word": "assault",
    "FREQcount": "896"
  },
  {
    "Word": "walt",
    "FREQcount": "896"
  },
  {
    "Word": "concert",
    "FREQcount": "895"
  },
  {
    "Word": "dorothy",
    "FREQcount": "895"
  },
  {
    "Word": "fifteen",
    "FREQcount": "895"
  },
  {
    "Word": "ld",
    "FREQcount": "895"
  },
  {
    "Word": "ranch",
    "FREQcount": "895"
  },
  {
    "Word": "suits",
    "FREQcount": "895"
  },
  {
    "Word": "temple",
    "FREQcount": "895"
  },
  {
    "Word": "designed",
    "FREQcount": "894"
  },
  {
    "Word": "planes",
    "FREQcount": "894"
  },
  {
    "Word": "vampire",
    "FREQcount": "894"
  },
  {
    "Word": "foolish",
    "FREQcount": "893"
  },
  {
    "Word": "agreement",
    "FREQcount": "892"
  },
  {
    "Word": "daphne",
    "FREQcount": "892"
  },
  {
    "Word": "darkness",
    "FREQcount": "892"
  },
  {
    "Word": "flag",
    "FREQcount": "892"
  },
  {
    "Word": "tent",
    "FREQcount": "892"
  },
  {
    "Word": "rotten",
    "FREQcount": "891"
  },
  {
    "Word": "pacey",
    "FREQcount": "890"
  },
  {
    "Word": "remains",
    "FREQcount": "890"
  },
  {
    "Word": "term",
    "FREQcount": "890"
  },
  {
    "Word": "alien",
    "FREQcount": "889"
  },
  {
    "Word": "patch",
    "FREQcount": "888"
  },
  {
    "Word": "provide",
    "FREQcount": "888"
  },
  {
    "Word": "touching",
    "FREQcount": "888"
  },
  {
    "Word": "cooper",
    "FREQcount": "887"
  },
  {
    "Word": "snap",
    "FREQcount": "887"
  },
  {
    "Word": "davis",
    "FREQcount": "886"
  },
  {
    "Word": "bail",
    "FREQcount": "885"
  },
  {
    "Word": "believes",
    "FREQcount": "885"
  },
  {
    "Word": "imagination",
    "FREQcount": "885"
  },
  {
    "Word": "actual",
    "FREQcount": "884"
  },
  {
    "Word": "incident",
    "FREQcount": "883"
  },
  {
    "Word": "liquor",
    "FREQcount": "882"
  },
  {
    "Word": "molly",
    "FREQcount": "882"
  },
  {
    "Word": "released",
    "FREQcount": "882"
  },
  {
    "Word": "sonny",
    "FREQcount": "882"
  },
  {
    "Word": "connected",
    "FREQcount": "881"
  },
  {
    "Word": "disaster",
    "FREQcount": "881"
  },
  {
    "Word": "fully",
    "FREQcount": "880"
  },
  {
    "Word": "mass",
    "FREQcount": "880"
  },
  {
    "Word": "comfort",
    "FREQcount": "878"
  },
  {
    "Word": "sec",
    "FREQcount": "877"
  },
  {
    "Word": "smiling",
    "FREQcount": "877"
  },
  {
    "Word": "border",
    "FREQcount": "876"
  },
  {
    "Word": "francis",
    "FREQcount": "876"
  },
  {
    "Word": "fuel",
    "FREQcount": "876"
  },
  {
    "Word": "thirty",
    "FREQcount": "876"
  },
  {
    "Word": "legend",
    "FREQcount": "875"
  },
  {
    "Word": "players",
    "FREQcount": "875"
  },
  {
    "Word": "crossed",
    "FREQcount": "874"
  },
  {
    "Word": "electric",
    "FREQcount": "874"
  },
  {
    "Word": "demand",
    "FREQcount": "873"
  },
  {
    "Word": "donald",
    "FREQcount": "873"
  },
  {
    "Word": "opera",
    "FREQcount": "873"
  },
  {
    "Word": "circus",
    "FREQcount": "870"
  },
  {
    "Word": "current",
    "FREQcount": "869"
  },
  {
    "Word": "diamonds",
    "FREQcount": "869"
  },
  {
    "Word": "trauma",
    "FREQcount": "869"
  },
  {
    "Word": "turtle",
    "FREQcount": "869"
  },
  {
    "Word": "bundy",
    "FREQcount": "868"
  },
  {
    "Word": "enjoying",
    "FREQcount": "868"
  },
  {
    "Word": "laws",
    "FREQcount": "868"
  },
  {
    "Word": "neighbors",
    "FREQcount": "868"
  },
  {
    "Word": "prints",
    "FREQcount": "868"
  },
  {
    "Word": "salad",
    "FREQcount": "868"
  },
  {
    "Word": "argument",
    "FREQcount": "867"
  },
  {
    "Word": "peggy",
    "FREQcount": "867"
  },
  {
    "Word": "describe",
    "FREQcount": "866"
  },
  {
    "Word": "harper",
    "FREQcount": "866"
  },
  {
    "Word": "impressive",
    "FREQcount": "865"
  },
  {
    "Word": "starving",
    "FREQcount": "865"
  },
  {
    "Word": "neighbor",
    "FREQcount": "864"
  },
  {
    "Word": "nigga",
    "FREQcount": "864"
  },
  {
    "Word": "council",
    "FREQcount": "863"
  },
  {
    "Word": "fallen",
    "FREQcount": "863"
  },
  {
    "Word": "sink",
    "FREQcount": "863"
  },
  {
    "Word": "backup",
    "FREQcount": "862"
  },
  {
    "Word": "screams",
    "FREQcount": "862"
  },
  {
    "Word": "avenue",
    "FREQcount": "861"
  },
  {
    "Word": "sneak",
    "FREQcount": "861"
  },
  {
    "Word": "trigger",
    "FREQcount": "861"
  },
  {
    "Word": "wipe",
    "FREQcount": "861"
  },
  {
    "Word": "events",
    "FREQcount": "860"
  },
  {
    "Word": "norman",
    "FREQcount": "860"
  },
  {
    "Word": "tone",
    "FREQcount": "860"
  },
  {
    "Word": "meg",
    "FREQcount": "859"
  },
  {
    "Word": "toy",
    "FREQcount": "859"
  },
  {
    "Word": "youth",
    "FREQcount": "858"
  },
  {
    "Word": "crush",
    "FREQcount": "857"
  },
  {
    "Word": "factory",
    "FREQcount": "857"
  },
  {
    "Word": "felicity",
    "FREQcount": "857"
  },
  {
    "Word": "campaign",
    "FREQcount": "856"
  },
  {
    "Word": "grass",
    "FREQcount": "856"
  },
  {
    "Word": "instance",
    "FREQcount": "856"
  },
  {
    "Word": "jen",
    "FREQcount": "856"
  },
  {
    "Word": "searching",
    "FREQcount": "856"
  },
  {
    "Word": "trusted",
    "FREQcount": "856"
  },
  {
    "Word": "williams",
    "FREQcount": "856"
  },
  {
    "Word": "bishop",
    "FREQcount": "855"
  },
  {
    "Word": "dennis",
    "FREQcount": "854"
  },
  {
    "Word": "goal",
    "FREQcount": "854"
  },
  {
    "Word": "ken",
    "FREQcount": "854"
  },
  {
    "Word": "tracks",
    "FREQcount": "854"
  },
  {
    "Word": "wasted",
    "FREQcount": "854"
  },
  {
    "Word": "messed",
    "FREQcount": "853"
  },
  {
    "Word": "asks",
    "FREQcount": "852"
  },
  {
    "Word": "cookie",
    "FREQcount": "852"
  },
  {
    "Word": "generous",
    "FREQcount": "852"
  },
  {
    "Word": "fairy",
    "FREQcount": "851"
  },
  {
    "Word": "violent",
    "FREQcount": "850"
  },
  {
    "Word": "average",
    "FREQcount": "849"
  },
  {
    "Word": "benny",
    "FREQcount": "849"
  },
  {
    "Word": "crisis",
    "FREQcount": "849"
  },
  {
    "Word": "harvey",
    "FREQcount": "849"
  },
  {
    "Word": "humor",
    "FREQcount": "849"
  },
  {
    "Word": "liberty",
    "FREQcount": "849"
  },
  {
    "Word": "suite",
    "FREQcount": "849"
  },
  {
    "Word": "opens",
    "FREQcount": "848"
  },
  {
    "Word": "rats",
    "FREQcount": "848"
  },
  {
    "Word": "slipped",
    "FREQcount": "848"
  },
  {
    "Word": "systems",
    "FREQcount": "848"
  },
  {
    "Word": "stake",
    "FREQcount": "847"
  },
  {
    "Word": "gambling",
    "FREQcount": "846"
  },
  {
    "Word": "managed",
    "FREQcount": "846"
  },
  {
    "Word": "nephew",
    "FREQcount": "846"
  },
  {
    "Word": "admiral",
    "FREQcount": "845"
  },
  {
    "Word": "alcohol",
    "FREQcount": "845"
  },
  {
    "Word": "politics",
    "FREQcount": "845"
  },
  {
    "Word": "threatened",
    "FREQcount": "845"
  },
  {
    "Word": "begins",
    "FREQcount": "844"
  },
  {
    "Word": "gentle",
    "FREQcount": "844"
  },
  {
    "Word": "occasion",
    "FREQcount": "844"
  },
  {
    "Word": "shirley",
    "FREQcount": "844"
  },
  {
    "Word": "network",
    "FREQcount": "843"
  },
  {
    "Word": "unhappy",
    "FREQcount": "843"
  },
  {
    "Word": "cleared",
    "FREQcount": "842"
  },
  {
    "Word": "charity",
    "FREQcount": "841"
  },
  {
    "Word": "confession",
    "FREQcount": "841"
  },
  {
    "Word": "explosion",
    "FREQcount": "841"
  },
  {
    "Word": "joined",
    "FREQcount": "841"
  },
  {
    "Word": "finest",
    "FREQcount": "840"
  },
  {
    "Word": "offense",
    "FREQcount": "840"
  },
  {
    "Word": "wade",
    "FREQcount": "840"
  },
  {
    "Word": "headquarters",
    "FREQcount": "839"
  },
  {
    "Word": "judgment",
    "FREQcount": "839"
  },
  {
    "Word": "shout",
    "FREQcount": "839"
  },
  {
    "Word": "filthy",
    "FREQcount": "838"
  },
  {
    "Word": "surgeon",
    "FREQcount": "838"
  },
  {
    "Word": "tube",
    "FREQcount": "838"
  },
  {
    "Word": "hon",
    "FREQcount": "837"
  },
  {
    "Word": "kidnapped",
    "FREQcount": "836"
  },
  {
    "Word": "math",
    "FREQcount": "836"
  },
  {
    "Word": "operator",
    "FREQcount": "836"
  },
  {
    "Word": "personnel",
    "FREQcount": "835"
  },
  {
    "Word": "pin",
    "FREQcount": "835"
  },
  {
    "Word": "mix",
    "FREQcount": "834"
  },
  {
    "Word": "sucker",
    "FREQcount": "834"
  },
  {
    "Word": "alley",
    "FREQcount": "831"
  },
  {
    "Word": "dancer",
    "FREQcount": "831"
  },
  {
    "Word": "dealer",
    "FREQcount": "831"
  },
  {
    "Word": "humans",
    "FREQcount": "831"
  },
  {
    "Word": "chat",
    "FREQcount": "830"
  },
  {
    "Word": "depressed",
    "FREQcount": "830"
  },
  {
    "Word": "hoped",
    "FREQcount": "830"
  },
  {
    "Word": "reaction",
    "FREQcount": "830"
  },
  {
    "Word": "commercial",
    "FREQcount": "829"
  },
  {
    "Word": "mon",
    "FREQcount": "829"
  },
  {
    "Word": "underneath",
    "FREQcount": "829"
  },
  {
    "Word": "behave",
    "FREQcount": "828"
  },
  {
    "Word": "chill",
    "FREQcount": "828"
  },
  {
    "Word": "chips",
    "FREQcount": "828"
  },
  {
    "Word": "fantasy",
    "FREQcount": "828"
  },
  {
    "Word": "gloves",
    "FREQcount": "828"
  },
  {
    "Word": "steak",
    "FREQcount": "828"
  },
  {
    "Word": "version",
    "FREQcount": "828"
  },
  {
    "Word": "sides",
    "FREQcount": "827"
  },
  {
    "Word": "worrying",
    "FREQcount": "827"
  },
  {
    "Word": "design",
    "FREQcount": "826"
  },
  {
    "Word": "dropping",
    "FREQcount": "826"
  },
  {
    "Word": "experiment",
    "FREQcount": "826"
  },
  {
    "Word": "honeymoon",
    "FREQcount": "826"
  },
  {
    "Word": "struck",
    "FREQcount": "826"
  },
  {
    "Word": "blast",
    "FREQcount": "825"
  },
  {
    "Word": "identify",
    "FREQcount": "825"
  },
  {
    "Word": "arranged",
    "FREQcount": "824"
  },
  {
    "Word": "classic",
    "FREQcount": "824"
  },
  {
    "Word": "quarters",
    "FREQcount": "824"
  },
  {
    "Word": "buster",
    "FREQcount": "823"
  },
  {
    "Word": "crystal",
    "FREQcount": "823"
  },
  {
    "Word": "delivered",
    "FREQcount": "823"
  },
  {
    "Word": "procedure",
    "FREQcount": "823"
  },
  {
    "Word": "spirits",
    "FREQcount": "823"
  },
  {
    "Word": "goodnight",
    "FREQcount": "822"
  },
  {
    "Word": "whiskey",
    "FREQcount": "822"
  },
  {
    "Word": "divorced",
    "FREQcount": "821"
  },
  {
    "Word": "jay",
    "FREQcount": "821"
  },
  {
    "Word": "perform",
    "FREQcount": "821"
  },
  {
    "Word": "prisoners",
    "FREQcount": "821"
  },
  {
    "Word": "response",
    "FREQcount": "821"
  },
  {
    "Word": "dope",
    "FREQcount": "820"
  },
  {
    "Word": "fence",
    "FREQcount": "819"
  },
  {
    "Word": "greater",
    "FREQcount": "819"
  },
  {
    "Word": "poker",
    "FREQcount": "819"
  },
  {
    "Word": "landing",
    "FREQcount": "818"
  },
  {
    "Word": "normally",
    "FREQcount": "818"
  },
  {
    "Word": "powder",
    "FREQcount": "818"
  },
  {
    "Word": "actress",
    "FREQcount": "817"
  },
  {
    "Word": "drawing",
    "FREQcount": "817"
  },
  {
    "Word": "protecting",
    "FREQcount": "817"
  },
  {
    "Word": "vietnam",
    "FREQcount": "817"
  },
  {
    "Word": "gear",
    "FREQcount": "816"
  },
  {
    "Word": "rape",
    "FREQcount": "816"
  },
  {
    "Word": "advance",
    "FREQcount": "815"
  },
  {
    "Word": "locker",
    "FREQcount": "815"
  },
  {
    "Word": "suspicious",
    "FREQcount": "815"
  },
  {
    "Word": "buzz",
    "FREQcount": "814"
  },
  {
    "Word": "beth",
    "FREQcount": "813"
  },
  {
    "Word": "civil",
    "FREQcount": "813"
  },
  {
    "Word": "sin",
    "FREQcount": "813"
  },
  {
    "Word": "classes",
    "FREQcount": "812"
  },
  {
    "Word": "ending",
    "FREQcount": "812"
  },
  {
    "Word": "le",
    "FREQcount": "812"
  },
  {
    "Word": "marrying",
    "FREQcount": "812"
  },
  {
    "Word": "meanwhile",
    "FREQcount": "812"
  },
  {
    "Word": "miami",
    "FREQcount": "812"
  },
  {
    "Word": "torture",
    "FREQcount": "812"
  },
  {
    "Word": "banks",
    "FREQcount": "811"
  },
  {
    "Word": "blown",
    "FREQcount": "811"
  },
  {
    "Word": "christian",
    "FREQcount": "811"
  },
  {
    "Word": "personality",
    "FREQcount": "811"
  },
  {
    "Word": "selfish",
    "FREQcount": "811"
  },
  {
    "Word": "teddy",
    "FREQcount": "811"
  },
  {
    "Word": "dough",
    "FREQcount": "810"
  },
  {
    "Word": "fed",
    "FREQcount": "810"
  },
  {
    "Word": "lf",
    "FREQcount": "809"
  },
  {
    "Word": "confess",
    "FREQcount": "808"
  },
  {
    "Word": "deserves",
    "FREQcount": "808"
  },
  {
    "Word": "walker",
    "FREQcount": "808"
  },
  {
    "Word": "warned",
    "FREQcount": "808"
  },
  {
    "Word": "ceremony",
    "FREQcount": "807"
  },
  {
    "Word": "clown",
    "FREQcount": "807"
  },
  {
    "Word": "highness",
    "FREQcount": "807"
  },
  {
    "Word": "rocky",
    "FREQcount": "807"
  },
  {
    "Word": "solution",
    "FREQcount": "807"
  },
  {
    "Word": "tries",
    "FREQcount": "807"
  },
  {
    "Word": "connie",
    "FREQcount": "806"
  },
  {
    "Word": "helicopter",
    "FREQcount": "806"
  },
  {
    "Word": "costs",
    "FREQcount": "805"
  },
  {
    "Word": "prayer",
    "FREQcount": "805"
  },
  {
    "Word": "apology",
    "FREQcount": "804"
  },
  {
    "Word": "dressing",
    "FREQcount": "804"
  },
  {
    "Word": "forth",
    "FREQcount": "804"
  },
  {
    "Word": "invented",
    "FREQcount": "803"
  },
  {
    "Word": "corporal",
    "FREQcount": "802"
  },
  {
    "Word": "hers",
    "FREQcount": "802"
  },
  {
    "Word": "hm",
    "FREQcount": "802"
  },
  {
    "Word": "accepted",
    "FREQcount": "801"
  },
  {
    "Word": "emma",
    "FREQcount": "801"
  },
  {
    "Word": "boxes",
    "FREQcount": "800"
  },
  {
    "Word": "entrance",
    "FREQcount": "800"
  },
  {
    "Word": "singer",
    "FREQcount": "800"
  },
  {
    "Word": "strip",
    "FREQcount": "800"
  },
  {
    "Word": "gather",
    "FREQcount": "799"
  },
  {
    "Word": "pearl",
    "FREQcount": "799"
  },
  {
    "Word": "concentrate",
    "FREQcount": "798"
  },
  {
    "Word": "deputy",
    "FREQcount": "798"
  },
  {
    "Word": "instructions",
    "FREQcount": "798"
  },
  {
    "Word": "satellite",
    "FREQcount": "798"
  },
  {
    "Word": "uncomfortable",
    "FREQcount": "798"
  },
  {
    "Word": "daily",
    "FREQcount": "797"
  },
  {
    "Word": "nut",
    "FREQcount": "797"
  },
  {
    "Word": "stress",
    "FREQcount": "796"
  },
  {
    "Word": "tune",
    "FREQcount": "796"
  },
  {
    "Word": "guitar",
    "FREQcount": "795"
  },
  {
    "Word": "kicking",
    "FREQcount": "795"
  },
  {
    "Word": "merely",
    "FREQcount": "795"
  },
  {
    "Word": "porter",
    "FREQcount": "795"
  },
  {
    "Word": "pretending",
    "FREQcount": "795"
  },
  {
    "Word": "sauce",
    "FREQcount": "795"
  },
  {
    "Word": "sighs",
    "FREQcount": "795"
  },
  {
    "Word": "valuable",
    "FREQcount": "795"
  },
  {
    "Word": "basic",
    "FREQcount": "794"
  },
  {
    "Word": "belly",
    "FREQcount": "794"
  },
  {
    "Word": "charm",
    "FREQcount": "794"
  },
  {
    "Word": "exit",
    "FREQcount": "794"
  },
  {
    "Word": "blows",
    "FREQcount": "793"
  },
  {
    "Word": "net",
    "FREQcount": "793"
  },
  {
    "Word": "steven",
    "FREQcount": "793"
  },
  {
    "Word": "voices",
    "FREQcount": "793"
  },
  {
    "Word": "patrol",
    "FREQcount": "792"
  },
  {
    "Word": "pitch",
    "FREQcount": "792"
  },
  {
    "Word": "romance",
    "FREQcount": "792"
  },
  {
    "Word": "arrange",
    "FREQcount": "791"
  },
  {
    "Word": "japan",
    "FREQcount": "791"
  },
  {
    "Word": "satisfied",
    "FREQcount": "791"
  },
  {
    "Word": "makeup",
    "FREQcount": "790"
  },
  {
    "Word": "matthew",
    "FREQcount": "790"
  },
  {
    "Word": "teams",
    "FREQcount": "790"
  },
  {
    "Word": "surrender",
    "FREQcount": "789"
  },
  {
    "Word": "rub",
    "FREQcount": "788"
  },
  {
    "Word": "strangers",
    "FREQcount": "788"
  },
  {
    "Word": "whistle",
    "FREQcount": "788"
  },
  {
    "Word": "bum",
    "FREQcount": "787"
  },
  {
    "Word": "fort",
    "FREQcount": "787"
  },
  {
    "Word": "kingdom",
    "FREQcount": "787"
  },
  {
    "Word": "visiting",
    "FREQcount": "787"
  },
  {
    "Word": "wives",
    "FREQcount": "787"
  },
  {
    "Word": "hip",
    "FREQcount": "786"
  },
  {
    "Word": "anthony",
    "FREQcount": "785"
  },
  {
    "Word": "flew",
    "FREQcount": "785"
  },
  {
    "Word": "hood",
    "FREQcount": "785"
  },
  {
    "Word": "ling",
    "FREQcount": "785"
  },
  {
    "Word": "diet",
    "FREQcount": "784"
  },
  {
    "Word": "dreamed",
    "FREQcount": "784"
  },
  {
    "Word": "junk",
    "FREQcount": "784"
  },
  {
    "Word": "patience",
    "FREQcount": "784"
  },
  {
    "Word": "earn",
    "FREQcount": "783"
  },
  {
    "Word": "flash",
    "FREQcount": "783"
  },
  {
    "Word": "lion",
    "FREQcount": "783"
  },
  {
    "Word": "ralph",
    "FREQcount": "783"
  },
  {
    "Word": "frozen",
    "FREQcount": "782"
  },
  {
    "Word": "homicide",
    "FREQcount": "782"
  },
  {
    "Word": "robbed",
    "FREQcount": "782"
  },
  {
    "Word": "decisions",
    "FREQcount": "781"
  },
  {
    "Word": "gross",
    "FREQcount": "779"
  },
  {
    "Word": "holes",
    "FREQcount": "779"
  },
  {
    "Word": "badge",
    "FREQcount": "778"
  },
  {
    "Word": "mel",
    "FREQcount": "778"
  },
  {
    "Word": "uses",
    "FREQcount": "778"
  },
  {
    "Word": "financial",
    "FREQcount": "777"
  },
  {
    "Word": "offering",
    "FREQcount": "777"
  },
  {
    "Word": "answered",
    "FREQcount": "775"
  },
  {
    "Word": "customer",
    "FREQcount": "775"
  },
  {
    "Word": "officially",
    "FREQcount": "775"
  },
  {
    "Word": "opposite",
    "FREQcount": "775"
  },
  {
    "Word": "soap",
    "FREQcount": "775"
  },
  {
    "Word": "beside",
    "FREQcount": "774"
  },
  {
    "Word": "privacy",
    "FREQcount": "774"
  },
  {
    "Word": "unknown",
    "FREQcount": "774"
  },
  {
    "Word": "anyhow",
    "FREQcount": "773"
  },
  {
    "Word": "painful",
    "FREQcount": "773"
  },
  {
    "Word": "represent",
    "FREQcount": "773"
  },
  {
    "Word": "lessons",
    "FREQcount": "772"
  },
  {
    "Word": "champ",
    "FREQcount": "771"
  },
  {
    "Word": "extraordinary",
    "FREQcount": "771"
  },
  {
    "Word": "pour",
    "FREQcount": "771"
  },
  {
    "Word": "reported",
    "FREQcount": "771"
  },
  {
    "Word": "testing",
    "FREQcount": "771"
  },
  {
    "Word": "hopes",
    "FREQcount": "770"
  },
  {
    "Word": "twins",
    "FREQcount": "770"
  },
  {
    "Word": "fascinating",
    "FREQcount": "769"
  },
  {
    "Word": "furniture",
    "FREQcount": "769"
  },
  {
    "Word": "meantime",
    "FREQcount": "769"
  },
  {
    "Word": "rice",
    "FREQcount": "769"
  },
  {
    "Word": "squeeze",
    "FREQcount": "769"
  },
  {
    "Word": "bend",
    "FREQcount": "768"
  },
  {
    "Word": "valentine",
    "FREQcount": "768"
  },
  {
    "Word": "beats",
    "FREQcount": "767"
  },
  {
    "Word": "begging",
    "FREQcount": "766"
  },
  {
    "Word": "host",
    "FREQcount": "766"
  },
  {
    "Word": "blocks",
    "FREQcount": "765"
  },
  {
    "Word": "mysterious",
    "FREQcount": "765"
  },
  {
    "Word": "sore",
    "FREQcount": "765"
  },
  {
    "Word": "balance",
    "FREQcount": "764"
  },
  {
    "Word": "shark",
    "FREQcount": "764"
  },
  {
    "Word": "timing",
    "FREQcount": "764"
  },
  {
    "Word": "technology",
    "FREQcount": "762"
  },
  {
    "Word": "angle",
    "FREQcount": "761"
  },
  {
    "Word": "dutch",
    "FREQcount": "761"
  },
  {
    "Word": "sets",
    "FREQcount": "761"
  },
  {
    "Word": "guilt",
    "FREQcount": "760"
  },
  {
    "Word": "wondered",
    "FREQcount": "760"
  },
  {
    "Word": "yards",
    "FREQcount": "760"
  },
  {
    "Word": "checks",
    "FREQcount": "759"
  },
  {
    "Word": "degree",
    "FREQcount": "759"
  },
  {
    "Word": "invitation",
    "FREQcount": "759"
  },
  {
    "Word": "knocking",
    "FREQcount": "759"
  },
  {
    "Word": "aim",
    "FREQcount": "758"
  },
  {
    "Word": "urgent",
    "FREQcount": "758"
  },
  {
    "Word": "movement",
    "FREQcount": "757"
  },
  {
    "Word": "morris",
    "FREQcount": "756"
  },
  {
    "Word": "mud",
    "FREQcount": "756"
  },
  {
    "Word": "chan",
    "FREQcount": "755"
  },
  {
    "Word": "heh",
    "FREQcount": "755"
  },
  {
    "Word": "review",
    "FREQcount": "755"
  },
  {
    "Word": "freaking",
    "FREQcount": "754"
  },
  {
    "Word": "influence",
    "FREQcount": "754"
  },
  {
    "Word": "moron",
    "FREQcount": "754"
  },
  {
    "Word": "souls",
    "FREQcount": "754"
  },
  {
    "Word": "warren",
    "FREQcount": "754"
  },
  {
    "Word": "oliver",
    "FREQcount": "753"
  },
  {
    "Word": "product",
    "FREQcount": "752"
  },
  {
    "Word": "scotch",
    "FREQcount": "752"
  },
  {
    "Word": "seal",
    "FREQcount": "752"
  },
  {
    "Word": "tap",
    "FREQcount": "752"
  },
  {
    "Word": "testimony",
    "FREQcount": "752"
  },
  {
    "Word": "ace",
    "FREQcount": "751"
  },
  {
    "Word": "broad",
    "FREQcount": "751"
  },
  {
    "Word": "anderson",
    "FREQcount": "750"
  },
  {
    "Word": "chandler",
    "FREQcount": "750"
  },
  {
    "Word": "films",
    "FREQcount": "750"
  },
  {
    "Word": "skull",
    "FREQcount": "750"
  },
  {
    "Word": "status",
    "FREQcount": "750"
  },
  {
    "Word": "escort",
    "FREQcount": "749"
  },
  {
    "Word": "knee",
    "FREQcount": "749"
  },
  {
    "Word": "recording",
    "FREQcount": "748"
  },
  {
    "Word": "stretch",
    "FREQcount": "748"
  },
  {
    "Word": "territory",
    "FREQcount": "748"
  },
  {
    "Word": "aaron",
    "FREQcount": "747"
  },
  {
    "Word": "affairs",
    "FREQcount": "747"
  },
  {
    "Word": "entered",
    "FREQcount": "747"
  },
  {
    "Word": "listened",
    "FREQcount": "747"
  },
  {
    "Word": "murders",
    "FREQcount": "747"
  },
  {
    "Word": "spin",
    "FREQcount": "746"
  },
  {
    "Word": "favourite",
    "FREQcount": "745"
  },
  {
    "Word": "angels",
    "FREQcount": "744"
  },
  {
    "Word": "noble",
    "FREQcount": "744"
  },
  {
    "Word": "relief",
    "FREQcount": "744"
  },
  {
    "Word": "sample",
    "FREQcount": "744"
  },
  {
    "Word": "shouting",
    "FREQcount": "744"
  },
  {
    "Word": "gene",
    "FREQcount": "743"
  },
  {
    "Word": "hostage",
    "FREQcount": "743"
  },
  {
    "Word": "rifle",
    "FREQcount": "743"
  },
  {
    "Word": "skills",
    "FREQcount": "743"
  },
  {
    "Word": "bo",
    "FREQcount": "742"
  },
  {
    "Word": "chicks",
    "FREQcount": "742"
  },
  {
    "Word": "tax",
    "FREQcount": "742"
  },
  {
    "Word": "deaf",
    "FREQcount": "741"
  },
  {
    "Word": "port",
    "FREQcount": "741"
  },
  {
    "Word": "sticking",
    "FREQcount": "741"
  },
  {
    "Word": "foundation",
    "FREQcount": "740"
  },
  {
    "Word": "literally",
    "FREQcount": "739"
  },
  {
    "Word": "patrick",
    "FREQcount": "739"
  },
  {
    "Word": "technically",
    "FREQcount": "739"
  },
  {
    "Word": "foul",
    "FREQcount": "738"
  },
  {
    "Word": "habit",
    "FREQcount": "738"
  },
  {
    "Word": "harris",
    "FREQcount": "738"
  },
  {
    "Word": "pattern",
    "FREQcount": "738"
  },
  {
    "Word": "ugh",
    "FREQcount": "738"
  },
  {
    "Word": "charged",
    "FREQcount": "737"
  },
  {
    "Word": "occurred",
    "FREQcount": "737"
  },
  {
    "Word": "removed",
    "FREQcount": "737"
  },
  {
    "Word": "beans",
    "FREQcount": "736"
  },
  {
    "Word": "confirm",
    "FREQcount": "736"
  },
  {
    "Word": "deeply",
    "FREQcount": "736"
  },
  {
    "Word": "lad",
    "FREQcount": "736"
  },
  {
    "Word": "option",
    "FREQcount": "736"
  },
  {
    "Word": "coward",
    "FREQcount": "734"
  },
  {
    "Word": "yale",
    "FREQcount": "734"
  },
  {
    "Word": "benefit",
    "FREQcount": "732"
  },
  {
    "Word": "brief",
    "FREQcount": "732"
  },
  {
    "Word": "gifts",
    "FREQcount": "732"
  },
  {
    "Word": "awkward",
    "FREQcount": "730"
  },
  {
    "Word": "adult",
    "FREQcount": "729"
  },
  {
    "Word": "liver",
    "FREQcount": "729"
  },
  {
    "Word": "bombs",
    "FREQcount": "728"
  },
  {
    "Word": "drives",
    "FREQcount": "728"
  },
  {
    "Word": "flip",
    "FREQcount": "728"
  },
  {
    "Word": "holds",
    "FREQcount": "728"
  },
  {
    "Word": "jumping",
    "FREQcount": "728"
  },
  {
    "Word": "diane",
    "FREQcount": "727"
  },
  {
    "Word": "ward",
    "FREQcount": "727"
  },
  {
    "Word": "counsel",
    "FREQcount": "726"
  },
  {
    "Word": "corn",
    "FREQcount": "725"
  },
  {
    "Word": "debt",
    "FREQcount": "725"
  },
  {
    "Word": "gal",
    "FREQcount": "725"
  },
  {
    "Word": "international",
    "FREQcount": "725"
  },
  {
    "Word": "testify",
    "FREQcount": "724"
  },
  {
    "Word": "traveling",
    "FREQcount": "724"
  },
  {
    "Word": "cared",
    "FREQcount": "723"
  },
  {
    "Word": "childhood",
    "FREQcount": "723"
  },
  {
    "Word": "cotton",
    "FREQcount": "723"
  },
  {
    "Word": "facility",
    "FREQcount": "723"
  },
  {
    "Word": "roses",
    "FREQcount": "723"
  },
  {
    "Word": "shown",
    "FREQcount": "723"
  },
  {
    "Word": "tragedy",
    "FREQcount": "723"
  },
  {
    "Word": "admire",
    "FREQcount": "722"
  },
  {
    "Word": "brush",
    "FREQcount": "722"
  },
  {
    "Word": "homes",
    "FREQcount": "722"
  },
  {
    "Word": "pro",
    "FREQcount": "722"
  },
  {
    "Word": "self",
    "FREQcount": "722"
  },
  {
    "Word": "towel",
    "FREQcount": "722"
  },
  {
    "Word": "wally",
    "FREQcount": "722"
  },
  {
    "Word": "costume",
    "FREQcount": "721"
  },
  {
    "Word": "jet",
    "FREQcount": "721"
  },
  {
    "Word": "lightning",
    "FREQcount": "721"
  },
  {
    "Word": "murphy",
    "FREQcount": "721"
  },
  {
    "Word": "bush",
    "FREQcount": "720"
  },
  {
    "Word": "prick",
    "FREQcount": "720"
  },
  {
    "Word": "anxious",
    "FREQcount": "719"
  },
  {
    "Word": "frame",
    "FREQcount": "719"
  },
  {
    "Word": "harvard",
    "FREQcount": "719"
  },
  {
    "Word": "headache",
    "FREQcount": "719"
  },
  {
    "Word": "respond",
    "FREQcount": "719"
  },
  {
    "Word": "ghosts",
    "FREQcount": "718"
  },
  {
    "Word": "marine",
    "FREQcount": "718"
  },
  {
    "Word": "virginia",
    "FREQcount": "718"
  },
  {
    "Word": "washed",
    "FREQcount": "718"
  },
  {
    "Word": "flies",
    "FREQcount": "717"
  },
  {
    "Word": "louise",
    "FREQcount": "717"
  },
  {
    "Word": "palmer",
    "FREQcount": "717"
  },
  {
    "Word": "supplies",
    "FREQcount": "717"
  },
  {
    "Word": "wounds",
    "FREQcount": "717"
  },
  {
    "Word": "answering",
    "FREQcount": "715"
  },
  {
    "Word": "attend",
    "FREQcount": "715"
  },
  {
    "Word": "dessert",
    "FREQcount": "715"
  },
  {
    "Word": "options",
    "FREQcount": "715"
  },
  {
    "Word": "pays",
    "FREQcount": "715"
  },
  {
    "Word": "sacred",
    "FREQcount": "715"
  },
  {
    "Word": "afterwards",
    "FREQcount": "714"
  },
  {
    "Word": "clinic",
    "FREQcount": "714"
  },
  {
    "Word": "recommend",
    "FREQcount": "714"
  },
  {
    "Word": "rubber",
    "FREQcount": "714"
  },
  {
    "Word": "schools",
    "FREQcount": "714"
  },
  {
    "Word": "cave",
    "FREQcount": "713"
  },
  {
    "Word": "remote",
    "FREQcount": "713"
  },
  {
    "Word": "skinny",
    "FREQcount": "713"
  },
  {
    "Word": "thick",
    "FREQcount": "713"
  },
  {
    "Word": "brand",
    "FREQcount": "712"
  },
  {
    "Word": "elaine",
    "FREQcount": "712"
  },
  {
    "Word": "culture",
    "FREQcount": "711"
  },
  {
    "Word": "dallas",
    "FREQcount": "711"
  },
  {
    "Word": "fans",
    "FREQcount": "711"
  },
  {
    "Word": "jonathan",
    "FREQcount": "711"
  },
  {
    "Word": "polite",
    "FREQcount": "711"
  },
  {
    "Word": "blonde",
    "FREQcount": "710"
  },
  {
    "Word": "claims",
    "FREQcount": "710"
  },
  {
    "Word": "painted",
    "FREQcount": "710"
  },
  {
    "Word": "theme",
    "FREQcount": "710"
  },
  {
    "Word": "aid",
    "FREQcount": "709"
  },
  {
    "Word": "conscience",
    "FREQcount": "709"
  },
  {
    "Word": "counter",
    "FREQcount": "709"
  },
  {
    "Word": "darn",
    "FREQcount": "709"
  },
  {
    "Word": "mason",
    "FREQcount": "709"
  },
  {
    "Word": "tyler",
    "FREQcount": "709"
  },
  {
    "Word": "oxygen",
    "FREQcount": "708"
  },
  {
    "Word": "pound",
    "FREQcount": "708"
  },
  {
    "Word": "tag",
    "FREQcount": "708"
  },
  {
    "Word": "claus",
    "FREQcount": "707"
  },
  {
    "Word": "griffin",
    "FREQcount": "707"
  },
  {
    "Word": "jo",
    "FREQcount": "707"
  },
  {
    "Word": "machines",
    "FREQcount": "707"
  },
  {
    "Word": "religion",
    "FREQcount": "707"
  },
  {
    "Word": "religious",
    "FREQcount": "707"
  },
  {
    "Word": "combat",
    "FREQcount": "706"
  },
  {
    "Word": "construction",
    "FREQcount": "706"
  },
  {
    "Word": "audition",
    "FREQcount": "705"
  },
  {
    "Word": "sherry",
    "FREQcount": "705"
  },
  {
    "Word": "transcript",
    "FREQcount": "705"
  },
  {
    "Word": "blessed",
    "FREQcount": "704"
  },
  {
    "Word": "laughter",
    "FREQcount": "704"
  },
  {
    "Word": "sammy",
    "FREQcount": "704"
  },
  {
    "Word": "sweater",
    "FREQcount": "704"
  },
  {
    "Word": "commission",
    "FREQcount": "703"
  },
  {
    "Word": "travis",
    "FREQcount": "703"
  },
  {
    "Word": "dame",
    "FREQcount": "702"
  },
  {
    "Word": "jewish",
    "FREQcount": "702"
  },
  {
    "Word": "shave",
    "FREQcount": "702"
  },
  {
    "Word": "temperature",
    "FREQcount": "702"
  },
  {
    "Word": "drill",
    "FREQcount": "701"
  },
  {
    "Word": "flow",
    "FREQcount": "701"
  },
  {
    "Word": "principal",
    "FREQcount": "701"
  },
  {
    "Word": "sail",
    "FREQcount": "701"
  },
  {
    "Word": "gain",
    "FREQcount": "700"
  },
  {
    "Word": "germany",
    "FREQcount": "699"
  },
  {
    "Word": "baker",
    "FREQcount": "698"
  },
  {
    "Word": "brooklyn",
    "FREQcount": "698"
  },
  {
    "Word": "crown",
    "FREQcount": "698"
  },
  {
    "Word": "packing",
    "FREQcount": "698"
  },
  {
    "Word": "granted",
    "FREQcount": "697"
  },
  {
    "Word": "tradition",
    "FREQcount": "697"
  },
  {
    "Word": "wreck",
    "FREQcount": "697"
  },
  {
    "Word": "bonnie",
    "FREQcount": "696"
  },
  {
    "Word": "lawrence",
    "FREQcount": "696"
  },
  {
    "Word": "poem",
    "FREQcount": "696"
  },
  {
    "Word": "species",
    "FREQcount": "696"
  },
  {
    "Word": "unique",
    "FREQcount": "696"
  },
  {
    "Word": "zoo",
    "FREQcount": "696"
  },
  {
    "Word": "bugs",
    "FREQcount": "695"
  },
  {
    "Word": "pages",
    "FREQcount": "695"
  },
  {
    "Word": "similar",
    "FREQcount": "695"
  },
  {
    "Word": "tennis",
    "FREQcount": "695"
  },
  {
    "Word": "ad",
    "FREQcount": "694"
  },
  {
    "Word": "chop",
    "FREQcount": "694"
  },
  {
    "Word": "muscle",
    "FREQcount": "694"
  },
  {
    "Word": "sticks",
    "FREQcount": "694"
  },
  {
    "Word": "barn",
    "FREQcount": "693"
  },
  {
    "Word": "cherry",
    "FREQcount": "693"
  },
  {
    "Word": "leather",
    "FREQcount": "693"
  },
  {
    "Word": "manny",
    "FREQcount": "693"
  },
  {
    "Word": "tooth",
    "FREQcount": "692"
  },
  {
    "Word": "counts",
    "FREQcount": "691"
  },
  {
    "Word": "cheering",
    "FREQcount": "690"
  },
  {
    "Word": "emperor",
    "FREQcount": "690"
  },
  {
    "Word": "jam",
    "FREQcount": "690"
  },
  {
    "Word": "tokyo",
    "FREQcount": "690"
  },
  {
    "Word": "ambassador",
    "FREQcount": "689"
  },
  {
    "Word": "confirmed",
    "FREQcount": "689"
  },
  {
    "Word": "daisy",
    "FREQcount": "689"
  },
  {
    "Word": "intelligent",
    "FREQcount": "689"
  },
  {
    "Word": "moral",
    "FREQcount": "689"
  },
  {
    "Word": "baron",
    "FREQcount": "687"
  },
  {
    "Word": "lap",
    "FREQcount": "687"
  },
  {
    "Word": "blah",
    "FREQcount": "686"
  },
  {
    "Word": "steam",
    "FREQcount": "686"
  },
  {
    "Word": "adventure",
    "FREQcount": "685"
  },
  {
    "Word": "berlin",
    "FREQcount": "685"
  },
  {
    "Word": "punishment",
    "FREQcount": "685"
  },
  {
    "Word": "sheep",
    "FREQcount": "685"
  },
  {
    "Word": "exam",
    "FREQcount": "684"
  },
  {
    "Word": "gates",
    "FREQcount": "684"
  },
  {
    "Word": "penis",
    "FREQcount": "684"
  },
  {
    "Word": "demons",
    "FREQcount": "683"
  },
  {
    "Word": "gum",
    "FREQcount": "683"
  },
  {
    "Word": "sarge",
    "FREQcount": "683"
  },
  {
    "Word": "suitcase",
    "FREQcount": "683"
  },
  {
    "Word": "bottles",
    "FREQcount": "682"
  },
  {
    "Word": "equal",
    "FREQcount": "682"
  },
  {
    "Word": "operate",
    "FREQcount": "682"
  },
  {
    "Word": "poetry",
    "FREQcount": "682"
  },
  {
    "Word": "struggle",
    "FREQcount": "682"
  },
  {
    "Word": "fools",
    "FREQcount": "681"
  },
  {
    "Word": "replace",
    "FREQcount": "681"
  },
  {
    "Word": "citizen",
    "FREQcount": "680"
  },
  {
    "Word": "freezing",
    "FREQcount": "680"
  },
  {
    "Word": "grabbed",
    "FREQcount": "680"
  },
  {
    "Word": "possession",
    "FREQcount": "680"
  },
  {
    "Word": "smaller",
    "FREQcount": "680"
  },
  {
    "Word": "thunder",
    "FREQcount": "679"
  },
  {
    "Word": "western",
    "FREQcount": "679"
  },
  {
    "Word": "abandoned",
    "FREQcount": "678"
  },
  {
    "Word": "halfway",
    "FREQcount": "678"
  },
  {
    "Word": "pigs",
    "FREQcount": "678"
  },
  {
    "Word": "session",
    "FREQcount": "678"
  },
  {
    "Word": "stephen",
    "FREQcount": "678"
  },
  {
    "Word": "wheels",
    "FREQcount": "678"
  },
  {
    "Word": "wicked",
    "FREQcount": "678"
  },
  {
    "Word": "heavens",
    "FREQcount": "677"
  },
  {
    "Word": "interests",
    "FREQcount": "677"
  },
  {
    "Word": "surrounded",
    "FREQcount": "677"
  },
  {
    "Word": "burt",
    "FREQcount": "676"
  },
  {
    "Word": "digging",
    "FREQcount": "676"
  },
  {
    "Word": "fellows",
    "FREQcount": "676"
  },
  {
    "Word": "paradise",
    "FREQcount": "676"
  },
  {
    "Word": "motive",
    "FREQcount": "675"
  },
  {
    "Word": "palm",
    "FREQcount": "675"
  },
  {
    "Word": "cattle",
    "FREQcount": "674"
  },
  {
    "Word": "hut",
    "FREQcount": "674"
  },
  {
    "Word": "magnificent",
    "FREQcount": "674"
  },
  {
    "Word": "pit",
    "FREQcount": "674"
  },
  {
    "Word": "shell",
    "FREQcount": "674"
  },
  {
    "Word": "shove",
    "FREQcount": "674"
  },
  {
    "Word": "toys",
    "FREQcount": "674"
  },
  {
    "Word": "waves",
    "FREQcount": "674"
  },
  {
    "Word": "stable",
    "FREQcount": "673"
  },
  {
    "Word": "stink",
    "FREQcount": "673"
  },
  {
    "Word": "waiter",
    "FREQcount": "673"
  },
  {
    "Word": "basket",
    "FREQcount": "672"
  },
  {
    "Word": "nurses",
    "FREQcount": "672"
  },
  {
    "Word": "pile",
    "FREQcount": "672"
  },
  {
    "Word": "tracking",
    "FREQcount": "672"
  },
  {
    "Word": "bells",
    "FREQcount": "671"
  },
  {
    "Word": "determined",
    "FREQcount": "671"
  },
  {
    "Word": "fucker",
    "FREQcount": "671"
  },
  {
    "Word": "marvelous",
    "FREQcount": "671"
  },
  {
    "Word": "motor",
    "FREQcount": "671"
  },
  {
    "Word": "musical",
    "FREQcount": "671"
  },
  {
    "Word": "sire",
    "FREQcount": "671"
  },
  {
    "Word": "whip",
    "FREQcount": "671"
  },
  {
    "Word": "missile",
    "FREQcount": "670"
  },
  {
    "Word": "parent",
    "FREQcount": "670"
  },
  {
    "Word": "complex",
    "FREQcount": "669"
  },
  {
    "Word": "hooked",
    "FREQcount": "669"
  },
  {
    "Word": "monitor",
    "FREQcount": "669"
  },
  {
    "Word": "recent",
    "FREQcount": "669"
  },
  {
    "Word": "useful",
    "FREQcount": "669"
  },
  {
    "Word": "incredibly",
    "FREQcount": "668"
  },
  {
    "Word": "organization",
    "FREQcount": "668"
  },
  {
    "Word": "backwards",
    "FREQcount": "667"
  },
  {
    "Word": "jill",
    "FREQcount": "667"
  },
  {
    "Word": "stroke",
    "FREQcount": "667"
  },
  {
    "Word": "accused",
    "FREQcount": "666"
  },
  {
    "Word": "engagement",
    "FREQcount": "666"
  },
  {
    "Word": "prevent",
    "FREQcount": "666"
  },
  {
    "Word": "chuckles",
    "FREQcount": "665"
  },
  {
    "Word": "goose",
    "FREQcount": "665"
  },
  {
    "Word": "halloween",
    "FREQcount": "665"
  },
  {
    "Word": "messing",
    "FREQcount": "665"
  },
  {
    "Word": "rap",
    "FREQcount": "665"
  },
  {
    "Word": "temporary",
    "FREQcount": "665"
  },
  {
    "Word": "howdy",
    "FREQcount": "664"
  },
  {
    "Word": "limit",
    "FREQcount": "664"
  },
  {
    "Word": "phones",
    "FREQcount": "664"
  },
  {
    "Word": "tapes",
    "FREQcount": "664"
  },
  {
    "Word": "appeal",
    "FREQcount": "663"
  },
  {
    "Word": "blade",
    "FREQcount": "663"
  },
  {
    "Word": "despite",
    "FREQcount": "663"
  },
  {
    "Word": "drawer",
    "FREQcount": "663"
  },
  {
    "Word": "propose",
    "FREQcount": "663"
  },
  {
    "Word": "superior",
    "FREQcount": "663"
  },
  {
    "Word": "bernard",
    "FREQcount": "662"
  },
  {
    "Word": "blanket",
    "FREQcount": "662"
  },
  {
    "Word": "cried",
    "FREQcount": "662"
  },
  {
    "Word": "eleven",
    "FREQcount": "662"
  },
  {
    "Word": "identity",
    "FREQcount": "662"
  },
  {
    "Word": "maintain",
    "FREQcount": "661"
  },
  {
    "Word": "cigar",
    "FREQcount": "660"
  },
  {
    "Word": "delighted",
    "FREQcount": "660"
  },
  {
    "Word": "inches",
    "FREQcount": "660"
  },
  {
    "Word": "mob",
    "FREQcount": "660"
  },
  {
    "Word": "refused",
    "FREQcount": "660"
  },
  {
    "Word": "survived",
    "FREQcount": "660"
  },
  {
    "Word": "matches",
    "FREQcount": "659"
  },
  {
    "Word": "sack",
    "FREQcount": "659"
  },
  {
    "Word": "clerk",
    "FREQcount": "658"
  },
  {
    "Word": "properly",
    "FREQcount": "658"
  },
  {
    "Word": "activity",
    "FREQcount": "657"
  },
  {
    "Word": "appropriate",
    "FREQcount": "657"
  },
  {
    "Word": "award",
    "FREQcount": "657"
  },
  {
    "Word": "gloria",
    "FREQcount": "657"
  },
  {
    "Word": "lamp",
    "FREQcount": "657"
  },
  {
    "Word": "parade",
    "FREQcount": "657"
  },
  {
    "Word": "profile",
    "FREQcount": "657"
  },
  {
    "Word": "resist",
    "FREQcount": "657"
  },
  {
    "Word": "rusty",
    "FREQcount": "657"
  },
  {
    "Word": "scout",
    "FREQcount": "657"
  },
  {
    "Word": "shaking",
    "FREQcount": "657"
  },
  {
    "Word": "drank",
    "FREQcount": "656"
  },
  {
    "Word": "stepped",
    "FREQcount": "656"
  },
  {
    "Word": "suffered",
    "FREQcount": "656"
  },
  {
    "Word": "exhausted",
    "FREQcount": "655"
  },
  {
    "Word": "heroes",
    "FREQcount": "655"
  },
  {
    "Word": "kenny",
    "FREQcount": "655"
  },
  {
    "Word": "comment",
    "FREQcount": "654"
  },
  {
    "Word": "dive",
    "FREQcount": "654"
  },
  {
    "Word": "fits",
    "FREQcount": "654"
  },
  {
    "Word": "hatch",
    "FREQcount": "654"
  },
  {
    "Word": "minor",
    "FREQcount": "654"
  },
  {
    "Word": "mistaken",
    "FREQcount": "654"
  },
  {
    "Word": "approaching",
    "FREQcount": "653"
  },
  {
    "Word": "landed",
    "FREQcount": "653"
  },
  {
    "Word": "authorities",
    "FREQcount": "652"
  },
  {
    "Word": "environment",
    "FREQcount": "652"
  },
  {
    "Word": "fighter",
    "FREQcount": "652"
  },
  {
    "Word": "handled",
    "FREQcount": "652"
  },
  {
    "Word": "hiya",
    "FREQcount": "652"
  },
  {
    "Word": "medication",
    "FREQcount": "652"
  },
  {
    "Word": "beloved",
    "FREQcount": "651"
  },
  {
    "Word": "expression",
    "FREQcount": "651"
  },
  {
    "Word": "manners",
    "FREQcount": "651"
  },
  {
    "Word": "stuart",
    "FREQcount": "651"
  },
  {
    "Word": "wears",
    "FREQcount": "651"
  },
  {
    "Word": "chamber",
    "FREQcount": "650"
  },
  {
    "Word": "hawk",
    "FREQcount": "650"
  },
  {
    "Word": "effects",
    "FREQcount": "649"
  },
  {
    "Word": "sookie",
    "FREQcount": "649"
  },
  {
    "Word": "swallow",
    "FREQcount": "649"
  },
  {
    "Word": "task",
    "FREQcount": "649"
  },
  {
    "Word": "capital",
    "FREQcount": "648"
  },
  {
    "Word": "catching",
    "FREQcount": "648"
  },
  {
    "Word": "sales",
    "FREQcount": "648"
  },
  {
    "Word": "chin",
    "FREQcount": "647"
  },
  {
    "Word": "conditions",
    "FREQcount": "647"
  },
  {
    "Word": "et",
    "FREQcount": "647"
  },
  {
    "Word": "lobby",
    "FREQcount": "647"
  },
  {
    "Word": "toe",
    "FREQcount": "647"
  },
  {
    "Word": "tub",
    "FREQcount": "647"
  },
  {
    "Word": "earned",
    "FREQcount": "646"
  },
  {
    "Word": "edgar",
    "FREQcount": "646"
  },
  {
    "Word": "empire",
    "FREQcount": "646"
  },
  {
    "Word": "highest",
    "FREQcount": "646"
  },
  {
    "Word": "string",
    "FREQcount": "646"
  },
  {
    "Word": "description",
    "FREQcount": "645"
  },
  {
    "Word": "developed",
    "FREQcount": "645"
  },
  {
    "Word": "eats",
    "FREQcount": "645"
  },
  {
    "Word": "nap",
    "FREQcount": "645"
  },
  {
    "Word": "production",
    "FREQcount": "645"
  },
  {
    "Word": "pump",
    "FREQcount": "645"
  },
  {
    "Word": "stations",
    "FREQcount": "645"
  },
  {
    "Word": "actors",
    "FREQcount": "644"
  },
  {
    "Word": "con",
    "FREQcount": "644"
  },
  {
    "Word": "deeper",
    "FREQcount": "644"
  },
  {
    "Word": "inform",
    "FREQcount": "644"
  },
  {
    "Word": "beard",
    "FREQcount": "643"
  },
  {
    "Word": "passes",
    "FREQcount": "643"
  },
  {
    "Word": "related",
    "FREQcount": "643"
  },
  {
    "Word": "twist",
    "FREQcount": "643"
  },
  {
    "Word": "bid",
    "FREQcount": "642"
  },
  {
    "Word": "pole",
    "FREQcount": "642"
  },
  {
    "Word": "typical",
    "FREQcount": "642"
  },
  {
    "Word": "realise",
    "FREQcount": "641"
  },
  {
    "Word": "remarkable",
    "FREQcount": "641"
  },
  {
    "Word": "ye",
    "FREQcount": "641"
  },
  {
    "Word": "bingo",
    "FREQcount": "640"
  },
  {
    "Word": "bitches",
    "FREQcount": "640"
  },
  {
    "Word": "complain",
    "FREQcount": "640"
  },
  {
    "Word": "creatures",
    "FREQcount": "640"
  },
  {
    "Word": "entertainment",
    "FREQcount": "640"
  },
  {
    "Word": "ex",
    "FREQcount": "640"
  },
  {
    "Word": "soccer",
    "FREQcount": "640"
  },
  {
    "Word": "insult",
    "FREQcount": "639"
  },
  {
    "Word": "philip",
    "FREQcount": "639"
  },
  {
    "Word": "apply",
    "FREQcount": "638"
  },
  {
    "Word": "plates",
    "FREQcount": "638"
  },
  {
    "Word": "toes",
    "FREQcount": "638"
  },
  {
    "Word": "abby",
    "FREQcount": "637"
  },
  {
    "Word": "happier",
    "FREQcount": "637"
  },
  {
    "Word": "korea",
    "FREQcount": "637"
  },
  {
    "Word": "seattle",
    "FREQcount": "637"
  },
  {
    "Word": "acts",
    "FREQcount": "636"
  },
  {
    "Word": "catholic",
    "FREQcount": "636"
  },
  {
    "Word": "choices",
    "FREQcount": "636"
  },
  {
    "Word": "colin",
    "FREQcount": "636"
  },
  {
    "Word": "germans",
    "FREQcount": "636"
  },
  {
    "Word": "hammer",
    "FREQcount": "636"
  },
  {
    "Word": "producer",
    "FREQcount": "636"
  },
  {
    "Word": "sheets",
    "FREQcount": "636"
  },
  {
    "Word": "slap",
    "FREQcount": "636"
  },
  {
    "Word": "troy",
    "FREQcount": "636"
  },
  {
    "Word": "neat",
    "FREQcount": "635"
  },
  {
    "Word": "rehearsal",
    "FREQcount": "635"
  },
  {
    "Word": "suspects",
    "FREQcount": "635"
  },
  {
    "Word": "breasts",
    "FREQcount": "634"
  },
  {
    "Word": "covering",
    "FREQcount": "634"
  },
  {
    "Word": "leonard",
    "FREQcount": "634"
  },
  {
    "Word": "railroad",
    "FREQcount": "634"
  },
  {
    "Word": "rear",
    "FREQcount": "634"
  },
  {
    "Word": "academy",
    "FREQcount": "633"
  },
  {
    "Word": "battery",
    "FREQcount": "633"
  },
  {
    "Word": "editor",
    "FREQcount": "633"
  },
  {
    "Word": "informed",
    "FREQcount": "633"
  },
  {
    "Word": "diner",
    "FREQcount": "632"
  },
  {
    "Word": "sailor",
    "FREQcount": "632"
  },
  {
    "Word": "tha",
    "FREQcount": "632"
  },
  {
    "Word": "toss",
    "FREQcount": "632"
  },
  {
    "Word": "broadway",
    "FREQcount": "631"
  },
  {
    "Word": "inch",
    "FREQcount": "631"
  },
  {
    "Word": "tire",
    "FREQcount": "631"
  },
  {
    "Word": "bump",
    "FREQcount": "630"
  },
  {
    "Word": "invisible",
    "FREQcount": "630"
  },
  {
    "Word": "lawn",
    "FREQcount": "630"
  },
  {
    "Word": "peanut",
    "FREQcount": "630"
  },
  {
    "Word": "russia",
    "FREQcount": "630"
  },
  {
    "Word": "convention",
    "FREQcount": "629"
  },
  {
    "Word": "dana",
    "FREQcount": "629"
  },
  {
    "Word": "fond",
    "FREQcount": "629"
  },
  {
    "Word": "phase",
    "FREQcount": "629"
  },
  {
    "Word": "purple",
    "FREQcount": "629"
  },
  {
    "Word": "quietly",
    "FREQcount": "629"
  },
  {
    "Word": "revolution",
    "FREQcount": "629"
  },
  {
    "Word": "excitement",
    "FREQcount": "628"
  },
  {
    "Word": "goods",
    "FREQcount": "628"
  },
  {
    "Word": "hitler",
    "FREQcount": "628"
  },
  {
    "Word": "item",
    "FREQcount": "628"
  },
  {
    "Word": "manhattan",
    "FREQcount": "628"
  },
  {
    "Word": "thus",
    "FREQcount": "628"
  },
  {
    "Word": "cheated",
    "FREQcount": "627"
  },
  {
    "Word": "episode",
    "FREQcount": "627"
  },
  {
    "Word": "forgetting",
    "FREQcount": "627"
  },
  {
    "Word": "pan",
    "FREQcount": "627"
  },
  {
    "Word": "passengers",
    "FREQcount": "627"
  },
  {
    "Word": "stinks",
    "FREQcount": "627"
  },
  {
    "Word": "thirsty",
    "FREQcount": "627"
  },
  {
    "Word": "tits",
    "FREQcount": "627"
  },
  {
    "Word": "coma",
    "FREQcount": "626"
  },
  {
    "Word": "cruise",
    "FREQcount": "626"
  },
  {
    "Word": "fooling",
    "FREQcount": "626"
  },
  {
    "Word": "pockets",
    "FREQcount": "626"
  },
  {
    "Word": "tend",
    "FREQcount": "626"
  },
  {
    "Word": "critical",
    "FREQcount": "625"
  },
  {
    "Word": "development",
    "FREQcount": "625"
  },
  {
    "Word": "diego",
    "FREQcount": "625"
  },
  {
    "Word": "spike",
    "FREQcount": "625"
  },
  {
    "Word": "commissioner",
    "FREQcount": "624"
  },
  {
    "Word": "mexican",
    "FREQcount": "624"
  },
  {
    "Word": "tragic",
    "FREQcount": "624"
  },
  {
    "Word": "attached",
    "FREQcount": "623"
  },
  {
    "Word": "graduate",
    "FREQcount": "623"
  },
  {
    "Word": "handy",
    "FREQcount": "623"
  },
  {
    "Word": "placed",
    "FREQcount": "623"
  },
  {
    "Word": "sharing",
    "FREQcount": "623"
  },
  {
    "Word": "superman",
    "FREQcount": "623"
  },
  {
    "Word": "advise",
    "FREQcount": "622"
  },
  {
    "Word": "dismissed",
    "FREQcount": "622"
  },
  {
    "Word": "mothers",
    "FREQcount": "622"
  },
  {
    "Word": "signature",
    "FREQcount": "622"
  },
  {
    "Word": "suggestion",
    "FREQcount": "622"
  },
  {
    "Word": "accent",
    "FREQcount": "621"
  },
  {
    "Word": "hollow",
    "FREQcount": "621"
  },
  {
    "Word": "labor",
    "FREQcount": "621"
  },
  {
    "Word": "robot",
    "FREQcount": "621"
  },
  {
    "Word": "scientist",
    "FREQcount": "621"
  },
  {
    "Word": "actions",
    "FREQcount": "620"
  },
  {
    "Word": "behalf",
    "FREQcount": "620"
  },
  {
    "Word": "entry",
    "FREQcount": "620"
  },
  {
    "Word": "buddies",
    "FREQcount": "619"
  },
  {
    "Word": "discussion",
    "FREQcount": "619"
  },
  {
    "Word": "generation",
    "FREQcount": "619"
  },
  {
    "Word": "helpful",
    "FREQcount": "619"
  },
  {
    "Word": "permanent",
    "FREQcount": "619"
  },
  {
    "Word": "servant",
    "FREQcount": "619"
  },
  {
    "Word": "assigned",
    "FREQcount": "618"
  },
  {
    "Word": "brass",
    "FREQcount": "618"
  },
  {
    "Word": "captured",
    "FREQcount": "618"
  },
  {
    "Word": "kidnapping",
    "FREQcount": "617"
  },
  {
    "Word": "permit",
    "FREQcount": "617"
  },
  {
    "Word": "q",
    "FREQcount": "617"
  },
  {
    "Word": "terrorist",
    "FREQcount": "617"
  },
  {
    "Word": "widow",
    "FREQcount": "617"
  },
  {
    "Word": "dull",
    "FREQcount": "616"
  },
  {
    "Word": "july",
    "FREQcount": "616"
  },
  {
    "Word": "upper",
    "FREQcount": "616"
  },
  {
    "Word": "dime",
    "FREQcount": "615"
  },
  {
    "Word": "motherfuckers",
    "FREQcount": "615"
  },
  {
    "Word": "psychiatrist",
    "FREQcount": "615"
  },
  {
    "Word": "retired",
    "FREQcount": "615"
  },
  {
    "Word": "crawl",
    "FREQcount": "614"
  },
  {
    "Word": "discover",
    "FREQcount": "614"
  },
  {
    "Word": "fights",
    "FREQcount": "614"
  },
  {
    "Word": "joining",
    "FREQcount": "614"
  },
  {
    "Word": "kansas",
    "FREQcount": "614"
  },
  {
    "Word": "vault",
    "FREQcount": "614"
  },
  {
    "Word": "foster",
    "FREQcount": "613"
  },
  {
    "Word": "hail",
    "FREQcount": "613"
  },
  {
    "Word": "lemon",
    "FREQcount": "613"
  },
  {
    "Word": "magnum",
    "FREQcount": "613"
  },
  {
    "Word": "underground",
    "FREQcount": "613"
  },
  {
    "Word": "bargain",
    "FREQcount": "612"
  },
  {
    "Word": "clay",
    "FREQcount": "612"
  },
  {
    "Word": "criminals",
    "FREQcount": "612"
  },
  {
    "Word": "ewing",
    "FREQcount": "612"
  },
  {
    "Word": "loyal",
    "FREQcount": "612"
  },
  {
    "Word": "tale",
    "FREQcount": "612"
  },
  {
    "Word": "beaten",
    "FREQcount": "611"
  },
  {
    "Word": "combination",
    "FREQcount": "611"
  },
  {
    "Word": "luther",
    "FREQcount": "611"
  },
  {
    "Word": "precisely",
    "FREQcount": "611"
  },
  {
    "Word": "tastes",
    "FREQcount": "611"
  },
  {
    "Word": "cells",
    "FREQcount": "610"
  },
  {
    "Word": "citizens",
    "FREQcount": "610"
  },
  {
    "Word": "employees",
    "FREQcount": "610"
  },
  {
    "Word": "hawaii",
    "FREQcount": "610"
  },
  {
    "Word": "log",
    "FREQcount": "610"
  },
  {
    "Word": "tattoo",
    "FREQcount": "610"
  },
  {
    "Word": "allen",
    "FREQcount": "609"
  },
  {
    "Word": "basis",
    "FREQcount": "609"
  },
  {
    "Word": "fields",
    "FREQcount": "609"
  },
  {
    "Word": "link",
    "FREQcount": "609"
  },
  {
    "Word": "relationships",
    "FREQcount": "609"
  },
  {
    "Word": "jazz",
    "FREQcount": "608"
  },
  {
    "Word": "needle",
    "FREQcount": "608"
  },
  {
    "Word": "pam",
    "FREQcount": "608"
  },
  {
    "Word": "buffalo",
    "FREQcount": "607"
  },
  {
    "Word": "idiots",
    "FREQcount": "607"
  },
  {
    "Word": "marco",
    "FREQcount": "607"
  },
  {
    "Word": "ruby",
    "FREQcount": "607"
  },
  {
    "Word": "sakes",
    "FREQcount": "607"
  },
  {
    "Word": "chef",
    "FREQcount": "606"
  },
  {
    "Word": "mistress",
    "FREQcount": "606"
  },
  {
    "Word": "racing",
    "FREQcount": "606"
  },
  {
    "Word": "attracted",
    "FREQcount": "605"
  },
  {
    "Word": "bacon",
    "FREQcount": "605"
  },
  {
    "Word": "chairman",
    "FREQcount": "605"
  },
  {
    "Word": "dishes",
    "FREQcount": "605"
  },
  {
    "Word": "psychic",
    "FREQcount": "605"
  },
  {
    "Word": "slim",
    "FREQcount": "605"
  },
  {
    "Word": "treating",
    "FREQcount": "605"
  },
  {
    "Word": "chapter",
    "FREQcount": "604"
  },
  {
    "Word": "farmer",
    "FREQcount": "604"
  },
  {
    "Word": "rocket",
    "FREQcount": "604"
  },
  {
    "Word": "sunshine",
    "FREQcount": "604"
  },
  {
    "Word": "unfortunate",
    "FREQcount": "604"
  },
  {
    "Word": "frog",
    "FREQcount": "603"
  },
  {
    "Word": "pill",
    "FREQcount": "603"
  },
  {
    "Word": "thumb",
    "FREQcount": "603"
  },
  {
    "Word": "comedy",
    "FREQcount": "602"
  },
  {
    "Word": "intended",
    "FREQcount": "601"
  },
  {
    "Word": "terrorists",
    "FREQcount": "601"
  },
  {
    "Word": "hart",
    "FREQcount": "600"
  },
  {
    "Word": "operations",
    "FREQcount": "600"
  },
  {
    "Word": "shoulders",
    "FREQcount": "600"
  },
  {
    "Word": "weed",
    "FREQcount": "600"
  },
  {
    "Word": "wrapped",
    "FREQcount": "600"
  },
  {
    "Word": "beings",
    "FREQcount": "599"
  },
  {
    "Word": "boats",
    "FREQcount": "599"
  },
  {
    "Word": "cloud",
    "FREQcount": "599"
  },
  {
    "Word": "feeding",
    "FREQcount": "599"
  },
  {
    "Word": "owned",
    "FREQcount": "599"
  },
  {
    "Word": "tables",
    "FREQcount": "599"
  },
  {
    "Word": "threatening",
    "FREQcount": "599"
  },
  {
    "Word": "transferred",
    "FREQcount": "599"
  },
  {
    "Word": "cohen",
    "FREQcount": "598"
  },
  {
    "Word": "dated",
    "FREQcount": "598"
  },
  {
    "Word": "dining",
    "FREQcount": "598"
  },
  {
    "Word": "explained",
    "FREQcount": "598"
  },
  {
    "Word": "hooker",
    "FREQcount": "598"
  },
  {
    "Word": "kennedy",
    "FREQcount": "598"
  },
  {
    "Word": "policeman",
    "FREQcount": "598"
  },
  {
    "Word": "pops",
    "FREQcount": "598"
  },
  {
    "Word": "shocked",
    "FREQcount": "598"
  },
  {
    "Word": "undercover",
    "FREQcount": "598"
  },
  {
    "Word": "z",
    "FREQcount": "598"
  },
  {
    "Word": "hopefully",
    "FREQcount": "597"
  },
  {
    "Word": "mount",
    "FREQcount": "597"
  },
  {
    "Word": "boo",
    "FREQcount": "596"
  },
  {
    "Word": "chopper",
    "FREQcount": "596"
  },
  {
    "Word": "engineer",
    "FREQcount": "596"
  },
  {
    "Word": "existence",
    "FREQcount": "596"
  },
  {
    "Word": "fries",
    "FREQcount": "596"
  },
  {
    "Word": "hid",
    "FREQcount": "596"
  },
  {
    "Word": "individual",
    "FREQcount": "596"
  },
  {
    "Word": "industry",
    "FREQcount": "596"
  },
  {
    "Word": "picnic",
    "FREQcount": "596"
  },
  {
    "Word": "reckon",
    "FREQcount": "596"
  },
  {
    "Word": "serving",
    "FREQcount": "596"
  },
  {
    "Word": "debbie",
    "FREQcount": "595"
  },
  {
    "Word": "jacob",
    "FREQcount": "595"
  },
  {
    "Word": "lend",
    "FREQcount": "595"
  },
  {
    "Word": "loyalty",
    "FREQcount": "595"
  },
  {
    "Word": "shelter",
    "FREQcount": "595"
  },
  {
    "Word": "splendid",
    "FREQcount": "595"
  },
  {
    "Word": "workers",
    "FREQcount": "595"
  },
  {
    "Word": "carpet",
    "FREQcount": "594"
  },
  {
    "Word": "divine",
    "FREQcount": "594"
  },
  {
    "Word": "management",
    "FREQcount": "594"
  },
  {
    "Word": "yup",
    "FREQcount": "594"
  },
  {
    "Word": "beneath",
    "FREQcount": "593"
  },
  {
    "Word": "introduced",
    "FREQcount": "593"
  },
  {
    "Word": "raped",
    "FREQcount": "593"
  },
  {
    "Word": "spoil",
    "FREQcount": "593"
  },
  {
    "Word": "synchro",
    "FREQcount": "593"
  },
  {
    "Word": "troubles",
    "FREQcount": "593"
  },
  {
    "Word": "porn",
    "FREQcount": "592"
  },
  {
    "Word": "sheet",
    "FREQcount": "592"
  },
  {
    "Word": "southern",
    "FREQcount": "592"
  },
  {
    "Word": "appearance",
    "FREQcount": "591"
  },
  {
    "Word": "ham",
    "FREQcount": "591"
  },
  {
    "Word": "lazy",
    "FREQcount": "591"
  },
  {
    "Word": "plot",
    "FREQcount": "591"
  },
  {
    "Word": "betrayed",
    "FREQcount": "590"
  },
  {
    "Word": "crimes",
    "FREQcount": "590"
  },
  {
    "Word": "employee",
    "FREQcount": "590"
  },
  {
    "Word": "medal",
    "FREQcount": "590"
  },
  {
    "Word": "returning",
    "FREQcount": "590"
  },
  {
    "Word": "dragged",
    "FREQcount": "589"
  },
  {
    "Word": "reporting",
    "FREQcount": "589"
  },
  {
    "Word": "entering",
    "FREQcount": "588"
  },
  {
    "Word": "hockey",
    "FREQcount": "588"
  },
  {
    "Word": "manner",
    "FREQcount": "588"
  },
  {
    "Word": "waitress",
    "FREQcount": "588"
  },
  {
    "Word": "destruction",
    "FREQcount": "587"
  },
  {
    "Word": "ford",
    "FREQcount": "587"
  },
  {
    "Word": "veronica",
    "FREQcount": "587"
  },
  {
    "Word": "eagle",
    "FREQcount": "586"
  },
  {
    "Word": "entitled",
    "FREQcount": "586"
  },
  {
    "Word": "fingerprints",
    "FREQcount": "586"
  },
  {
    "Word": "visual",
    "FREQcount": "586"
  },
  {
    "Word": "blake",
    "FREQcount": "585"
  },
  {
    "Word": "newspapers",
    "FREQcount": "585"
  },
  {
    "Word": "sends",
    "FREQcount": "585"
  },
  {
    "Word": "active",
    "FREQcount": "584"
  },
  {
    "Word": "denied",
    "FREQcount": "584"
  },
  {
    "Word": "discovery",
    "FREQcount": "584"
  },
  {
    "Word": "dish",
    "FREQcount": "584"
  },
  {
    "Word": "electricity",
    "FREQcount": "584"
  },
  {
    "Word": "puppy",
    "FREQcount": "584"
  },
  {
    "Word": "cuts",
    "FREQcount": "583"
  },
  {
    "Word": "perfume",
    "FREQcount": "583"
  },
  {
    "Word": "shadows",
    "FREQcount": "583"
  },
  {
    "Word": "unconscious",
    "FREQcount": "583"
  },
  {
    "Word": "operating",
    "FREQcount": "582"
  },
  {
    "Word": "temper",
    "FREQcount": "582"
  },
  {
    "Word": "theatre",
    "FREQcount": "582"
  },
  {
    "Word": "bears",
    "FREQcount": "581"
  },
  {
    "Word": "companies",
    "FREQcount": "581"
  },
  {
    "Word": "graham",
    "FREQcount": "581"
  },
  {
    "Word": "pillow",
    "FREQcount": "581"
  },
  {
    "Word": "roommate",
    "FREQcount": "581"
  },
  {
    "Word": "stones",
    "FREQcount": "581"
  },
  {
    "Word": "talented",
    "FREQcount": "581"
  },
  {
    "Word": "teachers",
    "FREQcount": "581"
  },
  {
    "Word": "approve",
    "FREQcount": "580"
  },
  {
    "Word": "cock",
    "FREQcount": "580"
  },
  {
    "Word": "defeat",
    "FREQcount": "580"
  },
  {
    "Word": "elephant",
    "FREQcount": "580"
  },
  {
    "Word": "forms",
    "FREQcount": "580"
  },
  {
    "Word": "promises",
    "FREQcount": "580"
  },
  {
    "Word": "safer",
    "FREQcount": "580"
  },
  {
    "Word": "scientific",
    "FREQcount": "580"
  },
  {
    "Word": "alike",
    "FREQcount": "579"
  },
  {
    "Word": "asses",
    "FREQcount": "579"
  },
  {
    "Word": "assumed",
    "FREQcount": "579"
  },
  {
    "Word": "chemical",
    "FREQcount": "579"
  },
  {
    "Word": "handling",
    "FREQcount": "579"
  },
  {
    "Word": "photograph",
    "FREQcount": "579"
  },
  {
    "Word": "slut",
    "FREQcount": "579"
  },
  {
    "Word": "trailer",
    "FREQcount": "579"
  },
  {
    "Word": "attacks",
    "FREQcount": "578"
  },
  {
    "Word": "greek",
    "FREQcount": "578"
  },
  {
    "Word": "heal",
    "FREQcount": "578"
  },
  {
    "Word": "absolute",
    "FREQcount": "577"
  },
  {
    "Word": "diana",
    "FREQcount": "577"
  },
  {
    "Word": "killers",
    "FREQcount": "577"
  },
  {
    "Word": "practical",
    "FREQcount": "577"
  },
  {
    "Word": "rage",
    "FREQcount": "577"
  },
  {
    "Word": "serial",
    "FREQcount": "577"
  },
  {
    "Word": "shakespeare",
    "FREQcount": "577"
  },
  {
    "Word": "shrink",
    "FREQcount": "577"
  },
  {
    "Word": "studied",
    "FREQcount": "577"
  },
  {
    "Word": "applause",
    "FREQcount": "576"
  },
  {
    "Word": "potato",
    "FREQcount": "576"
  },
  {
    "Word": "slightly",
    "FREQcount": "576"
  },
  {
    "Word": "exists",
    "FREQcount": "575"
  },
  {
    "Word": "geez",
    "FREQcount": "575"
  },
  {
    "Word": "gin",
    "FREQcount": "575"
  },
  {
    "Word": "halt",
    "FREQcount": "575"
  },
  {
    "Word": "necessarily",
    "FREQcount": "575"
  },
  {
    "Word": "paintings",
    "FREQcount": "575"
  },
  {
    "Word": "announcer",
    "FREQcount": "574"
  },
  {
    "Word": "blanche",
    "FREQcount": "574"
  },
  {
    "Word": "raising",
    "FREQcount": "574"
  },
  {
    "Word": "turner",
    "FREQcount": "574"
  },
  {
    "Word": "whale",
    "FREQcount": "574"
  },
  {
    "Word": "assholes",
    "FREQcount": "573"
  },
  {
    "Word": "creep",
    "FREQcount": "573"
  },
  {
    "Word": "peaceful",
    "FREQcount": "573"
  },
  {
    "Word": "warden",
    "FREQcount": "573"
  },
  {
    "Word": "lovers",
    "FREQcount": "572"
  },
  {
    "Word": "randy",
    "FREQcount": "572"
  },
  {
    "Word": "complaining",
    "FREQcount": "571"
  },
  {
    "Word": "dentist",
    "FREQcount": "571"
  },
  {
    "Word": "gig",
    "FREQcount": "571"
  },
  {
    "Word": "immediate",
    "FREQcount": "571"
  },
  {
    "Word": "straighten",
    "FREQcount": "571"
  },
  {
    "Word": "transport",
    "FREQcount": "571"
  },
  {
    "Word": "wesley",
    "FREQcount": "571"
  },
  {
    "Word": "affect",
    "FREQcount": "568"
  },
  {
    "Word": "billion",
    "FREQcount": "568"
  },
  {
    "Word": "bitter",
    "FREQcount": "568"
  },
  {
    "Word": "boot",
    "FREQcount": "568"
  },
  {
    "Word": "bureau",
    "FREQcount": "568"
  },
  {
    "Word": "creepy",
    "FREQcount": "568"
  },
  {
    "Word": "gob",
    "FREQcount": "568"
  },
  {
    "Word": "helpless",
    "FREQcount": "568"
  },
  {
    "Word": "include",
    "FREQcount": "568"
  },
  {
    "Word": "laying",
    "FREQcount": "568"
  },
  {
    "Word": "rd",
    "FREQcount": "568"
  },
  {
    "Word": "reception",
    "FREQcount": "568"
  },
  {
    "Word": "ages",
    "FREQcount": "567"
  },
  {
    "Word": "annoying",
    "FREQcount": "567"
  },
  {
    "Word": "brandy",
    "FREQcount": "567"
  },
  {
    "Word": "luggage",
    "FREQcount": "567"
  },
  {
    "Word": "tools",
    "FREQcount": "567"
  },
  {
    "Word": "assuming",
    "FREQcount": "566"
  },
  {
    "Word": "conduct",
    "FREQcount": "566"
  },
  {
    "Word": "disturb",
    "FREQcount": "566"
  },
  {
    "Word": "nest",
    "FREQcount": "566"
  },
  {
    "Word": "potatoes",
    "FREQcount": "566"
  },
  {
    "Word": "safely",
    "FREQcount": "566"
  },
  {
    "Word": "function",
    "FREQcount": "565"
  },
  {
    "Word": "massage",
    "FREQcount": "565"
  },
  {
    "Word": "wisdom",
    "FREQcount": "565"
  },
  {
    "Word": "arizona",
    "FREQcount": "564"
  },
  {
    "Word": "boarding",
    "FREQcount": "564"
  },
  {
    "Word": "charley",
    "FREQcount": "564"
  },
  {
    "Word": "jewelry",
    "FREQcount": "564"
  },
  {
    "Word": "patty",
    "FREQcount": "564"
  },
  {
    "Word": "produce",
    "FREQcount": "564"
  },
  {
    "Word": "thrilled",
    "FREQcount": "564"
  },
  {
    "Word": "analysis",
    "FREQcount": "563"
  },
  {
    "Word": "nails",
    "FREQcount": "563"
  },
  {
    "Word": "nelson",
    "FREQcount": "563"
  },
  {
    "Word": "delay",
    "FREQcount": "562"
  },
  {
    "Word": "harbor",
    "FREQcount": "562"
  },
  {
    "Word": "psycho",
    "FREQcount": "562"
  },
  {
    "Word": "latin",
    "FREQcount": "561"
  },
  {
    "Word": "limited",
    "FREQcount": "561"
  },
  {
    "Word": "murray",
    "FREQcount": "561"
  },
  {
    "Word": "register",
    "FREQcount": "561"
  },
  {
    "Word": "september",
    "FREQcount": "561"
  },
  {
    "Word": "spain",
    "FREQcount": "561"
  },
  {
    "Word": "election",
    "FREQcount": "560"
  },
  {
    "Word": "reverse",
    "FREQcount": "560"
  },
  {
    "Word": "shed",
    "FREQcount": "560"
  },
  {
    "Word": "column",
    "FREQcount": "559"
  },
  {
    "Word": "fetch",
    "FREQcount": "559"
  },
  {
    "Word": "intention",
    "FREQcount": "559"
  },
  {
    "Word": "lick",
    "FREQcount": "559"
  },
  {
    "Word": "nerves",
    "FREQcount": "559"
  },
  {
    "Word": "ouch",
    "FREQcount": "559"
  },
  {
    "Word": "profit",
    "FREQcount": "559"
  },
  {
    "Word": "assistance",
    "FREQcount": "558"
  },
  {
    "Word": "booze",
    "FREQcount": "558"
  },
  {
    "Word": "emotions",
    "FREQcount": "558"
  },
  {
    "Word": "extreme",
    "FREQcount": "558"
  },
  {
    "Word": "heather",
    "FREQcount": "558"
  },
  {
    "Word": "shawn",
    "FREQcount": "558"
  },
  {
    "Word": "verdict",
    "FREQcount": "558"
  },
  {
    "Word": "worker",
    "FREQcount": "558"
  },
  {
    "Word": "airplane",
    "FREQcount": "557"
  },
  {
    "Word": "bra",
    "FREQcount": "557"
  },
  {
    "Word": "herr",
    "FREQcount": "557"
  },
  {
    "Word": "lame",
    "FREQcount": "557"
  },
  {
    "Word": "promotion",
    "FREQcount": "557"
  },
  {
    "Word": "oops",
    "FREQcount": "556"
  },
  {
    "Word": "rhythm",
    "FREQcount": "556"
  },
  {
    "Word": "cocktail",
    "FREQcount": "555"
  },
  {
    "Word": "corps",
    "FREQcount": "555"
  },
  {
    "Word": "everyday",
    "FREQcount": "555"
  },
  {
    "Word": "phoenix",
    "FREQcount": "555"
  },
  {
    "Word": "rounds",
    "FREQcount": "555"
  },
  {
    "Word": "honored",
    "FREQcount": "554"
  },
  {
    "Word": "lance",
    "FREQcount": "554"
  },
  {
    "Word": "protected",
    "FREQcount": "554"
  },
  {
    "Word": "stubborn",
    "FREQcount": "554"
  },
  {
    "Word": "von",
    "FREQcount": "554"
  },
  {
    "Word": "clothing",
    "FREQcount": "553"
  },
  {
    "Word": "concept",
    "FREQcount": "553"
  },
  {
    "Word": "pumpkin",
    "FREQcount": "553"
  },
  {
    "Word": "smarter",
    "FREQcount": "553"
  },
  {
    "Word": "torn",
    "FREQcount": "553"
  },
  {
    "Word": "waters",
    "FREQcount": "553"
  },
  {
    "Word": "comic",
    "FREQcount": "552"
  },
  {
    "Word": "grief",
    "FREQcount": "552"
  },
  {
    "Word": "computers",
    "FREQcount": "551"
  },
  {
    "Word": "deposit",
    "FREQcount": "551"
  },
  {
    "Word": "dignity",
    "FREQcount": "551"
  },
  {
    "Word": "franklin",
    "FREQcount": "551"
  },
  {
    "Word": "kay",
    "FREQcount": "551"
  },
  {
    "Word": "sixth",
    "FREQcount": "551"
  },
  {
    "Word": "suggesting",
    "FREQcount": "551"
  },
  {
    "Word": "canada",
    "FREQcount": "550"
  },
  {
    "Word": "commitment",
    "FREQcount": "550"
  },
  {
    "Word": "gotcha",
    "FREQcount": "550"
  },
  {
    "Word": "instant",
    "FREQcount": "550"
  },
  {
    "Word": "monsters",
    "FREQcount": "550"
  },
  {
    "Word": "bits",
    "FREQcount": "549"
  },
  {
    "Word": "jefferson",
    "FREQcount": "549"
  },
  {
    "Word": "jew",
    "FREQcount": "549"
  },
  {
    "Word": "orleans",
    "FREQcount": "549"
  },
  {
    "Word": "passenger",
    "FREQcount": "549"
  },
  {
    "Word": "proved",
    "FREQcount": "549"
  },
  {
    "Word": "understands",
    "FREQcount": "549"
  },
  {
    "Word": "acted",
    "FREQcount": "548"
  },
  {
    "Word": "beers",
    "FREQcount": "548"
  },
  {
    "Word": "creative",
    "FREQcount": "548"
  },
  {
    "Word": "facing",
    "FREQcount": "548"
  },
  {
    "Word": "holly",
    "FREQcount": "548"
  },
  {
    "Word": "lip",
    "FREQcount": "548"
  },
  {
    "Word": "salary",
    "FREQcount": "548"
  },
  {
    "Word": "strictly",
    "FREQcount": "548"
  },
  {
    "Word": "throughout",
    "FREQcount": "548"
  },
  {
    "Word": "tool",
    "FREQcount": "548"
  },
  {
    "Word": "banana",
    "FREQcount": "547"
  },
  {
    "Word": "cathy",
    "FREQcount": "547"
  },
  {
    "Word": "eternal",
    "FREQcount": "547"
  },
  {
    "Word": "marked",
    "FREQcount": "547"
  },
  {
    "Word": "required",
    "FREQcount": "547"
  },
  {
    "Word": "rod",
    "FREQcount": "547"
  },
  {
    "Word": "tissue",
    "FREQcount": "547"
  },
  {
    "Word": "campus",
    "FREQcount": "546"
  },
  {
    "Word": "guessing",
    "FREQcount": "546"
  },
  {
    "Word": "pope",
    "FREQcount": "546"
  },
  {
    "Word": "subway",
    "FREQcount": "546"
  },
  {
    "Word": "bowling",
    "FREQcount": "545"
  },
  {
    "Word": "laughed",
    "FREQcount": "545"
  },
  {
    "Word": "arguing",
    "FREQcount": "544"
  },
  {
    "Word": "roberts",
    "FREQcount": "544"
  },
  {
    "Word": "confident",
    "FREQcount": "543"
  },
  {
    "Word": "engines",
    "FREQcount": "543"
  },
  {
    "Word": "hector",
    "FREQcount": "543"
  },
  {
    "Word": "homeless",
    "FREQcount": "543"
  },
  {
    "Word": "paranoid",
    "FREQcount": "543"
  },
  {
    "Word": "barrel",
    "FREQcount": "542"
  },
  {
    "Word": "drawn",
    "FREQcount": "542"
  },
  {
    "Word": "lamb",
    "FREQcount": "542"
  },
  {
    "Word": "privilege",
    "FREQcount": "542"
  },
  {
    "Word": "require",
    "FREQcount": "542"
  },
  {
    "Word": "wizard",
    "FREQcount": "542"
  },
  {
    "Word": "wong",
    "FREQcount": "542"
  },
  {
    "Word": "carmen",
    "FREQcount": "541"
  },
  {
    "Word": "executive",
    "FREQcount": "541"
  },
  {
    "Word": "fund",
    "FREQcount": "541"
  },
  {
    "Word": "worries",
    "FREQcount": "541"
  },
  {
    "Word": "capture",
    "FREQcount": "540"
  },
  {
    "Word": "drown",
    "FREQcount": "540"
  },
  {
    "Word": "fleet",
    "FREQcount": "540"
  },
  {
    "Word": "lungs",
    "FREQcount": "540"
  },
  {
    "Word": "multiple",
    "FREQcount": "540"
  },
  {
    "Word": "separated",
    "FREQcount": "540"
  },
  {
    "Word": "statue",
    "FREQcount": "540"
  },
  {
    "Word": "traitor",
    "FREQcount": "540"
  },
  {
    "Word": "twisted",
    "FREQcount": "540"
  },
  {
    "Word": "consequences",
    "FREQcount": "539"
  },
  {
    "Word": "forty",
    "FREQcount": "539"
  },
  {
    "Word": "philadelphia",
    "FREQcount": "539"
  },
  {
    "Word": "begun",
    "FREQcount": "538"
  },
  {
    "Word": "detroit",
    "FREQcount": "538"
  },
  {
    "Word": "discussed",
    "FREQcount": "538"
  },
  {
    "Word": "exposed",
    "FREQcount": "538"
  },
  {
    "Word": "kindly",
    "FREQcount": "538"
  },
  {
    "Word": "payment",
    "FREQcount": "538"
  },
  {
    "Word": "adorable",
    "FREQcount": "537"
  },
  {
    "Word": "bets",
    "FREQcount": "537"
  },
  {
    "Word": "compared",
    "FREQcount": "537"
  },
  {
    "Word": "countries",
    "FREQcount": "537"
  },
  {
    "Word": "elvis",
    "FREQcount": "537"
  },
  {
    "Word": "goat",
    "FREQcount": "537"
  },
  {
    "Word": "measure",
    "FREQcount": "537"
  },
  {
    "Word": "pork",
    "FREQcount": "537"
  },
  {
    "Word": "tested",
    "FREQcount": "537"
  },
  {
    "Word": "candles",
    "FREQcount": "536"
  },
  {
    "Word": "collar",
    "FREQcount": "536"
  },
  {
    "Word": "effective",
    "FREQcount": "536"
  },
  {
    "Word": "houston",
    "FREQcount": "536"
  },
  {
    "Word": "mars",
    "FREQcount": "535"
  },
  {
    "Word": "accounts",
    "FREQcount": "534"
  },
  {
    "Word": "hans",
    "FREQcount": "534"
  },
  {
    "Word": "injured",
    "FREQcount": "534"
  },
  {
    "Word": "lecture",
    "FREQcount": "534"
  },
  {
    "Word": "passport",
    "FREQcount": "534"
  },
  {
    "Word": "publicity",
    "FREQcount": "534"
  },
  {
    "Word": "roman",
    "FREQcount": "534"
  },
  {
    "Word": "root",
    "FREQcount": "534"
  },
  {
    "Word": "shared",
    "FREQcount": "534"
  },
  {
    "Word": "blond",
    "FREQcount": "533"
  },
  {
    "Word": "dice",
    "FREQcount": "533"
  },
  {
    "Word": "fixing",
    "FREQcount": "533"
  },
  {
    "Word": "grounds",
    "FREQcount": "533"
  },
  {
    "Word": "parked",
    "FREQcount": "533"
  },
  {
    "Word": "parole",
    "FREQcount": "533"
  },
  {
    "Word": "witches",
    "FREQcount": "533"
  },
  {
    "Word": "believing",
    "FREQcount": "532"
  },
  {
    "Word": "celebrating",
    "FREQcount": "532"
  },
  {
    "Word": "salesman",
    "FREQcount": "532"
  },
  {
    "Word": "twin",
    "FREQcount": "532"
  },
  {
    "Word": "booked",
    "FREQcount": "531"
  },
  {
    "Word": "bothered",
    "FREQcount": "531"
  },
  {
    "Word": "clubs",
    "FREQcount": "531"
  },
  {
    "Word": "crashed",
    "FREQcount": "531"
  },
  {
    "Word": "nanny",
    "FREQcount": "531"
  },
  {
    "Word": "paperwork",
    "FREQcount": "531"
  },
  {
    "Word": "plug",
    "FREQcount": "531"
  },
  {
    "Word": "rug",
    "FREQcount": "531"
  },
  {
    "Word": "rumor",
    "FREQcount": "531"
  },
  {
    "Word": "sidney",
    "FREQcount": "531"
  },
  {
    "Word": "cal",
    "FREQcount": "530"
  },
  {
    "Word": "meetings",
    "FREQcount": "530"
  },
  {
    "Word": "rode",
    "FREQcount": "530"
  },
  {
    "Word": "tellin",
    "FREQcount": "530"
  },
  {
    "Word": "unlike",
    "FREQcount": "530"
  },
  {
    "Word": "freaked",
    "FREQcount": "529"
  },
  {
    "Word": "lean",
    "FREQcount": "529"
  },
  {
    "Word": "narrator",
    "FREQcount": "529"
  },
  {
    "Word": "bee",
    "FREQcount": "528"
  },
  {
    "Word": "colors",
    "FREQcount": "528"
  },
  {
    "Word": "communication",
    "FREQcount": "528"
  },
  {
    "Word": "coop",
    "FREQcount": "528"
  },
  {
    "Word": "cooperate",
    "FREQcount": "528"
  },
  {
    "Word": "caroline",
    "FREQcount": "527"
  },
  {
    "Word": "levels",
    "FREQcount": "527"
  },
  {
    "Word": "nd",
    "FREQcount": "527"
  },
  {
    "Word": "spots",
    "FREQcount": "527"
  },
  {
    "Word": "worthy",
    "FREQcount": "527"
  },
  {
    "Word": "wrist",
    "FREQcount": "527"
  },
  {
    "Word": "conspiracy",
    "FREQcount": "526"
  },
  {
    "Word": "enormous",
    "FREQcount": "526"
  },
  {
    "Word": "misery",
    "FREQcount": "526"
  },
  {
    "Word": "obsessed",
    "FREQcount": "526"
  },
  {
    "Word": "punished",
    "FREQcount": "526"
  },
  {
    "Word": "reservation",
    "FREQcount": "526"
  },
  {
    "Word": "sunset",
    "FREQcount": "526"
  },
  {
    "Word": "announcement",
    "FREQcount": "525"
  },
  {
    "Word": "austin",
    "FREQcount": "525"
  },
  {
    "Word": "curtain",
    "FREQcount": "525"
  },
  {
    "Word": "drops",
    "FREQcount": "525"
  },
  {
    "Word": "kane",
    "FREQcount": "525"
  },
  {
    "Word": "nicky",
    "FREQcount": "525"
  },
  {
    "Word": "suggested",
    "FREQcount": "525"
  },
  {
    "Word": "driven",
    "FREQcount": "524"
  },
  {
    "Word": "fooled",
    "FREQcount": "524"
  },
  {
    "Word": "identified",
    "FREQcount": "524"
  },
  {
    "Word": "jeep",
    "FREQcount": "524"
  },
  {
    "Word": "locate",
    "FREQcount": "524"
  },
  {
    "Word": "relieved",
    "FREQcount": "524"
  },
  {
    "Word": "sharon",
    "FREQcount": "524"
  },
  {
    "Word": "specifically",
    "FREQcount": "524"
  },
  {
    "Word": "abuse",
    "FREQcount": "523"
  },
  {
    "Word": "ballet",
    "FREQcount": "523"
  },
  {
    "Word": "blues",
    "FREQcount": "523"
  },
  {
    "Word": "compliment",
    "FREQcount": "523"
  },
  {
    "Word": "magazines",
    "FREQcount": "523"
  },
  {
    "Word": "naughty",
    "FREQcount": "523"
  },
  {
    "Word": "skipper",
    "FREQcount": "523"
  },
  {
    "Word": "stiff",
    "FREQcount": "523"
  },
  {
    "Word": "sum",
    "FREQcount": "523"
  },
  {
    "Word": "unable",
    "FREQcount": "523"
  },
  {
    "Word": "album",
    "FREQcount": "522"
  },
  {
    "Word": "burger",
    "FREQcount": "522"
  },
  {
    "Word": "random",
    "FREQcount": "522"
  },
  {
    "Word": "spotted",
    "FREQcount": "522"
  },
  {
    "Word": "tense",
    "FREQcount": "522"
  },
  {
    "Word": "caesar",
    "FREQcount": "521"
  },
  {
    "Word": "concerns",
    "FREQcount": "521"
  },
  {
    "Word": "corporate",
    "FREQcount": "521"
  },
  {
    "Word": "happily",
    "FREQcount": "521"
  },
  {
    "Word": "august",
    "FREQcount": "520"
  },
  {
    "Word": "chickens",
    "FREQcount": "520"
  },
  {
    "Word": "gunshot",
    "FREQcount": "520"
  },
  {
    "Word": "impress",
    "FREQcount": "520"
  },
  {
    "Word": "injury",
    "FREQcount": "520"
  },
  {
    "Word": "intense",
    "FREQcount": "520"
  },
  {
    "Word": "jews",
    "FREQcount": "520"
  },
  {
    "Word": "praying",
    "FREQcount": "520"
  },
  {
    "Word": "rembrandt",
    "FREQcount": "520"
  },
  {
    "Word": "borrowed",
    "FREQcount": "519"
  },
  {
    "Word": "brick",
    "FREQcount": "519"
  },
  {
    "Word": "leon",
    "FREQcount": "519"
  },
  {
    "Word": "organized",
    "FREQcount": "519"
  },
  {
    "Word": "priority",
    "FREQcount": "519"
  },
  {
    "Word": "questioning",
    "FREQcount": "519"
  },
  {
    "Word": "raw",
    "FREQcount": "519"
  },
  {
    "Word": "slight",
    "FREQcount": "519"
  },
  {
    "Word": "structure",
    "FREQcount": "519"
  },
  {
    "Word": "complaint",
    "FREQcount": "518"
  },
  {
    "Word": "fried",
    "FREQcount": "518"
  },
  {
    "Word": "snakes",
    "FREQcount": "518"
  },
  {
    "Word": "leak",
    "FREQcount": "517"
  },
  {
    "Word": "registered",
    "FREQcount": "517"
  },
  {
    "Word": "sucked",
    "FREQcount": "516"
  },
  {
    "Word": "warrior",
    "FREQcount": "516"
  },
  {
    "Word": "worm",
    "FREQcount": "516"
  },
  {
    "Word": "bleed",
    "FREQcount": "515"
  },
  {
    "Word": "corpse",
    "FREQcount": "515"
  },
  {
    "Word": "document",
    "FREQcount": "515"
  },
  {
    "Word": "dynamite",
    "FREQcount": "515"
  },
  {
    "Word": "glove",
    "FREQcount": "515"
  },
  {
    "Word": "louder",
    "FREQcount": "515"
  },
  {
    "Word": "sober",
    "FREQcount": "515"
  },
  {
    "Word": "spider",
    "FREQcount": "515"
  },
  {
    "Word": "survival",
    "FREQcount": "515"
  },
  {
    "Word": "vodka",
    "FREQcount": "515"
  },
  {
    "Word": "branch",
    "FREQcount": "514"
  },
  {
    "Word": "worn",
    "FREQcount": "514"
  },
  {
    "Word": "budget",
    "FREQcount": "513"
  },
  {
    "Word": "deserved",
    "FREQcount": "513"
  },
  {
    "Word": "envelope",
    "FREQcount": "513"
  },
  {
    "Word": "novel",
    "FREQcount": "513"
  },
  {
    "Word": "pistol",
    "FREQcount": "513"
  },
  {
    "Word": "relatives",
    "FREQcount": "513"
  },
  {
    "Word": "shortly",
    "FREQcount": "513"
  },
  {
    "Word": "fraud",
    "FREQcount": "512"
  },
  {
    "Word": "shaw",
    "FREQcount": "512"
  },
  {
    "Word": "shotgun",
    "FREQcount": "512"
  },
  {
    "Word": "bucket",
    "FREQcount": "511"
  },
  {
    "Word": "clouds",
    "FREQcount": "511"
  },
  {
    "Word": "overnight",
    "FREQcount": "511"
  },
  {
    "Word": "application",
    "FREQcount": "510"
  },
  {
    "Word": "belonged",
    "FREQcount": "510"
  },
  {
    "Word": "experienced",
    "FREQcount": "510"
  },
  {
    "Word": "heels",
    "FREQcount": "510"
  },
  {
    "Word": "nicely",
    "FREQcount": "510"
  },
  {
    "Word": "russians",
    "FREQcount": "510"
  },
  {
    "Word": "buildings",
    "FREQcount": "509"
  },
  {
    "Word": "daughters",
    "FREQcount": "509"
  },
  {
    "Word": "excellency",
    "FREQcount": "509"
  },
  {
    "Word": "warehouse",
    "FREQcount": "509"
  },
  {
    "Word": "acid",
    "FREQcount": "508"
  },
  {
    "Word": "butler",
    "FREQcount": "508"
  },
  {
    "Word": "massive",
    "FREQcount": "508"
  },
  {
    "Word": "menu",
    "FREQcount": "508"
  },
  {
    "Word": "sits",
    "FREQcount": "508"
  },
  {
    "Word": "skirt",
    "FREQcount": "508"
  },
  {
    "Word": "stare",
    "FREQcount": "508"
  },
  {
    "Word": "inner",
    "FREQcount": "507"
  },
  {
    "Word": "scholarship",
    "FREQcount": "507"
  },
  {
    "Word": "signing",
    "FREQcount": "507"
  },
  {
    "Word": "causes",
    "FREQcount": "506"
  },
  {
    "Word": "collins",
    "FREQcount": "506"
  },
  {
    "Word": "constant",
    "FREQcount": "506"
  },
  {
    "Word": "counselor",
    "FREQcount": "506"
  },
  {
    "Word": "korean",
    "FREQcount": "506"
  },
  {
    "Word": "october",
    "FREQcount": "506"
  },
  {
    "Word": "provided",
    "FREQcount": "506"
  },
  {
    "Word": "solved",
    "FREQcount": "506"
  },
  {
    "Word": "tanks",
    "FREQcount": "506"
  },
  {
    "Word": "visitors",
    "FREQcount": "506"
  },
  {
    "Word": "centre",
    "FREQcount": "505"
  },
  {
    "Word": "cleveland",
    "FREQcount": "505"
  },
  {
    "Word": "festival",
    "FREQcount": "505"
  },
  {
    "Word": "imagined",
    "FREQcount": "505"
  },
  {
    "Word": "scum",
    "FREQcount": "505"
  },
  {
    "Word": "atlantic",
    "FREQcount": "504"
  },
  {
    "Word": "bachelor",
    "FREQcount": "504"
  },
  {
    "Word": "celebration",
    "FREQcount": "504"
  },
  {
    "Word": "chairs",
    "FREQcount": "504"
  },
  {
    "Word": "deadly",
    "FREQcount": "504"
  },
  {
    "Word": "depend",
    "FREQcount": "504"
  },
  {
    "Word": "examine",
    "FREQcount": "504"
  },
  {
    "Word": "oath",
    "FREQcount": "504"
  },
  {
    "Word": "practicing",
    "FREQcount": "504"
  },
  {
    "Word": "romeo",
    "FREQcount": "504"
  },
  {
    "Word": "screwing",
    "FREQcount": "504"
  },
  {
    "Word": "ashes",
    "FREQcount": "503"
  },
  {
    "Word": "disturbed",
    "FREQcount": "503"
  },
  {
    "Word": "pencil",
    "FREQcount": "503"
  },
  {
    "Word": "trucks",
    "FREQcount": "503"
  },
  {
    "Word": "arrangements",
    "FREQcount": "502"
  },
  {
    "Word": "bounce",
    "FREQcount": "502"
  },
  {
    "Word": "causing",
    "FREQcount": "502"
  },
  {
    "Word": "confusing",
    "FREQcount": "502"
  },
  {
    "Word": "fridge",
    "FREQcount": "502"
  },
  {
    "Word": "internal",
    "FREQcount": "502"
  },
  {
    "Word": "ties",
    "FREQcount": "502"
  },
  {
    "Word": "unfair",
    "FREQcount": "502"
  },
  {
    "Word": "burden",
    "FREQcount": "501"
  },
  {
    "Word": "core",
    "FREQcount": "501"
  },
  {
    "Word": "heroin",
    "FREQcount": "501"
  },
  {
    "Word": "shining",
    "FREQcount": "501"
  },
  {
    "Word": "championship",
    "FREQcount": "500"
  },
  {
    "Word": "columbo",
    "FREQcount": "500"
  },
  {
    "Word": "dummy",
    "FREQcount": "500"
  },
  {
    "Word": "graduation",
    "FREQcount": "500"
  },
  {
    "Word": "humble",
    "FREQcount": "500"
  },
  {
    "Word": "mummy",
    "FREQcount": "500"
  },
  {
    "Word": "appeared",
    "FREQcount": "499"
  },
  {
    "Word": "deals",
    "FREQcount": "499"
  },
  {
    "Word": "dramatic",
    "FREQcount": "499"
  },
  {
    "Word": "explode",
    "FREQcount": "499"
  },
  {
    "Word": "observe",
    "FREQcount": "499"
  },
  {
    "Word": "photographs",
    "FREQcount": "499"
  },
  {
    "Word": "raining",
    "FREQcount": "499"
  },
  {
    "Word": "retire",
    "FREQcount": "499"
  },
  {
    "Word": "roast",
    "FREQcount": "499"
  },
  {
    "Word": "shooter",
    "FREQcount": "499"
  },
  {
    "Word": "silk",
    "FREQcount": "499"
  },
  {
    "Word": "wha",
    "FREQcount": "499"
  },
  {
    "Word": "announce",
    "FREQcount": "498"
  },
  {
    "Word": "bartender",
    "FREQcount": "498"
  },
  {
    "Word": "differently",
    "FREQcount": "498"
  },
  {
    "Word": "fires",
    "FREQcount": "498"
  },
  {
    "Word": "ransom",
    "FREQcount": "498"
  },
  {
    "Word": "coin",
    "FREQcount": "497"
  },
  {
    "Word": "dock",
    "FREQcount": "497"
  },
  {
    "Word": "dresses",
    "FREQcount": "497"
  },
  {
    "Word": "execution",
    "FREQcount": "497"
  },
  {
    "Word": "gut",
    "FREQcount": "497"
  },
  {
    "Word": "investment",
    "FREQcount": "497"
  },
  {
    "Word": "necklace",
    "FREQcount": "497"
  },
  {
    "Word": "sealed",
    "FREQcount": "497"
  },
  {
    "Word": "seventh",
    "FREQcount": "497"
  },
  {
    "Word": "surprises",
    "FREQcount": "497"
  },
  {
    "Word": "suspected",
    "FREQcount": "497"
  },
  {
    "Word": "taxes",
    "FREQcount": "497"
  },
  {
    "Word": "bait",
    "FREQcount": "496"
  },
  {
    "Word": "bald",
    "FREQcount": "496"
  },
  {
    "Word": "hats",
    "FREQcount": "496"
  },
  {
    "Word": "lit",
    "FREQcount": "496"
  },
  {
    "Word": "queens",
    "FREQcount": "496"
  },
  {
    "Word": "tarzan",
    "FREQcount": "496"
  },
  {
    "Word": "absurd",
    "FREQcount": "495"
  },
  {
    "Word": "blank",
    "FREQcount": "495"
  },
  {
    "Word": "blessing",
    "FREQcount": "495"
  },
  {
    "Word": "demands",
    "FREQcount": "495"
  },
  {
    "Word": "humanity",
    "FREQcount": "495"
  },
  {
    "Word": "reese",
    "FREQcount": "495"
  },
  {
    "Word": "copies",
    "FREQcount": "494"
  },
  {
    "Word": "directions",
    "FREQcount": "494"
  },
  {
    "Word": "fee",
    "FREQcount": "494"
  },
  {
    "Word": "filling",
    "FREQcount": "494"
  },
  {
    "Word": "grip",
    "FREQcount": "494"
  },
  {
    "Word": "hostages",
    "FREQcount": "494"
  },
  {
    "Word": "kidney",
    "FREQcount": "494"
  },
  {
    "Word": "scientists",
    "FREQcount": "494"
  },
  {
    "Word": "sworn",
    "FREQcount": "494"
  },
  {
    "Word": "ape",
    "FREQcount": "493"
  },
  {
    "Word": "atmosphere",
    "FREQcount": "493"
  },
  {
    "Word": "bench",
    "FREQcount": "493"
  },
  {
    "Word": "pacific",
    "FREQcount": "493"
  },
  {
    "Word": "polish",
    "FREQcount": "493"
  },
  {
    "Word": "punish",
    "FREQcount": "493"
  },
  {
    "Word": "added",
    "FREQcount": "492"
  },
  {
    "Word": "connect",
    "FREQcount": "492"
  },
  {
    "Word": "cracked",
    "FREQcount": "492"
  },
  {
    "Word": "pancakes",
    "FREQcount": "492"
  },
  {
    "Word": "spray",
    "FREQcount": "492"
  },
  {
    "Word": "aliens",
    "FREQcount": "491"
  },
  {
    "Word": "floating",
    "FREQcount": "491"
  },
  {
    "Word": "gathered",
    "FREQcount": "491"
  },
  {
    "Word": "losers",
    "FREQcount": "491"
  },
  {
    "Word": "marines",
    "FREQcount": "491"
  },
  {
    "Word": "porch",
    "FREQcount": "491"
  },
  {
    "Word": "tires",
    "FREQcount": "491"
  },
  {
    "Word": "develop",
    "FREQcount": "490"
  },
  {
    "Word": "sandwiches",
    "FREQcount": "490"
  },
  {
    "Word": "autopsy",
    "FREQcount": "489"
  },
  {
    "Word": "positions",
    "FREQcount": "489"
  },
  {
    "Word": "requires",
    "FREQcount": "489"
  },
  {
    "Word": "adults",
    "FREQcount": "488"
  },
  {
    "Word": "burnt",
    "FREQcount": "488"
  },
  {
    "Word": "daylight",
    "FREQcount": "488"
  },
  {
    "Word": "lynn",
    "FREQcount": "488"
  },
  {
    "Word": "mortal",
    "FREQcount": "488"
  },
  {
    "Word": "pace",
    "FREQcount": "488"
  },
  {
    "Word": "plants",
    "FREQcount": "488"
  },
  {
    "Word": "quote",
    "FREQcount": "488"
  },
  {
    "Word": "sorts",
    "FREQcount": "488"
  },
  {
    "Word": "terrified",
    "FREQcount": "488"
  },
  {
    "Word": "benjamin",
    "FREQcount": "487"
  },
  {
    "Word": "envy",
    "FREQcount": "487"
  },
  {
    "Word": "hallway",
    "FREQcount": "487"
  },
  {
    "Word": "relations",
    "FREQcount": "487"
  },
  {
    "Word": "bearing",
    "FREQcount": "486"
  },
  {
    "Word": "characters",
    "FREQcount": "486"
  },
  {
    "Word": "interfere",
    "FREQcount": "486"
  },
  {
    "Word": "li",
    "FREQcount": "486"
  },
  {
    "Word": "mill",
    "FREQcount": "486"
  },
  {
    "Word": "niece",
    "FREQcount": "486"
  },
  {
    "Word": "signals",
    "FREQcount": "486"
  },
  {
    "Word": "alexander",
    "FREQcount": "485"
  },
  {
    "Word": "cooked",
    "FREQcount": "485"
  },
  {
    "Word": "delicate",
    "FREQcount": "485"
  },
  {
    "Word": "en",
    "FREQcount": "485"
  },
  {
    "Word": "lesbian",
    "FREQcount": "485"
  },
  {
    "Word": "loses",
    "FREQcount": "485"
  },
  {
    "Word": "prayers",
    "FREQcount": "485"
  },
  {
    "Word": "scale",
    "FREQcount": "485"
  },
  {
    "Word": "smack",
    "FREQcount": "485"
  },
  {
    "Word": "stores",
    "FREQcount": "485"
  },
  {
    "Word": "strikes",
    "FREQcount": "485"
  },
  {
    "Word": "sweep",
    "FREQcount": "485"
  },
  {
    "Word": "therapist",
    "FREQcount": "485"
  },
  {
    "Word": "grows",
    "FREQcount": "484"
  },
  {
    "Word": "previous",
    "FREQcount": "484"
  },
  {
    "Word": "retreat",
    "FREQcount": "484"
  },
  {
    "Word": "towels",
    "FREQcount": "484"
  },
  {
    "Word": "awhile",
    "FREQcount": "483"
  },
  {
    "Word": "cent",
    "FREQcount": "483"
  },
  {
    "Word": "chart",
    "FREQcount": "483"
  },
  {
    "Word": "helmet",
    "FREQcount": "483"
  },
  {
    "Word": "investigate",
    "FREQcount": "483"
  },
  {
    "Word": "louie",
    "FREQcount": "483"
  },
  {
    "Word": "scheduled",
    "FREQcount": "483"
  },
  {
    "Word": "aircraft",
    "FREQcount": "482"
  },
  {
    "Word": "arrangement",
    "FREQcount": "482"
  },
  {
    "Word": "farewell",
    "FREQcount": "482"
  },
  {
    "Word": "fathers",
    "FREQcount": "482"
  },
  {
    "Word": "fog",
    "FREQcount": "482"
  },
  {
    "Word": "physics",
    "FREQcount": "482"
  },
  {
    "Word": "praise",
    "FREQcount": "482"
  },
  {
    "Word": "stabbed",
    "FREQcount": "482"
  },
  {
    "Word": "strategy",
    "FREQcount": "482"
  },
  {
    "Word": "succeed",
    "FREQcount": "482"
  },
  {
    "Word": "discussing",
    "FREQcount": "481"
  },
  {
    "Word": "hudson",
    "FREQcount": "481"
  },
  {
    "Word": "moscow",
    "FREQcount": "481"
  },
  {
    "Word": "cows",
    "FREQcount": "480"
  },
  {
    "Word": "impact",
    "FREQcount": "480"
  },
  {
    "Word": "sailing",
    "FREQcount": "480"
  },
  {
    "Word": "scan",
    "FREQcount": "480"
  },
  {
    "Word": "severe",
    "FREQcount": "480"
  },
  {
    "Word": "shorts",
    "FREQcount": "480"
  },
  {
    "Word": "tons",
    "FREQcount": "480"
  },
  {
    "Word": "wells",
    "FREQcount": "480"
  },
  {
    "Word": "burke",
    "FREQcount": "479"
  },
  {
    "Word": "chaos",
    "FREQcount": "479"
  },
  {
    "Word": "civilian",
    "FREQcount": "479"
  },
  {
    "Word": "maniac",
    "FREQcount": "479"
  },
  {
    "Word": "triple",
    "FREQcount": "479"
  },
  {
    "Word": "types",
    "FREQcount": "479"
  },
  {
    "Word": "cellar",
    "FREQcount": "478"
  },
  {
    "Word": "covers",
    "FREQcount": "478"
  },
  {
    "Word": "documents",
    "FREQcount": "478"
  },
  {
    "Word": "flush",
    "FREQcount": "478"
  },
  {
    "Word": "oldest",
    "FREQcount": "478"
  },
  {
    "Word": "owes",
    "FREQcount": "478"
  },
  {
    "Word": "danced",
    "FREQcount": "477"
  },
  {
    "Word": "independent",
    "FREQcount": "477"
  },
  {
    "Word": "studies",
    "FREQcount": "477"
  },
  {
    "Word": "vessel",
    "FREQcount": "477"
  },
  {
    "Word": "alternative",
    "FREQcount": "476"
  },
  {
    "Word": "hallelujah",
    "FREQcount": "476"
  },
  {
    "Word": "height",
    "FREQcount": "476"
  },
  {
    "Word": "motherfucking",
    "FREQcount": "476"
  },
  {
    "Word": "reveal",
    "FREQcount": "476"
  },
  {
    "Word": "stella",
    "FREQcount": "476"
  },
  {
    "Word": "deed",
    "FREQcount": "475"
  },
  {
    "Word": "meets",
    "FREQcount": "475"
  },
  {
    "Word": "thompson",
    "FREQcount": "475"
  },
  {
    "Word": "volunteer",
    "FREQcount": "475"
  },
  {
    "Word": "brandon",
    "FREQcount": "474"
  },
  {
    "Word": "calvin",
    "FREQcount": "474"
  },
  {
    "Word": "debate",
    "FREQcount": "474"
  },
  {
    "Word": "glorious",
    "FREQcount": "474"
  },
  {
    "Word": "upside",
    "FREQcount": "474"
  },
  {
    "Word": "amber",
    "FREQcount": "473"
  },
  {
    "Word": "error",
    "FREQcount": "473"
  },
  {
    "Word": "faint",
    "FREQcount": "473"
  },
  {
    "Word": "handed",
    "FREQcount": "473"
  },
  {
    "Word": "stinking",
    "FREQcount": "473"
  },
  {
    "Word": "worthless",
    "FREQcount": "473"
  },
  {
    "Word": "ladder",
    "FREQcount": "472"
  },
  {
    "Word": "groups",
    "FREQcount": "471"
  },
  {
    "Word": "physically",
    "FREQcount": "471"
  },
  {
    "Word": "telegram",
    "FREQcount": "471"
  },
  {
    "Word": "adams",
    "FREQcount": "470"
  },
  {
    "Word": "arts",
    "FREQcount": "470"
  },
  {
    "Word": "gasps",
    "FREQcount": "470"
  },
  {
    "Word": "hears",
    "FREQcount": "470"
  },
  {
    "Word": "poet",
    "FREQcount": "470"
  },
  {
    "Word": "resources",
    "FREQcount": "470"
  },
  {
    "Word": "web",
    "FREQcount": "470"
  },
  {
    "Word": "whatsoever",
    "FREQcount": "470"
  },
  {
    "Word": "willy",
    "FREQcount": "470"
  },
  {
    "Word": "amusing",
    "FREQcount": "469"
  },
  {
    "Word": "arrives",
    "FREQcount": "469"
  },
  {
    "Word": "ash",
    "FREQcount": "469"
  },
  {
    "Word": "bonus",
    "FREQcount": "469"
  },
  {
    "Word": "bree",
    "FREQcount": "469"
  },
  {
    "Word": "delightful",
    "FREQcount": "469"
  },
  {
    "Word": "grey",
    "FREQcount": "469"
  },
  {
    "Word": "hint",
    "FREQcount": "469"
  },
  {
    "Word": "stunt",
    "FREQcount": "469"
  },
  {
    "Word": "closely",
    "FREQcount": "468"
  },
  {
    "Word": "fairly",
    "FREQcount": "468"
  },
  {
    "Word": "horror",
    "FREQcount": "468"
  },
  {
    "Word": "located",
    "FREQcount": "468"
  },
  {
    "Word": "picks",
    "FREQcount": "468"
  },
  {
    "Word": "rumors",
    "FREQcount": "468"
  },
  {
    "Word": "admitted",
    "FREQcount": "467"
  },
  {
    "Word": "codes",
    "FREQcount": "467"
  },
  {
    "Word": "fears",
    "FREQcount": "467"
  },
  {
    "Word": "jeremy",
    "FREQcount": "467"
  },
  {
    "Word": "tips",
    "FREQcount": "467"
  },
  {
    "Word": "betray",
    "FREQcount": "466"
  },
  {
    "Word": "holidays",
    "FREQcount": "466"
  },
  {
    "Word": "investigating",
    "FREQcount": "466"
  },
  {
    "Word": "madison",
    "FREQcount": "466"
  },
  {
    "Word": "rented",
    "FREQcount": "466"
  },
  {
    "Word": "snack",
    "FREQcount": "466"
  },
  {
    "Word": "alliance",
    "FREQcount": "465"
  },
  {
    "Word": "conclusion",
    "FREQcount": "465"
  },
  {
    "Word": "faithful",
    "FREQcount": "465"
  },
  {
    "Word": "photographer",
    "FREQcount": "465"
  },
  {
    "Word": "popcorn",
    "FREQcount": "465"
  },
  {
    "Word": "wars",
    "FREQcount": "465"
  },
  {
    "Word": "magical",
    "FREQcount": "464"
  },
  {
    "Word": "penalty",
    "FREQcount": "464"
  },
  {
    "Word": "phrase",
    "FREQcount": "464"
  },
  {
    "Word": "population",
    "FREQcount": "464"
  },
  {
    "Word": "recovery",
    "FREQcount": "464"
  },
  {
    "Word": "reed",
    "FREQcount": "464"
  },
  {
    "Word": "somewhat",
    "FREQcount": "464"
  },
  {
    "Word": "thieves",
    "FREQcount": "464"
  },
  {
    "Word": "tournament",
    "FREQcount": "464"
  },
  {
    "Word": "dale",
    "FREQcount": "463"
  },
  {
    "Word": "damaged",
    "FREQcount": "463"
  },
  {
    "Word": "disturbing",
    "FREQcount": "463"
  },
  {
    "Word": "outer",
    "FREQcount": "463"
  },
  {
    "Word": "chew",
    "FREQcount": "462"
  },
  {
    "Word": "crawling",
    "FREQcount": "462"
  },
  {
    "Word": "described",
    "FREQcount": "462"
  },
  {
    "Word": "discipline",
    "FREQcount": "462"
  },
  {
    "Word": "rex",
    "FREQcount": "462"
  },
  {
    "Word": "roads",
    "FREQcount": "462"
  },
  {
    "Word": "takin",
    "FREQcount": "462"
  },
  {
    "Word": "washing",
    "FREQcount": "462"
  },
  {
    "Word": "cart",
    "FREQcount": "461"
  },
  {
    "Word": "coffin",
    "FREQcount": "461"
  },
  {
    "Word": "explains",
    "FREQcount": "461"
  },
  {
    "Word": "flame",
    "FREQcount": "461"
  },
  {
    "Word": "perimeter",
    "FREQcount": "461"
  },
  {
    "Word": "profession",
    "FREQcount": "461"
  },
  {
    "Word": "wax",
    "FREQcount": "461"
  },
  {
    "Word": "kindness",
    "FREQcount": "460"
  },
  {
    "Word": "ultimate",
    "FREQcount": "460"
  },
  {
    "Word": "barking",
    "FREQcount": "459"
  },
  {
    "Word": "bret",
    "FREQcount": "459"
  },
  {
    "Word": "cargo",
    "FREQcount": "459"
  },
  {
    "Word": "gently",
    "FREQcount": "459"
  },
  {
    "Word": "hopper",
    "FREQcount": "459"
  },
  {
    "Word": "terror",
    "FREQcount": "459"
  },
  {
    "Word": "vampires",
    "FREQcount": "459"
  },
  {
    "Word": "yankee",
    "FREQcount": "459"
  },
  {
    "Word": "associate",
    "FREQcount": "458"
  },
  {
    "Word": "certificate",
    "FREQcount": "458"
  },
  {
    "Word": "coroner",
    "FREQcount": "458"
  },
  {
    "Word": "diary",
    "FREQcount": "458"
  },
  {
    "Word": "recognized",
    "FREQcount": "458"
  },
  {
    "Word": "sock",
    "FREQcount": "458"
  },
  {
    "Word": "swamp",
    "FREQcount": "458"
  },
  {
    "Word": "breast",
    "FREQcount": "457"
  },
  {
    "Word": "broadcast",
    "FREQcount": "457"
  },
  {
    "Word": "closest",
    "FREQcount": "457"
  },
  {
    "Word": "jock",
    "FREQcount": "457"
  },
  {
    "Word": "kings",
    "FREQcount": "457"
  },
  {
    "Word": "lighter",
    "FREQcount": "457"
  },
  {
    "Word": "preparing",
    "FREQcount": "457"
  },
  {
    "Word": "russ",
    "FREQcount": "457"
  },
  {
    "Word": "stall",
    "FREQcount": "457"
  },
  {
    "Word": "appetite",
    "FREQcount": "456"
  },
  {
    "Word": "areas",
    "FREQcount": "456"
  },
  {
    "Word": "barbecue",
    "FREQcount": "456"
  },
  {
    "Word": "crowded",
    "FREQcount": "456"
  },
  {
    "Word": "fluid",
    "FREQcount": "456"
  },
  {
    "Word": "gamble",
    "FREQcount": "456"
  },
  {
    "Word": "hopeless",
    "FREQcount": "456"
  },
  {
    "Word": "hostile",
    "FREQcount": "456"
  },
  {
    "Word": "obey",
    "FREQcount": "456"
  },
  {
    "Word": "planted",
    "FREQcount": "456"
  },
  {
    "Word": "ritual",
    "FREQcount": "456"
  },
  {
    "Word": "technique",
    "FREQcount": "456"
  },
  {
    "Word": "various",
    "FREQcount": "456"
  },
  {
    "Word": "dug",
    "FREQcount": "455"
  },
  {
    "Word": "motorcycle",
    "FREQcount": "455"
  },
  {
    "Word": "noah",
    "FREQcount": "455"
  },
  {
    "Word": "sins",
    "FREQcount": "455"
  },
  {
    "Word": "whack",
    "FREQcount": "455"
  },
  {
    "Word": "auction",
    "FREQcount": "454"
  },
  {
    "Word": "contrary",
    "FREQcount": "454"
  },
  {
    "Word": "creek",
    "FREQcount": "454"
  },
  {
    "Word": "jr",
    "FREQcount": "454"
  },
  {
    "Word": "weakness",
    "FREQcount": "454"
  },
  {
    "Word": "doris",
    "FREQcount": "453"
  },
  {
    "Word": "journal",
    "FREQcount": "453"
  },
  {
    "Word": "leaders",
    "FREQcount": "453"
  },
  {
    "Word": "oven",
    "FREQcount": "453"
  },
  {
    "Word": "spiritual",
    "FREQcount": "453"
  },
  {
    "Word": "tender",
    "FREQcount": "453"
  },
  {
    "Word": "worlds",
    "FREQcount": "453"
  },
  {
    "Word": "dial",
    "FREQcount": "452"
  },
  {
    "Word": "storage",
    "FREQcount": "452"
  },
  {
    "Word": "val",
    "FREQcount": "452"
  },
  {
    "Word": "advanced",
    "FREQcount": "451"
  },
  {
    "Word": "cd",
    "FREQcount": "451"
  },
  {
    "Word": "grades",
    "FREQcount": "451"
  },
  {
    "Word": "helio",
    "FREQcount": "451"
  },
  {
    "Word": "marilyn",
    "FREQcount": "451"
  },
  {
    "Word": "models",
    "FREQcount": "451"
  },
  {
    "Word": "constantly",
    "FREQcount": "450"
  },
  {
    "Word": "embarrass",
    "FREQcount": "450"
  },
  {
    "Word": "fork",
    "FREQcount": "450"
  },
  {
    "Word": "melissa",
    "FREQcount": "450"
  },
  {
    "Word": "quitting",
    "FREQcount": "450"
  },
  {
    "Word": "repair",
    "FREQcount": "450"
  },
  {
    "Word": "reunion",
    "FREQcount": "450"
  },
  {
    "Word": "accidentally",
    "FREQcount": "449"
  },
  {
    "Word": "apologies",
    "FREQcount": "449"
  },
  {
    "Word": "filed",
    "FREQcount": "449"
  },
  {
    "Word": "lipstick",
    "FREQcount": "449"
  },
  {
    "Word": "pepper",
    "FREQcount": "449"
  },
  {
    "Word": "cities",
    "FREQcount": "448"
  },
  {
    "Word": "cough",
    "FREQcount": "448"
  },
  {
    "Word": "proposal",
    "FREQcount": "448"
  },
  {
    "Word": "protest",
    "FREQcount": "448"
  },
  {
    "Word": "recovered",
    "FREQcount": "448"
  },
  {
    "Word": "rolls",
    "FREQcount": "448"
  },
  {
    "Word": "unexpected",
    "FREQcount": "448"
  },
  {
    "Word": "goddess",
    "FREQcount": "447"
  },
  {
    "Word": "hurricane",
    "FREQcount": "447"
  },
  {
    "Word": "mankind",
    "FREQcount": "447"
  },
  {
    "Word": "november",
    "FREQcount": "447"
  },
  {
    "Word": "returns",
    "FREQcount": "447"
  },
  {
    "Word": "stab",
    "FREQcount": "447"
  },
  {
    "Word": "supreme",
    "FREQcount": "447"
  },
  {
    "Word": "waking",
    "FREQcount": "447"
  },
  {
    "Word": "almighty",
    "FREQcount": "446"
  },
  {
    "Word": "infection",
    "FREQcount": "446"
  },
  {
    "Word": "swore",
    "FREQcount": "446"
  },
  {
    "Word": "visitor",
    "FREQcount": "446"
  },
  {
    "Word": "wrestling",
    "FREQcount": "446"
  },
  {
    "Word": "beam",
    "FREQcount": "445"
  },
  {
    "Word": "cease",
    "FREQcount": "445"
  },
  {
    "Word": "reads",
    "FREQcount": "445"
  },
  {
    "Word": "anyways",
    "FREQcount": "444"
  },
  {
    "Word": "buttons",
    "FREQcount": "444"
  },
  {
    "Word": "cannon",
    "FREQcount": "444"
  },
  {
    "Word": "colour",
    "FREQcount": "444"
  },
  {
    "Word": "conflict",
    "FREQcount": "444"
  },
  {
    "Word": "crossing",
    "FREQcount": "444"
  },
  {
    "Word": "deer",
    "FREQcount": "444"
  },
  {
    "Word": "flu",
    "FREQcount": "444"
  },
  {
    "Word": "fortunately",
    "FREQcount": "444"
  },
  {
    "Word": "objects",
    "FREQcount": "444"
  },
  {
    "Word": "ohio",
    "FREQcount": "444"
  },
  {
    "Word": "primary",
    "FREQcount": "444"
  },
  {
    "Word": "shirts",
    "FREQcount": "444"
  },
  {
    "Word": "shrimp",
    "FREQcount": "444"
  },
  {
    "Word": "cemetery",
    "FREQcount": "443"
  },
  {
    "Word": "balloon",
    "FREQcount": "442"
  },
  {
    "Word": "chemistry",
    "FREQcount": "442"
  },
  {
    "Word": "samples",
    "FREQcount": "442"
  },
  {
    "Word": "sexually",
    "FREQcount": "442"
  },
  {
    "Word": "excuses",
    "FREQcount": "441"
  },
  {
    "Word": "fame",
    "FREQcount": "441"
  },
  {
    "Word": "harmless",
    "FREQcount": "441"
  },
  {
    "Word": "stuffed",
    "FREQcount": "441"
  },
  {
    "Word": "throne",
    "FREQcount": "441"
  },
  {
    "Word": "tin",
    "FREQcount": "441"
  },
  {
    "Word": "drain",
    "FREQcount": "440"
  },
  {
    "Word": "electrical",
    "FREQcount": "440"
  },
  {
    "Word": "fold",
    "FREQcount": "440"
  },
  {
    "Word": "morgue",
    "FREQcount": "440"
  },
  {
    "Word": "pimp",
    "FREQcount": "440"
  },
  {
    "Word": "requested",
    "FREQcount": "440"
  },
  {
    "Word": "rig",
    "FREQcount": "440"
  },
  {
    "Word": "setup",
    "FREQcount": "440"
  },
  {
    "Word": "activities",
    "FREQcount": "439"
  },
  {
    "Word": "distant",
    "FREQcount": "439"
  },
  {
    "Word": "tan",
    "FREQcount": "439"
  },
  {
    "Word": "briefcase",
    "FREQcount": "438"
  },
  {
    "Word": "clarence",
    "FREQcount": "438"
  },
  {
    "Word": "evans",
    "FREQcount": "438"
  },
  {
    "Word": "petty",
    "FREQcount": "438"
  },
  {
    "Word": "symbol",
    "FREQcount": "438"
  },
  {
    "Word": "vicious",
    "FREQcount": "438"
  },
  {
    "Word": "beds",
    "FREQcount": "437"
  },
  {
    "Word": "del",
    "FREQcount": "437"
  },
  {
    "Word": "sleepy",
    "FREQcount": "437"
  },
  {
    "Word": "vulnerable",
    "FREQcount": "437"
  },
  {
    "Word": "banging",
    "FREQcount": "436"
  },
  {
    "Word": "comrade",
    "FREQcount": "436"
  },
  {
    "Word": "convenient",
    "FREQcount": "436"
  },
  {
    "Word": "forbid",
    "FREQcount": "436"
  },
  {
    "Word": "hack",
    "FREQcount": "436"
  },
  {
    "Word": "increase",
    "FREQcount": "436"
  },
  {
    "Word": "raid",
    "FREQcount": "436"
  },
  {
    "Word": "reporters",
    "FREQcount": "436"
  },
  {
    "Word": "seated",
    "FREQcount": "436"
  },
  {
    "Word": "solo",
    "FREQcount": "436"
  },
  {
    "Word": "tension",
    "FREQcount": "436"
  },
  {
    "Word": "burst",
    "FREQcount": "435"
  },
  {
    "Word": "curiosity",
    "FREQcount": "435"
  },
  {
    "Word": "display",
    "FREQcount": "435"
  },
  {
    "Word": "eli",
    "FREQcount": "435"
  },
  {
    "Word": "scares",
    "FREQcount": "435"
  },
  {
    "Word": "slice",
    "FREQcount": "435"
  },
  {
    "Word": "threaten",
    "FREQcount": "435"
  },
  {
    "Word": "transmission",
    "FREQcount": "435"
  },
  {
    "Word": "butcher",
    "FREQcount": "434"
  },
  {
    "Word": "candidate",
    "FREQcount": "434"
  },
  {
    "Word": "communicate",
    "FREQcount": "434"
  },
  {
    "Word": "gallery",
    "FREQcount": "434"
  },
  {
    "Word": "invasion",
    "FREQcount": "434"
  },
  {
    "Word": "wee",
    "FREQcount": "434"
  },
  {
    "Word": "laser",
    "FREQcount": "433"
  },
  {
    "Word": "lunatic",
    "FREQcount": "433"
  },
  {
    "Word": "rank",
    "FREQcount": "433"
  },
  {
    "Word": "robe",
    "FREQcount": "433"
  },
  {
    "Word": "til",
    "FREQcount": "433"
  },
  {
    "Word": "woody",
    "FREQcount": "433"
  },
  {
    "Word": "compete",
    "FREQcount": "432"
  },
  {
    "Word": "drum",
    "FREQcount": "432"
  },
  {
    "Word": "ducks",
    "FREQcount": "432"
  },
  {
    "Word": "fisher",
    "FREQcount": "432"
  },
  {
    "Word": "kiddo",
    "FREQcount": "432"
  },
  {
    "Word": "limo",
    "FREQcount": "432"
  },
  {
    "Word": "reference",
    "FREQcount": "432"
  },
  {
    "Word": "regarding",
    "FREQcount": "432"
  },
  {
    "Word": "rolled",
    "FREQcount": "432"
  },
  {
    "Word": "scar",
    "FREQcount": "432"
  },
  {
    "Word": "senses",
    "FREQcount": "432"
  },
  {
    "Word": "spill",
    "FREQcount": "432"
  },
  {
    "Word": "spoiled",
    "FREQcount": "432"
  },
  {
    "Word": "values",
    "FREQcount": "432"
  },
  {
    "Word": "affection",
    "FREQcount": "431"
  },
  {
    "Word": "arnold",
    "FREQcount": "431"
  },
  {
    "Word": "chased",
    "FREQcount": "431"
  },
  {
    "Word": "crushed",
    "FREQcount": "431"
  },
  {
    "Word": "disappoint",
    "FREQcount": "431"
  },
  {
    "Word": "madness",
    "FREQcount": "431"
  },
  {
    "Word": "nickel",
    "FREQcount": "431"
  },
  {
    "Word": "resistance",
    "FREQcount": "431"
  },
  {
    "Word": "retirement",
    "FREQcount": "431"
  },
  {
    "Word": "tremendous",
    "FREQcount": "431"
  },
  {
    "Word": "adopted",
    "FREQcount": "430"
  },
  {
    "Word": "australia",
    "FREQcount": "430"
  },
  {
    "Word": "betting",
    "FREQcount": "430"
  },
  {
    "Word": "dizzy",
    "FREQcount": "430"
  },
  {
    "Word": "granny",
    "FREQcount": "430"
  },
  {
    "Word": "software",
    "FREQcount": "430"
  },
  {
    "Word": "anonymous",
    "FREQcount": "429"
  },
  {
    "Word": "haircut",
    "FREQcount": "429"
  },
  {
    "Word": "lads",
    "FREQcount": "429"
  },
  {
    "Word": "recorded",
    "FREQcount": "429"
  },
  {
    "Word": "rising",
    "FREQcount": "429"
  },
  {
    "Word": "thrill",
    "FREQcount": "429"
  },
  {
    "Word": "approval",
    "FREQcount": "428"
  },
  {
    "Word": "determine",
    "FREQcount": "428"
  },
  {
    "Word": "fry",
    "FREQcount": "428"
  },
  {
    "Word": "horny",
    "FREQcount": "428"
  },
  {
    "Word": "inn",
    "FREQcount": "428"
  },
  {
    "Word": "instincts",
    "FREQcount": "428"
  },
  {
    "Word": "scenes",
    "FREQcount": "428"
  },
  {
    "Word": "sequence",
    "FREQcount": "428"
  },
  {
    "Word": "courtroom",
    "FREQcount": "427"
  },
  {
    "Word": "harrison",
    "FREQcount": "427"
  },
  {
    "Word": "refrigerator",
    "FREQcount": "427"
  },
  {
    "Word": "alibi",
    "FREQcount": "426"
  },
  {
    "Word": "ceiling",
    "FREQcount": "426"
  },
  {
    "Word": "compare",
    "FREQcount": "426"
  },
  {
    "Word": "judges",
    "FREQcount": "426"
  },
  {
    "Word": "ribs",
    "FREQcount": "426"
  },
  {
    "Word": "sympathy",
    "FREQcount": "426"
  },
  {
    "Word": "wig",
    "FREQcount": "426"
  },
  {
    "Word": "bare",
    "FREQcount": "425"
  },
  {
    "Word": "cabinet",
    "FREQcount": "425"
  },
  {
    "Word": "cane",
    "FREQcount": "425"
  },
  {
    "Word": "civilization",
    "FREQcount": "425"
  },
  {
    "Word": "delta",
    "FREQcount": "425"
  },
  {
    "Word": "doorbell",
    "FREQcount": "425"
  },
  {
    "Word": "indicate",
    "FREQcount": "425"
  },
  {
    "Word": "nearby",
    "FREQcount": "425"
  },
  {
    "Word": "pointing",
    "FREQcount": "425"
  },
  {
    "Word": "formal",
    "FREQcount": "424"
  },
  {
    "Word": "generally",
    "FREQcount": "424"
  },
  {
    "Word": "jar",
    "FREQcount": "424"
  },
  {
    "Word": "plague",
    "FREQcount": "424"
  },
  {
    "Word": "apples",
    "FREQcount": "423"
  },
  {
    "Word": "emotion",
    "FREQcount": "423"
  },
  {
    "Word": "felix",
    "FREQcount": "423"
  },
  {
    "Word": "reminded",
    "FREQcount": "423"
  },
  {
    "Word": "tore",
    "FREQcount": "423"
  },
  {
    "Word": "tramp",
    "FREQcount": "423"
  },
  {
    "Word": "arrival",
    "FREQcount": "422"
  },
  {
    "Word": "footage",
    "FREQcount": "422"
  },
  {
    "Word": "freaks",
    "FREQcount": "422"
  },
  {
    "Word": "fur",
    "FREQcount": "422"
  },
  {
    "Word": "infected",
    "FREQcount": "422"
  },
  {
    "Word": "misunderstanding",
    "FREQcount": "422"
  },
  {
    "Word": "philosophy",
    "FREQcount": "422"
  },
  {
    "Word": "prior",
    "FREQcount": "422"
  },
  {
    "Word": "scores",
    "FREQcount": "422"
  },
  {
    "Word": "sheila",
    "FREQcount": "422"
  },
  {
    "Word": "cocaine",
    "FREQcount": "421"
  },
  {
    "Word": "denver",
    "FREQcount": "421"
  },
  {
    "Word": "depth",
    "FREQcount": "421"
  },
  {
    "Word": "illusion",
    "FREQcount": "421"
  },
  {
    "Word": "native",
    "FREQcount": "421"
  },
  {
    "Word": "phony",
    "FREQcount": "421"
  },
  {
    "Word": "qualified",
    "FREQcount": "421"
  },
  {
    "Word": "replaced",
    "FREQcount": "421"
  },
  {
    "Word": "residence",
    "FREQcount": "421"
  },
  {
    "Word": "smash",
    "FREQcount": "421"
  },
  {
    "Word": "tossed",
    "FREQcount": "421"
  },
  {
    "Word": "writes",
    "FREQcount": "421"
  },
  {
    "Word": "brooks",
    "FREQcount": "420"
  },
  {
    "Word": "cape",
    "FREQcount": "420"
  },
  {
    "Word": "convicted",
    "FREQcount": "420"
  },
  {
    "Word": "lung",
    "FREQcount": "420"
  },
  {
    "Word": "technical",
    "FREQcount": "420"
  },
  {
    "Word": "visions",
    "FREQcount": "420"
  },
  {
    "Word": "wished",
    "FREQcount": "420"
  },
  {
    "Word": "congress",
    "FREQcount": "419"
  },
  {
    "Word": "fortunate",
    "FREQcount": "419"
  },
  {
    "Word": "harmony",
    "FREQcount": "419"
  },
  {
    "Word": "mature",
    "FREQcount": "419"
  },
  {
    "Word": "perspective",
    "FREQcount": "419"
  },
  {
    "Word": "radiation",
    "FREQcount": "419"
  },
  {
    "Word": "sang",
    "FREQcount": "419"
  },
  {
    "Word": "shelly",
    "FREQcount": "419"
  },
  {
    "Word": "sources",
    "FREQcount": "419"
  },
  {
    "Word": "sweating",
    "FREQcount": "419"
  },
  {
    "Word": "yacht",
    "FREQcount": "419"
  },
  {
    "Word": "canyon",
    "FREQcount": "418"
  },
  {
    "Word": "genuine",
    "FREQcount": "418"
  },
  {
    "Word": "kent",
    "FREQcount": "418"
  },
  {
    "Word": "larger",
    "FREQcount": "418"
  },
  {
    "Word": "lori",
    "FREQcount": "418"
  },
  {
    "Word": "shield",
    "FREQcount": "418"
  },
  {
    "Word": "sixteen",
    "FREQcount": "418"
  },
  {
    "Word": "strings",
    "FREQcount": "418"
  },
  {
    "Word": "deeds",
    "FREQcount": "417"
  },
  {
    "Word": "insisted",
    "FREQcount": "417"
  },
  {
    "Word": "lan",
    "FREQcount": "417"
  },
  {
    "Word": "mademoiselle",
    "FREQcount": "417"
  },
  {
    "Word": "autograph",
    "FREQcount": "416"
  },
  {
    "Word": "dedicated",
    "FREQcount": "416"
  },
  {
    "Word": "judging",
    "FREQcount": "416"
  },
  {
    "Word": "mick",
    "FREQcount": "416"
  },
  {
    "Word": "trains",
    "FREQcount": "416"
  },
  {
    "Word": "cocksucker",
    "FREQcount": "415"
  },
  {
    "Word": "doomed",
    "FREQcount": "415"
  },
  {
    "Word": "established",
    "FREQcount": "415"
  },
  {
    "Word": "minimum",
    "FREQcount": "415"
  },
  {
    "Word": "pad",
    "FREQcount": "415"
  },
  {
    "Word": "presume",
    "FREQcount": "415"
  },
  {
    "Word": "traditional",
    "FREQcount": "415"
  },
  {
    "Word": "alpha",
    "FREQcount": "414"
  },
  {
    "Word": "association",
    "FREQcount": "414"
  },
  {
    "Word": "courtesy",
    "FREQcount": "414"
  },
  {
    "Word": "eastern",
    "FREQcount": "414"
  },
  {
    "Word": "fletcher",
    "FREQcount": "414"
  },
  {
    "Word": "julius",
    "FREQcount": "414"
  },
  {
    "Word": "kicks",
    "FREQcount": "414"
  },
  {
    "Word": "panties",
    "FREQcount": "414"
  },
  {
    "Word": "scandal",
    "FREQcount": "414"
  },
  {
    "Word": "slaves",
    "FREQcount": "414"
  },
  {
    "Word": "abandon",
    "FREQcount": "413"
  },
  {
    "Word": "allergic",
    "FREQcount": "413"
  },
  {
    "Word": "andromeda",
    "FREQcount": "413"
  },
  {
    "Word": "belle",
    "FREQcount": "413"
  },
  {
    "Word": "capacity",
    "FREQcount": "413"
  },
  {
    "Word": "consciousness",
    "FREQcount": "413"
  },
  {
    "Word": "enterprise",
    "FREQcount": "413"
  },
  {
    "Word": "girlfriends",
    "FREQcount": "413"
  },
  {
    "Word": "improve",
    "FREQcount": "413"
  },
  {
    "Word": "instrument",
    "FREQcount": "413"
  },
  {
    "Word": "mccoy",
    "FREQcount": "413"
  },
  {
    "Word": "missy",
    "FREQcount": "413"
  },
  {
    "Word": "pony",
    "FREQcount": "413"
  },
  {
    "Word": "ski",
    "FREQcount": "413"
  },
  {
    "Word": "sleeps",
    "FREQcount": "413"
  },
  {
    "Word": "weaver",
    "FREQcount": "413"
  },
  {
    "Word": "whispering",
    "FREQcount": "413"
  },
  {
    "Word": "artists",
    "FREQcount": "412"
  },
  {
    "Word": "hawkeye",
    "FREQcount": "412"
  },
  {
    "Word": "momma",
    "FREQcount": "412"
  },
  {
    "Word": "needing",
    "FREQcount": "412"
  },
  {
    "Word": "reaching",
    "FREQcount": "412"
  },
  {
    "Word": "hose",
    "FREQcount": "411"
  },
  {
    "Word": "messenger",
    "FREQcount": "411"
  },
  {
    "Word": "missiles",
    "FREQcount": "411"
  },
  {
    "Word": "mole",
    "FREQcount": "411"
  },
  {
    "Word": "saunders",
    "FREQcount": "411"
  },
  {
    "Word": "versus",
    "FREQcount": "411"
  },
  {
    "Word": "breeze",
    "FREQcount": "410"
  },
  {
    "Word": "rash",
    "FREQcount": "410"
  },
  {
    "Word": "stream",
    "FREQcount": "410"
  },
  {
    "Word": "tray",
    "FREQcount": "410"
  },
  {
    "Word": "violet",
    "FREQcount": "410"
  },
  {
    "Word": "ankle",
    "FREQcount": "409"
  },
  {
    "Word": "candle",
    "FREQcount": "409"
  },
  {
    "Word": "couples",
    "FREQcount": "409"
  },
  {
    "Word": "defence",
    "FREQcount": "409"
  },
  {
    "Word": "devoted",
    "FREQcount": "409"
  },
  {
    "Word": "disgrace",
    "FREQcount": "409"
  },
  {
    "Word": "exception",
    "FREQcount": "409"
  },
  {
    "Word": "identification",
    "FREQcount": "409"
  },
  {
    "Word": "milo",
    "FREQcount": "409"
  },
  {
    "Word": "pale",
    "FREQcount": "409"
  },
  {
    "Word": "recover",
    "FREQcount": "409"
  },
  {
    "Word": "satan",
    "FREQcount": "409"
  },
  {
    "Word": "surgical",
    "FREQcount": "409"
  },
  {
    "Word": "worship",
    "FREQcount": "409"
  },
  {
    "Word": "attacking",
    "FREQcount": "408"
  },
  {
    "Word": "bubble",
    "FREQcount": "408"
  },
  {
    "Word": "circles",
    "FREQcount": "408"
  },
  {
    "Word": "dreadful",
    "FREQcount": "408"
  },
  {
    "Word": "manual",
    "FREQcount": "408"
  },
  {
    "Word": "pod",
    "FREQcount": "408"
  },
  {
    "Word": "tuna",
    "FREQcount": "408"
  },
  {
    "Word": "cooperation",
    "FREQcount": "407"
  },
  {
    "Word": "deb",
    "FREQcount": "407"
  },
  {
    "Word": "eternity",
    "FREQcount": "407"
  },
  {
    "Word": "floors",
    "FREQcount": "407"
  },
  {
    "Word": "grandson",
    "FREQcount": "407"
  },
  {
    "Word": "mae",
    "FREQcount": "407"
  },
  {
    "Word": "password",
    "FREQcount": "407"
  },
  {
    "Word": "rainbow",
    "FREQcount": "407"
  },
  {
    "Word": "symptoms",
    "FREQcount": "407"
  },
  {
    "Word": "bp",
    "FREQcount": "406"
  },
  {
    "Word": "chapel",
    "FREQcount": "406"
  },
  {
    "Word": "depression",
    "FREQcount": "406"
  },
  {
    "Word": "dip",
    "FREQcount": "406"
  },
  {
    "Word": "existed",
    "FREQcount": "406"
  },
  {
    "Word": "scaring",
    "FREQcount": "406"
  },
  {
    "Word": "searched",
    "FREQcount": "406"
  },
  {
    "Word": "tricky",
    "FREQcount": "406"
  },
  {
    "Word": "tuck",
    "FREQcount": "406"
  },
  {
    "Word": "watches",
    "FREQcount": "406"
  },
  {
    "Word": "aggressive",
    "FREQcount": "405"
  },
  {
    "Word": "author",
    "FREQcount": "405"
  },
  {
    "Word": "batteries",
    "FREQcount": "405"
  },
  {
    "Word": "forgiveness",
    "FREQcount": "405"
  },
  {
    "Word": "martini",
    "FREQcount": "405"
  },
  {
    "Word": "monkeys",
    "FREQcount": "405"
  },
  {
    "Word": "sickness",
    "FREQcount": "405"
  },
  {
    "Word": "businessman",
    "FREQcount": "404"
  },
  {
    "Word": "decides",
    "FREQcount": "404"
  },
  {
    "Word": "meals",
    "FREQcount": "404"
  },
  {
    "Word": "popped",
    "FREQcount": "404"
  },
  {
    "Word": "proves",
    "FREQcount": "404"
  },
  {
    "Word": "pulls",
    "FREQcount": "404"
  },
  {
    "Word": "skill",
    "FREQcount": "404"
  },
  {
    "Word": "smelled",
    "FREQcount": "404"
  },
  {
    "Word": "sneaking",
    "FREQcount": "404"
  },
  {
    "Word": "whitey",
    "FREQcount": "404"
  },
  {
    "Word": "connections",
    "FREQcount": "403"
  },
  {
    "Word": "contacts",
    "FREQcount": "403"
  },
  {
    "Word": "finishing",
    "FREQcount": "403"
  },
  {
    "Word": "focused",
    "FREQcount": "403"
  },
  {
    "Word": "kathy",
    "FREQcount": "403"
  },
  {
    "Word": "uniforms",
    "FREQcount": "403"
  },
  {
    "Word": "wandering",
    "FREQcount": "403"
  },
  {
    "Word": "whisper",
    "FREQcount": "403"
  },
  {
    "Word": "climbing",
    "FREQcount": "402"
  },
  {
    "Word": "duties",
    "FREQcount": "402"
  },
  {
    "Word": "hustle",
    "FREQcount": "402"
  },
  {
    "Word": "largest",
    "FREQcount": "402"
  },
  {
    "Word": "method",
    "FREQcount": "402"
  },
  {
    "Word": "proposition",
    "FREQcount": "402"
  },
  {
    "Word": "welfare",
    "FREQcount": "402"
  },
  {
    "Word": "abbott",
    "FREQcount": "401"
  },
  {
    "Word": "auntie",
    "FREQcount": "401"
  },
  {
    "Word": "ditch",
    "FREQcount": "401"
  },
  {
    "Word": "formula",
    "FREQcount": "401"
  },
  {
    "Word": "images",
    "FREQcount": "401"
  },
  {
    "Word": "lounge",
    "FREQcount": "401"
  },
  {
    "Word": "mere",
    "FREQcount": "401"
  },
  {
    "Word": "minus",
    "FREQcount": "401"
  },
  {
    "Word": "prosecution",
    "FREQcount": "401"
  },
  {
    "Word": "wiped",
    "FREQcount": "401"
  },
  {
    "Word": "accurate",
    "FREQcount": "400"
  },
  {
    "Word": "arrow",
    "FREQcount": "400"
  },
  {
    "Word": "assist",
    "FREQcount": "400"
  },
  {
    "Word": "attic",
    "FREQcount": "400"
  },
  {
    "Word": "backs",
    "FREQcount": "400"
  },
  {
    "Word": "cynthia",
    "FREQcount": "400"
  },
  {
    "Word": "forehead",
    "FREQcount": "400"
  },
  {
    "Word": "sal",
    "FREQcount": "400"
  },
  {
    "Word": "sis",
    "FREQcount": "400"
  },
  {
    "Word": "votes",
    "FREQcount": "400"
  },
  {
    "Word": "apologise",
    "FREQcount": "399"
  },
  {
    "Word": "defending",
    "FREQcount": "399"
  },
  {
    "Word": "groom",
    "FREQcount": "399"
  },
  {
    "Word": "saddle",
    "FREQcount": "399"
  },
  {
    "Word": "bracelet",
    "FREQcount": "398"
  },
  {
    "Word": "communications",
    "FREQcount": "398"
  },
  {
    "Word": "controls",
    "FREQcount": "398"
  },
  {
    "Word": "destroying",
    "FREQcount": "398"
  },
  {
    "Word": "disguise",
    "FREQcount": "398"
  },
  {
    "Word": "exclusive",
    "FREQcount": "398"
  },
  {
    "Word": "flattered",
    "FREQcount": "398"
  },
  {
    "Word": "kisses",
    "FREQcount": "398"
  },
  {
    "Word": "shiny",
    "FREQcount": "398"
  },
  {
    "Word": "thoughtful",
    "FREQcount": "398"
  },
  {
    "Word": "cue",
    "FREQcount": "397"
  },
  {
    "Word": "embassy",
    "FREQcount": "397"
  },
  {
    "Word": "gossip",
    "FREQcount": "397"
  },
  {
    "Word": "grounded",
    "FREQcount": "397"
  },
  {
    "Word": "hamburger",
    "FREQcount": "397"
  },
  {
    "Word": "lo",
    "FREQcount": "397"
  },
  {
    "Word": "ox",
    "FREQcount": "397"
  },
  {
    "Word": "rack",
    "FREQcount": "397"
  },
  {
    "Word": "relative",
    "FREQcount": "397"
  },
  {
    "Word": "sausage",
    "FREQcount": "397"
  },
  {
    "Word": "soil",
    "FREQcount": "397"
  },
  {
    "Word": "sustained",
    "FREQcount": "397"
  },
  {
    "Word": "creating",
    "FREQcount": "396"
  },
  {
    "Word": "dodge",
    "FREQcount": "396"
  },
  {
    "Word": "husbands",
    "FREQcount": "396"
  },
  {
    "Word": "institution",
    "FREQcount": "396"
  },
  {
    "Word": "joel",
    "FREQcount": "396"
  },
  {
    "Word": "maximum",
    "FREQcount": "396"
  },
  {
    "Word": "vital",
    "FREQcount": "396"
  },
  {
    "Word": "addition",
    "FREQcount": "395"
  },
  {
    "Word": "aspirin",
    "FREQcount": "395"
  },
  {
    "Word": "bore",
    "FREQcount": "395"
  },
  {
    "Word": "graduated",
    "FREQcount": "395"
  },
  {
    "Word": "gratitude",
    "FREQcount": "395"
  },
  {
    "Word": "liquid",
    "FREQcount": "395"
  },
  {
    "Word": "principle",
    "FREQcount": "395"
  },
  {
    "Word": "theirs",
    "FREQcount": "395"
  },
  {
    "Word": "adore",
    "FREQcount": "394"
  },
  {
    "Word": "arriving",
    "FREQcount": "394"
  },
  {
    "Word": "bailey",
    "FREQcount": "394"
  },
  {
    "Word": "blackmail",
    "FREQcount": "394"
  },
  {
    "Word": "persons",
    "FREQcount": "394"
  },
  {
    "Word": "pierre",
    "FREQcount": "394"
  },
  {
    "Word": "poisoned",
    "FREQcount": "394"
  },
  {
    "Word": "rot",
    "FREQcount": "394"
  },
  {
    "Word": "corporation",
    "FREQcount": "393"
  },
  {
    "Word": "expenses",
    "FREQcount": "393"
  },
  {
    "Word": "moore",
    "FREQcount": "393"
  },
  {
    "Word": "remembers",
    "FREQcount": "393"
  },
  {
    "Word": "rider",
    "FREQcount": "393"
  },
  {
    "Word": "risky",
    "FREQcount": "393"
  },
  {
    "Word": "shaft",
    "FREQcount": "393"
  },
  {
    "Word": "attempted",
    "FREQcount": "392"
  },
  {
    "Word": "deaths",
    "FREQcount": "392"
  },
  {
    "Word": "receiving",
    "FREQcount": "392"
  },
  {
    "Word": "ahem",
    "FREQcount": "391"
  },
  {
    "Word": "auto",
    "FREQcount": "391"
  },
  {
    "Word": "cans",
    "FREQcount": "391"
  },
  {
    "Word": "completed",
    "FREQcount": "391"
  },
  {
    "Word": "cuba",
    "FREQcount": "391"
  },
  {
    "Word": "drowned",
    "FREQcount": "391"
  },
  {
    "Word": "insanity",
    "FREQcount": "391"
  },
  {
    "Word": "interrupting",
    "FREQcount": "391"
  },
  {
    "Word": "perry",
    "FREQcount": "391"
  },
  {
    "Word": "si",
    "FREQcount": "391"
  },
  {
    "Word": "sunny",
    "FREQcount": "391"
  },
  {
    "Word": "switched",
    "FREQcount": "391"
  },
  {
    "Word": "groans",
    "FREQcount": "390"
  },
  {
    "Word": "importance",
    "FREQcount": "390"
  },
  {
    "Word": "inspired",
    "FREQcount": "390"
  },
  {
    "Word": "instinct",
    "FREQcount": "390"
  },
  {
    "Word": "magician",
    "FREQcount": "390"
  },
  {
    "Word": "mona",
    "FREQcount": "390"
  },
  {
    "Word": "passage",
    "FREQcount": "390"
  },
  {
    "Word": "sub",
    "FREQcount": "390"
  },
  {
    "Word": "terminal",
    "FREQcount": "390"
  },
  {
    "Word": "content",
    "FREQcount": "389"
  },
  {
    "Word": "pickup",
    "FREQcount": "389"
  },
  {
    "Word": "pilots",
    "FREQcount": "389"
  },
  {
    "Word": "un",
    "FREQcount": "389"
  },
  {
    "Word": "unto",
    "FREQcount": "389"
  },
  {
    "Word": "zip",
    "FREQcount": "389"
  },
  {
    "Word": "belief",
    "FREQcount": "388"
  },
  {
    "Word": "exhibit",
    "FREQcount": "388"
  },
  {
    "Word": "hush",
    "FREQcount": "388"
  },
  {
    "Word": "legally",
    "FREQcount": "388"
  },
  {
    "Word": "recipe",
    "FREQcount": "388"
  },
  {
    "Word": "spite",
    "FREQcount": "388"
  },
  {
    "Word": "spoon",
    "FREQcount": "388"
  },
  {
    "Word": "administration",
    "FREQcount": "387"
  },
  {
    "Word": "chains",
    "FREQcount": "387"
  },
  {
    "Word": "december",
    "FREQcount": "387"
  },
  {
    "Word": "forbidden",
    "FREQcount": "387"
  },
  {
    "Word": "pointed",
    "FREQcount": "387"
  },
  {
    "Word": "stove",
    "FREQcount": "387"
  },
  {
    "Word": "communist",
    "FREQcount": "386"
  },
  {
    "Word": "declare",
    "FREQcount": "386"
  },
  {
    "Word": "embrace",
    "FREQcount": "386"
  },
  {
    "Word": "karate",
    "FREQcount": "386"
  },
  {
    "Word": "lizzie",
    "FREQcount": "386"
  },
  {
    "Word": "masters",
    "FREQcount": "386"
  },
  {
    "Word": "nations",
    "FREQcount": "386"
  },
  {
    "Word": "possibilities",
    "FREQcount": "386"
  },
  {
    "Word": "seed",
    "FREQcount": "386"
  },
  {
    "Word": "wired",
    "FREQcount": "386"
  },
  {
    "Word": "bass",
    "FREQcount": "385"
  },
  {
    "Word": "bold",
    "FREQcount": "385"
  },
  {
    "Word": "genetic",
    "FREQcount": "385"
  },
  {
    "Word": "muscles",
    "FREQcount": "385"
  },
  {
    "Word": "peanuts",
    "FREQcount": "385"
  },
  {
    "Word": "peculiar",
    "FREQcount": "385"
  },
  {
    "Word": "prep",
    "FREQcount": "385"
  },
  {
    "Word": "prostitute",
    "FREQcount": "385"
  },
  {
    "Word": "react",
    "FREQcount": "385"
  },
  {
    "Word": "robinson",
    "FREQcount": "385"
  },
  {
    "Word": "rogers",
    "FREQcount": "385"
  },
  {
    "Word": "trophy",
    "FREQcount": "385"
  },
  {
    "Word": "violation",
    "FREQcount": "385"
  },
  {
    "Word": "accomplished",
    "FREQcount": "384"
  },
  {
    "Word": "knights",
    "FREQcount": "384"
  },
  {
    "Word": "legitimate",
    "FREQcount": "384"
  },
  {
    "Word": "offended",
    "FREQcount": "384"
  },
  {
    "Word": "savings",
    "FREQcount": "384"
  },
  {
    "Word": "throws",
    "FREQcount": "384"
  },
  {
    "Word": "winds",
    "FREQcount": "384"
  },
  {
    "Word": "hunch",
    "FREQcount": "383"
  },
  {
    "Word": "ja",
    "FREQcount": "383"
  },
  {
    "Word": "jenna",
    "FREQcount": "383"
  },
  {
    "Word": "offers",
    "FREQcount": "383"
  },
  {
    "Word": "backed",
    "FREQcount": "382"
  },
  {
    "Word": "bombing",
    "FREQcount": "382"
  },
  {
    "Word": "centuries",
    "FREQcount": "382"
  },
  {
    "Word": "chili",
    "FREQcount": "382"
  },
  {
    "Word": "easter",
    "FREQcount": "382"
  },
  {
    "Word": "ego",
    "FREQcount": "382"
  },
  {
    "Word": "flames",
    "FREQcount": "382"
  },
  {
    "Word": "grams",
    "FREQcount": "382"
  },
  {
    "Word": "included",
    "FREQcount": "382"
  },
  {
    "Word": "ink",
    "FREQcount": "382"
  },
  {
    "Word": "jolly",
    "FREQcount": "382"
  },
  {
    "Word": "nearest",
    "FREQcount": "382"
  },
  {
    "Word": "nicer",
    "FREQcount": "382"
  },
  {
    "Word": "protocol",
    "FREQcount": "382"
  },
  {
    "Word": "rum",
    "FREQcount": "382"
  },
  {
    "Word": "skies",
    "FREQcount": "382"
  },
  {
    "Word": "ton",
    "FREQcount": "382"
  },
  {
    "Word": "umbrella",
    "FREQcount": "382"
  },
  {
    "Word": "carriage",
    "FREQcount": "381"
  },
  {
    "Word": "dammit",
    "FREQcount": "381"
  },
  {
    "Word": "executed",
    "FREQcount": "381"
  },
  {
    "Word": "float",
    "FREQcount": "381"
  },
  {
    "Word": "juan",
    "FREQcount": "381"
  },
  {
    "Word": "mobile",
    "FREQcount": "381"
  },
  {
    "Word": "sings",
    "FREQcount": "381"
  },
  {
    "Word": "stitch",
    "FREQcount": "381"
  },
  {
    "Word": "tortured",
    "FREQcount": "381"
  },
  {
    "Word": "approximately",
    "FREQcount": "380"
  },
  {
    "Word": "chess",
    "FREQcount": "380"
  },
  {
    "Word": "expense",
    "FREQcount": "380"
  },
  {
    "Word": "favors",
    "FREQcount": "380"
  },
  {
    "Word": "observation",
    "FREQcount": "380"
  },
  {
    "Word": "outstanding",
    "FREQcount": "380"
  },
  {
    "Word": "potion",
    "FREQcount": "380"
  },
  {
    "Word": "advertising",
    "FREQcount": "379"
  },
  {
    "Word": "aisle",
    "FREQcount": "379"
  },
  {
    "Word": "bathing",
    "FREQcount": "379"
  },
  {
    "Word": "benefits",
    "FREQcount": "379"
  },
  {
    "Word": "billie",
    "FREQcount": "379"
  },
  {
    "Word": "concrete",
    "FREQcount": "379"
  },
  {
    "Word": "consent",
    "FREQcount": "379"
  },
  {
    "Word": "contacted",
    "FREQcount": "379"
  },
  {
    "Word": "dealt",
    "FREQcount": "379"
  },
  {
    "Word": "gesture",
    "FREQcount": "379"
  },
  {
    "Word": "guessed",
    "FREQcount": "379"
  },
  {
    "Word": "haunted",
    "FREQcount": "379"
  },
  {
    "Word": "occur",
    "FREQcount": "379"
  },
  {
    "Word": "ol",
    "FREQcount": "379"
  },
  {
    "Word": "racket",
    "FREQcount": "379"
  },
  {
    "Word": "ranger",
    "FREQcount": "379"
  },
  {
    "Word": "receipt",
    "FREQcount": "379"
  },
  {
    "Word": "shepherd",
    "FREQcount": "379"
  },
  {
    "Word": "alison",
    "FREQcount": "378"
  },
  {
    "Word": "anchor",
    "FREQcount": "378"
  },
  {
    "Word": "income",
    "FREQcount": "378"
  },
  {
    "Word": "injuries",
    "FREQcount": "378"
  },
  {
    "Word": "julian",
    "FREQcount": "378"
  },
  {
    "Word": "pipes",
    "FREQcount": "378"
  },
  {
    "Word": "ruining",
    "FREQcount": "378"
  },
  {
    "Word": "scotland",
    "FREQcount": "378"
  },
  {
    "Word": "colored",
    "FREQcount": "377"
  },
  {
    "Word": "cousins",
    "FREQcount": "377"
  },
  {
    "Word": "cursed",
    "FREQcount": "377"
  },
  {
    "Word": "distracted",
    "FREQcount": "377"
  },
  {
    "Word": "heel",
    "FREQcount": "377"
  },
  {
    "Word": "logical",
    "FREQcount": "377"
  },
  {
    "Word": "weekends",
    "FREQcount": "377"
  },
  {
    "Word": "guidance",
    "FREQcount": "376"
  },
  {
    "Word": "heights",
    "FREQcount": "376"
  },
  {
    "Word": "monk",
    "FREQcount": "376"
  },
  {
    "Word": "prescription",
    "FREQcount": "376"
  },
  {
    "Word": "prices",
    "FREQcount": "376"
  },
  {
    "Word": "sucking",
    "FREQcount": "376"
  },
  {
    "Word": "wang",
    "FREQcount": "376"
  },
  {
    "Word": "wealthy",
    "FREQcount": "376"
  },
  {
    "Word": "bothers",
    "FREQcount": "375"
  },
  {
    "Word": "brutal",
    "FREQcount": "375"
  },
  {
    "Word": "efforts",
    "FREQcount": "375"
  },
  {
    "Word": "fist",
    "FREQcount": "375"
  },
  {
    "Word": "freshman",
    "FREQcount": "375"
  },
  {
    "Word": "hamilton",
    "FREQcount": "375"
  },
  {
    "Word": "olive",
    "FREQcount": "375"
  },
  {
    "Word": "pirate",
    "FREQcount": "375"
  },
  {
    "Word": "regard",
    "FREQcount": "375"
  },
  {
    "Word": "sharks",
    "FREQcount": "375"
  },
  {
    "Word": "tide",
    "FREQcount": "375"
  },
  {
    "Word": "tops",
    "FREQcount": "375"
  },
  {
    "Word": "victoria",
    "FREQcount": "375"
  },
  {
    "Word": "achieve",
    "FREQcount": "374"
  },
  {
    "Word": "boobs",
    "FREQcount": "374"
  },
  {
    "Word": "ideal",
    "FREQcount": "374"
  },
  {
    "Word": "lobster",
    "FREQcount": "374"
  },
  {
    "Word": "owed",
    "FREQcount": "374"
  },
  {
    "Word": "precinct",
    "FREQcount": "374"
  },
  {
    "Word": "puzzle",
    "FREQcount": "374"
  },
  {
    "Word": "refer",
    "FREQcount": "374"
  },
  {
    "Word": "resident",
    "FREQcount": "374"
  },
  {
    "Word": "spinning",
    "FREQcount": "374"
  },
  {
    "Word": "agenda",
    "FREQcount": "373"
  },
  {
    "Word": "balcony",
    "FREQcount": "373"
  },
  {
    "Word": "breakdown",
    "FREQcount": "373"
  },
  {
    "Word": "casual",
    "FREQcount": "373"
  },
  {
    "Word": "casualties",
    "FREQcount": "373"
  },
  {
    "Word": "melt",
    "FREQcount": "373"
  },
  {
    "Word": "misses",
    "FREQcount": "373"
  },
  {
    "Word": "performed",
    "FREQcount": "373"
  },
  {
    "Word": "suspended",
    "FREQcount": "373"
  },
  {
    "Word": "suspicion",
    "FREQcount": "373"
  },
  {
    "Word": "alfred",
    "FREQcount": "372"
  },
  {
    "Word": "armor",
    "FREQcount": "372"
  },
  {
    "Word": "bizarre",
    "FREQcount": "372"
  },
  {
    "Word": "canceled",
    "FREQcount": "372"
  },
  {
    "Word": "celebrity",
    "FREQcount": "372"
  },
  {
    "Word": "claimed",
    "FREQcount": "372"
  },
  {
    "Word": "clears",
    "FREQcount": "372"
  },
  {
    "Word": "panel",
    "FREQcount": "372"
  },
  {
    "Word": "sissy",
    "FREQcount": "372"
  },
  {
    "Word": "spencer",
    "FREQcount": "372"
  },
  {
    "Word": "begged",
    "FREQcount": "371"
  },
  {
    "Word": "distress",
    "FREQcount": "371"
  },
  {
    "Word": "donny",
    "FREQcount": "371"
  },
  {
    "Word": "draft",
    "FREQcount": "371"
  },
  {
    "Word": "follows",
    "FREQcount": "371"
  },
  {
    "Word": "fu",
    "FREQcount": "371"
  },
  {
    "Word": "illness",
    "FREQcount": "371"
  },
  {
    "Word": "jammed",
    "FREQcount": "371"
  },
  {
    "Word": "joyce",
    "FREQcount": "371"
  },
  {
    "Word": "nightmares",
    "FREQcount": "371"
  },
  {
    "Word": "samson",
    "FREQcount": "371"
  },
  {
    "Word": "sandra",
    "FREQcount": "371"
  },
  {
    "Word": "shitty",
    "FREQcount": "371"
  },
  {
    "Word": "boxing",
    "FREQcount": "370"
  },
  {
    "Word": "continued",
    "FREQcount": "370"
  },
  {
    "Word": "elected",
    "FREQcount": "370"
  },
  {
    "Word": "factor",
    "FREQcount": "370"
  },
  {
    "Word": "gathering",
    "FREQcount": "370"
  },
  {
    "Word": "jewels",
    "FREQcount": "370"
  },
  {
    "Word": "organ",
    "FREQcount": "370"
  },
  {
    "Word": "salute",
    "FREQcount": "370"
  },
  {
    "Word": "scheme",
    "FREQcount": "370"
  },
  {
    "Word": "springs",
    "FREQcount": "370"
  },
  {
    "Word": "sylvia",
    "FREQcount": "370"
  },
  {
    "Word": "tick",
    "FREQcount": "370"
  },
  {
    "Word": "whipped",
    "FREQcount": "370"
  },
  {
    "Word": "abortion",
    "FREQcount": "369"
  },
  {
    "Word": "backyard",
    "FREQcount": "369"
  },
  {
    "Word": "dorm",
    "FREQcount": "369"
  },
  {
    "Word": "honorable",
    "FREQcount": "369"
  },
  {
    "Word": "jewel",
    "FREQcount": "369"
  },
  {
    "Word": "liable",
    "FREQcount": "369"
  },
  {
    "Word": "ordering",
    "FREQcount": "369"
  },
  {
    "Word": "bent",
    "FREQcount": "368"
  },
  {
    "Word": "bully",
    "FREQcount": "368"
  },
  {
    "Word": "drowning",
    "FREQcount": "368"
  },
  {
    "Word": "harriet",
    "FREQcount": "368"
  },
  {
    "Word": "honesty",
    "FREQcount": "368"
  },
  {
    "Word": "mutual",
    "FREQcount": "368"
  },
  {
    "Word": "platoon",
    "FREQcount": "368"
  },
  {
    "Word": "presentation",
    "FREQcount": "368"
  },
  {
    "Word": "rally",
    "FREQcount": "368"
  },
  {
    "Word": "standards",
    "FREQcount": "368"
  },
  {
    "Word": "annual",
    "FREQcount": "367"
  },
  {
    "Word": "christine",
    "FREQcount": "367"
  },
  {
    "Word": "drums",
    "FREQcount": "367"
  },
  {
    "Word": "integrity",
    "FREQcount": "367"
  },
  {
    "Word": "inviting",
    "FREQcount": "367"
  },
  {
    "Word": "limits",
    "FREQcount": "367"
  },
  {
    "Word": "nailed",
    "FREQcount": "367"
  },
  {
    "Word": "notify",
    "FREQcount": "367"
  },
  {
    "Word": "posted",
    "FREQcount": "367"
  },
  {
    "Word": "published",
    "FREQcount": "367"
  },
  {
    "Word": "scrambled",
    "FREQcount": "367"
  },
  {
    "Word": "trips",
    "FREQcount": "367"
  },
  {
    "Word": "wooden",
    "FREQcount": "367"
  },
  {
    "Word": "bounty",
    "FREQcount": "366"
  },
  {
    "Word": "chad",
    "FREQcount": "366"
  },
  {
    "Word": "demonstration",
    "FREQcount": "366"
  },
  {
    "Word": "glen",
    "FREQcount": "366"
  },
  {
    "Word": "intentions",
    "FREQcount": "366"
  },
  {
    "Word": "moe",
    "FREQcount": "366"
  },
  {
    "Word": "prosecutor",
    "FREQcount": "366"
  },
  {
    "Word": "quicker",
    "FREQcount": "366"
  },
  {
    "Word": "rely",
    "FREQcount": "366"
  },
  {
    "Word": "reserve",
    "FREQcount": "366"
  },
  {
    "Word": "rides",
    "FREQcount": "366"
  },
  {
    "Word": "tucker",
    "FREQcount": "366"
  },
  {
    "Word": "ants",
    "FREQcount": "365"
  },
  {
    "Word": "cheek",
    "FREQcount": "365"
  },
  {
    "Word": "craig",
    "FREQcount": "365"
  },
  {
    "Word": "douglas",
    "FREQcount": "365"
  },
  {
    "Word": "folk",
    "FREQcount": "365"
  },
  {
    "Word": "gracious",
    "FREQcount": "365"
  },
  {
    "Word": "noises",
    "FREQcount": "365"
  },
  {
    "Word": "savage",
    "FREQcount": "365"
  },
  {
    "Word": "amongst",
    "FREQcount": "364"
  },
  {
    "Word": "attending",
    "FREQcount": "364"
  },
  {
    "Word": "disorder",
    "FREQcount": "364"
  },
  {
    "Word": "fuss",
    "FREQcount": "364"
  },
  {
    "Word": "jaw",
    "FREQcount": "364"
  },
  {
    "Word": "moses",
    "FREQcount": "364"
  },
  {
    "Word": "occasionally",
    "FREQcount": "364"
  },
  {
    "Word": "substance",
    "FREQcount": "364"
  },
  {
    "Word": "calendar",
    "FREQcount": "363"
  },
  {
    "Word": "carnival",
    "FREQcount": "363"
  },
  {
    "Word": "confusion",
    "FREQcount": "363"
  },
  {
    "Word": "jelly",
    "FREQcount": "363"
  },
  {
    "Word": "lester",
    "FREQcount": "363"
  },
  {
    "Word": "mack",
    "FREQcount": "363"
  },
  {
    "Word": "sells",
    "FREQcount": "363"
  },
  {
    "Word": "weigh",
    "FREQcount": "363"
  },
  {
    "Word": "baltimore",
    "FREQcount": "362"
  },
  {
    "Word": "chi",
    "FREQcount": "362"
  },
  {
    "Word": "dearest",
    "FREQcount": "362"
  },
  {
    "Word": "fatal",
    "FREQcount": "362"
  },
  {
    "Word": "fighters",
    "FREQcount": "362"
  },
  {
    "Word": "harsh",
    "FREQcount": "362"
  },
  {
    "Word": "hysterical",
    "FREQcount": "362"
  },
  {
    "Word": "inspiration",
    "FREQcount": "362"
  },
  {
    "Word": "medium",
    "FREQcount": "362"
  },
  {
    "Word": "northern",
    "FREQcount": "362"
  },
  {
    "Word": "situations",
    "FREQcount": "362"
  },
  {
    "Word": "submarine",
    "FREQcount": "362"
  },
  {
    "Word": "ariel",
    "FREQcount": "361"
  },
  {
    "Word": "bam",
    "FREQcount": "361"
  },
  {
    "Word": "compound",
    "FREQcount": "361"
  },
  {
    "Word": "haul",
    "FREQcount": "361"
  },
  {
    "Word": "jin",
    "FREQcount": "361"
  },
  {
    "Word": "meters",
    "FREQcount": "361"
  },
  {
    "Word": "ridge",
    "FREQcount": "361"
  },
  {
    "Word": "strain",
    "FREQcount": "361"
  },
  {
    "Word": "aha",
    "FREQcount": "360"
  },
  {
    "Word": "apollo",
    "FREQcount": "360"
  },
  {
    "Word": "buys",
    "FREQcount": "360"
  },
  {
    "Word": "cooler",
    "FREQcount": "360"
  },
  {
    "Word": "erin",
    "FREQcount": "360"
  },
  {
    "Word": "european",
    "FREQcount": "360"
  },
  {
    "Word": "expose",
    "FREQcount": "360"
  },
  {
    "Word": "gag",
    "FREQcount": "360"
  },
  {
    "Word": "herd",
    "FREQcount": "360"
  },
  {
    "Word": "lifted",
    "FREQcount": "360"
  },
  {
    "Word": "memorial",
    "FREQcount": "360"
  },
  {
    "Word": "sector",
    "FREQcount": "360"
  },
  {
    "Word": "soviet",
    "FREQcount": "360"
  },
  {
    "Word": "caring",
    "FREQcount": "359"
  },
  {
    "Word": "elder",
    "FREQcount": "359"
  },
  {
    "Word": "feds",
    "FREQcount": "359"
  },
  {
    "Word": "katherine",
    "FREQcount": "359"
  },
  {
    "Word": "nowadays",
    "FREQcount": "359"
  },
  {
    "Word": "objective",
    "FREQcount": "359"
  },
  {
    "Word": "pursuit",
    "FREQcount": "359"
  },
  {
    "Word": "sentimental",
    "FREQcount": "359"
  },
  {
    "Word": "tales",
    "FREQcount": "359"
  },
  {
    "Word": "compromise",
    "FREQcount": "358"
  },
  {
    "Word": "congratulate",
    "FREQcount": "358"
  },
  {
    "Word": "cord",
    "FREQcount": "358"
  },
  {
    "Word": "experiences",
    "FREQcount": "358"
  },
  {
    "Word": "guardian",
    "FREQcount": "358"
  },
  {
    "Word": "length",
    "FREQcount": "358"
  },
  {
    "Word": "mule",
    "FREQcount": "358"
  },
  {
    "Word": "narrow",
    "FREQcount": "358"
  },
  {
    "Word": "paulie",
    "FREQcount": "358"
  },
  {
    "Word": "smashed",
    "FREQcount": "358"
  },
  {
    "Word": "sting",
    "FREQcount": "358"
  },
  {
    "Word": "strict",
    "FREQcount": "358"
  },
  {
    "Word": "beautifully",
    "FREQcount": "357"
  },
  {
    "Word": "closes",
    "FREQcount": "357"
  },
  {
    "Word": "fax",
    "FREQcount": "357"
  },
  {
    "Word": "lonesome",
    "FREQcount": "357"
  },
  {
    "Word": "plead",
    "FREQcount": "357"
  },
  {
    "Word": "resting",
    "FREQcount": "357"
  },
  {
    "Word": "smoked",
    "FREQcount": "357"
  },
  {
    "Word": "automatic",
    "FREQcount": "356"
  },
  {
    "Word": "controlled",
    "FREQcount": "356"
  },
  {
    "Word": "cries",
    "FREQcount": "356"
  },
  {
    "Word": "grunts",
    "FREQcount": "356"
  },
  {
    "Word": "lands",
    "FREQcount": "356"
  },
  {
    "Word": "officials",
    "FREQcount": "356"
  },
  {
    "Word": "relaxed",
    "FREQcount": "356"
  },
  {
    "Word": "shoots",
    "FREQcount": "356"
  },
  {
    "Word": "simpson",
    "FREQcount": "356"
  },
  {
    "Word": "tobacco",
    "FREQcount": "356"
  },
  {
    "Word": "intimate",
    "FREQcount": "355"
  },
  {
    "Word": "nun",
    "FREQcount": "355"
  },
  {
    "Word": "originally",
    "FREQcount": "355"
  },
  {
    "Word": "satisfaction",
    "FREQcount": "355"
  },
  {
    "Word": "shelf",
    "FREQcount": "355"
  },
  {
    "Word": "stepping",
    "FREQcount": "355"
  },
  {
    "Word": "subjects",
    "FREQcount": "355"
  },
  {
    "Word": "wires",
    "FREQcount": "355"
  },
  {
    "Word": "baldrick",
    "FREQcount": "354"
  },
  {
    "Word": "blaming",
    "FREQcount": "354"
  },
  {
    "Word": "emotionally",
    "FREQcount": "354"
  },
  {
    "Word": "grease",
    "FREQcount": "354"
  },
  {
    "Word": "hobby",
    "FREQcount": "354"
  },
  {
    "Word": "household",
    "FREQcount": "354"
  },
  {
    "Word": "mo",
    "FREQcount": "354"
  },
  {
    "Word": "moonlight",
    "FREQcount": "354"
  },
  {
    "Word": "semester",
    "FREQcount": "354"
  },
  {
    "Word": "stud",
    "FREQcount": "354"
  },
  {
    "Word": "subtle",
    "FREQcount": "354"
  },
  {
    "Word": "tis",
    "FREQcount": "354"
  },
  {
    "Word": "tolerate",
    "FREQcount": "354"
  },
  {
    "Word": "vanessa",
    "FREQcount": "354"
  },
  {
    "Word": "volume",
    "FREQcount": "354"
  },
  {
    "Word": "voted",
    "FREQcount": "354"
  },
  {
    "Word": "cleaner",
    "FREQcount": "353"
  },
  {
    "Word": "compliments",
    "FREQcount": "353"
  },
  {
    "Word": "convincing",
    "FREQcount": "353"
  },
  {
    "Word": "eleanor",
    "FREQcount": "353"
  },
  {
    "Word": "eugene",
    "FREQcount": "353"
  },
  {
    "Word": "frankenstein",
    "FREQcount": "353"
  },
  {
    "Word": "geek",
    "FREQcount": "353"
  },
  {
    "Word": "knives",
    "FREQcount": "353"
  },
  {
    "Word": "toby",
    "FREQcount": "353"
  },
  {
    "Word": "commanding",
    "FREQcount": "352"
  },
  {
    "Word": "crab",
    "FREQcount": "352"
  },
  {
    "Word": "elements",
    "FREQcount": "352"
  },
  {
    "Word": "explaining",
    "FREQcount": "352"
  },
  {
    "Word": "fountain",
    "FREQcount": "352"
  },
  {
    "Word": "kang",
    "FREQcount": "352"
  },
  {
    "Word": "myth",
    "FREQcount": "352"
  },
  {
    "Word": "nevada",
    "FREQcount": "352"
  },
  {
    "Word": "opposed",
    "FREQcount": "352"
  },
  {
    "Word": "pervert",
    "FREQcount": "352"
  },
  {
    "Word": "resort",
    "FREQcount": "352"
  },
  {
    "Word": "servants",
    "FREQcount": "352"
  },
  {
    "Word": "speaker",
    "FREQcount": "352"
  },
  {
    "Word": "yah",
    "FREQcount": "352"
  },
  {
    "Word": "bolt",
    "FREQcount": "351"
  },
  {
    "Word": "currently",
    "FREQcount": "351"
  },
  {
    "Word": "domestic",
    "FREQcount": "351"
  },
  {
    "Word": "gravity",
    "FREQcount": "351"
  },
  {
    "Word": "label",
    "FREQcount": "351"
  },
  {
    "Word": "pledge",
    "FREQcount": "351"
  },
  {
    "Word": "razor",
    "FREQcount": "351"
  },
  {
    "Word": "teenager",
    "FREQcount": "351"
  },
  {
    "Word": "yea",
    "FREQcount": "351"
  },
  {
    "Word": "chow",
    "FREQcount": "350"
  },
  {
    "Word": "clamp",
    "FREQcount": "350"
  },
  {
    "Word": "clearance",
    "FREQcount": "350"
  },
  {
    "Word": "cunt",
    "FREQcount": "350"
  },
  {
    "Word": "dispatch",
    "FREQcount": "350"
  },
  {
    "Word": "eager",
    "FREQcount": "350"
  },
  {
    "Word": "echo",
    "FREQcount": "350"
  },
  {
    "Word": "eighth",
    "FREQcount": "350"
  },
  {
    "Word": "electronic",
    "FREQcount": "350"
  },
  {
    "Word": "faggot",
    "FREQcount": "350"
  },
  {
    "Word": "messy",
    "FREQcount": "350"
  },
  {
    "Word": "nazi",
    "FREQcount": "350"
  },
  {
    "Word": "slick",
    "FREQcount": "350"
  },
  {
    "Word": "sorrow",
    "FREQcount": "350"
  },
  {
    "Word": "teenage",
    "FREQcount": "350"
  },
  {
    "Word": "visited",
    "FREQcount": "350"
  },
  {
    "Word": "bean",
    "FREQcount": "349"
  },
  {
    "Word": "collecting",
    "FREQcount": "349"
  },
  {
    "Word": "complaints",
    "FREQcount": "349"
  },
  {
    "Word": "maintenance",
    "FREQcount": "349"
  },
  {
    "Word": "mug",
    "FREQcount": "349"
  },
  {
    "Word": "otto",
    "FREQcount": "349"
  },
  {
    "Word": "plea",
    "FREQcount": "349"
  },
  {
    "Word": "restaurants",
    "FREQcount": "349"
  },
  {
    "Word": "rio",
    "FREQcount": "349"
  },
  {
    "Word": "shorty",
    "FREQcount": "349"
  },
  {
    "Word": "shovel",
    "FREQcount": "349"
  },
  {
    "Word": "attraction",
    "FREQcount": "348"
  },
  {
    "Word": "avoiding",
    "FREQcount": "348"
  },
  {
    "Word": "coordinates",
    "FREQcount": "348"
  },
  {
    "Word": "hardware",
    "FREQcount": "348"
  },
  {
    "Word": "kerry",
    "FREQcount": "348"
  },
  {
    "Word": "races",
    "FREQcount": "348"
  },
  {
    "Word": "swan",
    "FREQcount": "348"
  },
  {
    "Word": "conscious",
    "FREQcount": "347"
  },
  {
    "Word": "han",
    "FREQcount": "347"
  },
  {
    "Word": "jackass",
    "FREQcount": "347"
  },
  {
    "Word": "nicholas",
    "FREQcount": "347"
  },
  {
    "Word": "pose",
    "FREQcount": "347"
  },
  {
    "Word": "sensible",
    "FREQcount": "347"
  },
  {
    "Word": "blocked",
    "FREQcount": "346"
  },
  {
    "Word": "colleague",
    "FREQcount": "346"
  },
  {
    "Word": "experts",
    "FREQcount": "346"
  },
  {
    "Word": "nickname",
    "FREQcount": "346"
  },
  {
    "Word": "slightest",
    "FREQcount": "346"
  },
  {
    "Word": "sophisticated",
    "FREQcount": "346"
  },
  {
    "Word": "touches",
    "FREQcount": "346"
  },
  {
    "Word": "troubled",
    "FREQcount": "346"
  },
  {
    "Word": "yay",
    "FREQcount": "346"
  },
  {
    "Word": "affected",
    "FREQcount": "345"
  },
  {
    "Word": "african",
    "FREQcount": "345"
  },
  {
    "Word": "anxiety",
    "FREQcount": "345"
  },
  {
    "Word": "bart",
    "FREQcount": "345"
  },
  {
    "Word": "classified",
    "FREQcount": "345"
  },
  {
    "Word": "dudes",
    "FREQcount": "345"
  },
  {
    "Word": "greetings",
    "FREQcount": "345"
  },
  {
    "Word": "loop",
    "FREQcount": "345"
  },
  {
    "Word": "wakes",
    "FREQcount": "345"
  },
  {
    "Word": "horace",
    "FREQcount": "344"
  },
  {
    "Word": "lottery",
    "FREQcount": "344"
  },
  {
    "Word": "med",
    "FREQcount": "344"
  },
  {
    "Word": "monroe",
    "FREQcount": "344"
  },
  {
    "Word": "obligation",
    "FREQcount": "344"
  },
  {
    "Word": "painter",
    "FREQcount": "344"
  },
  {
    "Word": "psych",
    "FREQcount": "344"
  },
  {
    "Word": "remaining",
    "FREQcount": "344"
  },
  {
    "Word": "samuel",
    "FREQcount": "344"
  },
  {
    "Word": "spreading",
    "FREQcount": "344"
  },
  {
    "Word": "theft",
    "FREQcount": "344"
  },
  {
    "Word": "trey",
    "FREQcount": "344"
  },
  {
    "Word": "driveway",
    "FREQcount": "343"
  },
  {
    "Word": "items",
    "FREQcount": "343"
  },
  {
    "Word": "proposed",
    "FREQcount": "343"
  },
  {
    "Word": "psychological",
    "FREQcount": "343"
  },
  {
    "Word": "referring",
    "FREQcount": "343"
  },
  {
    "Word": "traveled",
    "FREQcount": "343"
  },
  {
    "Word": "woo",
    "FREQcount": "343"
  },
  {
    "Word": "confidential",
    "FREQcount": "342"
  },
  {
    "Word": "feast",
    "FREQcount": "342"
  },
  {
    "Word": "hardest",
    "FREQcount": "342"
  },
  {
    "Word": "hearst",
    "FREQcount": "342"
  },
  {
    "Word": "logic",
    "FREQcount": "342"
  },
  {
    "Word": "negotiate",
    "FREQcount": "342"
  },
  {
    "Word": "online",
    "FREQcount": "342"
  },
  {
    "Word": "peyton",
    "FREQcount": "342"
  },
  {
    "Word": "pirates",
    "FREQcount": "342"
  },
  {
    "Word": "preacher",
    "FREQcount": "342"
  },
  {
    "Word": "rabbi",
    "FREQcount": "342"
  },
  {
    "Word": "rarely",
    "FREQcount": "342"
  },
  {
    "Word": "sponge",
    "FREQcount": "342"
  },
  {
    "Word": "strongly",
    "FREQcount": "342"
  },
  {
    "Word": "swallowed",
    "FREQcount": "342"
  },
  {
    "Word": "baked",
    "FREQcount": "341"
  },
  {
    "Word": "covenant",
    "FREQcount": "341"
  },
  {
    "Word": "detectives",
    "FREQcount": "341"
  },
  {
    "Word": "holland",
    "FREQcount": "341"
  },
  {
    "Word": "january",
    "FREQcount": "341"
  },
  {
    "Word": "locks",
    "FREQcount": "341"
  },
  {
    "Word": "lodge",
    "FREQcount": "341"
  },
  {
    "Word": "miriam",
    "FREQcount": "341"
  },
  {
    "Word": "pedro",
    "FREQcount": "341"
  },
  {
    "Word": "scissors",
    "FREQcount": "341"
  },
  {
    "Word": "accidents",
    "FREQcount": "340"
  },
  {
    "Word": "bonds",
    "FREQcount": "340"
  },
  {
    "Word": "cigars",
    "FREQcount": "340"
  },
  {
    "Word": "circuit",
    "FREQcount": "340"
  },
  {
    "Word": "commonwealth",
    "FREQcount": "340"
  },
  {
    "Word": "drivers",
    "FREQcount": "340"
  },
  {
    "Word": "finals",
    "FREQcount": "340"
  },
  {
    "Word": "homer",
    "FREQcount": "340"
  },
  {
    "Word": "leap",
    "FREQcount": "340"
  },
  {
    "Word": "possessed",
    "FREQcount": "340"
  },
  {
    "Word": "respects",
    "FREQcount": "340"
  },
  {
    "Word": "targets",
    "FREQcount": "340"
  },
  {
    "Word": "baxter",
    "FREQcount": "339"
  },
  {
    "Word": "brakes",
    "FREQcount": "339"
  },
  {
    "Word": "dee",
    "FREQcount": "339"
  },
  {
    "Word": "dreamt",
    "FREQcount": "339"
  },
  {
    "Word": "enforcement",
    "FREQcount": "339"
  },
  {
    "Word": "galaxy",
    "FREQcount": "339"
  },
  {
    "Word": "guaranteed",
    "FREQcount": "339"
  },
  {
    "Word": "humiliated",
    "FREQcount": "339"
  },
  {
    "Word": "ming",
    "FREQcount": "339"
  },
  {
    "Word": "mississippi",
    "FREQcount": "339"
  },
  {
    "Word": "proven",
    "FREQcount": "339"
  },
  {
    "Word": "threats",
    "FREQcount": "339"
  },
  {
    "Word": "urge",
    "FREQcount": "339"
  },
  {
    "Word": "wishing",
    "FREQcount": "339"
  },
  {
    "Word": "disagree",
    "FREQcount": "338"
  },
  {
    "Word": "disk",
    "FREQcount": "338"
  },
  {
    "Word": "dot",
    "FREQcount": "338"
  },
  {
    "Word": "element",
    "FREQcount": "338"
  },
  {
    "Word": "endless",
    "FREQcount": "338"
  },
  {
    "Word": "feather",
    "FREQcount": "338"
  },
  {
    "Word": "gail",
    "FREQcount": "338"
  },
  {
    "Word": "greedy",
    "FREQcount": "338"
  },
  {
    "Word": "gypsy",
    "FREQcount": "338"
  },
  {
    "Word": "inappropriate",
    "FREQcount": "338"
  },
  {
    "Word": "responsibilities",
    "FREQcount": "338"
  },
  {
    "Word": "vegetables",
    "FREQcount": "338"
  },
  {
    "Word": "andre",
    "FREQcount": "337"
  },
  {
    "Word": "bicycle",
    "FREQcount": "337"
  },
  {
    "Word": "democracy",
    "FREQcount": "337"
  },
  {
    "Word": "frequency",
    "FREQcount": "337"
  },
  {
    "Word": "funds",
    "FREQcount": "337"
  },
  {
    "Word": "jeans",
    "FREQcount": "337"
  },
  {
    "Word": "mattress",
    "FREQcount": "337"
  },
  {
    "Word": "melody",
    "FREQcount": "337"
  },
  {
    "Word": "memo",
    "FREQcount": "337"
  },
  {
    "Word": "polly",
    "FREQcount": "337"
  },
  {
    "Word": "rejected",
    "FREQcount": "337"
  },
  {
    "Word": "tubes",
    "FREQcount": "337"
  },
  {
    "Word": "virgil",
    "FREQcount": "337"
  },
  {
    "Word": "withdraw",
    "FREQcount": "337"
  },
  {
    "Word": "catches",
    "FREQcount": "336"
  },
  {
    "Word": "copper",
    "FREQcount": "336"
  },
  {
    "Word": "dexter",
    "FREQcount": "336"
  },
  {
    "Word": "innocence",
    "FREQcount": "336"
  },
  {
    "Word": "notion",
    "FREQcount": "336"
  },
  {
    "Word": "offices",
    "FREQcount": "336"
  },
  {
    "Word": "promising",
    "FREQcount": "336"
  },
  {
    "Word": "respected",
    "FREQcount": "336"
  },
  {
    "Word": "warriors",
    "FREQcount": "336"
  },
  {
    "Word": "coal",
    "FREQcount": "335"
  },
  {
    "Word": "dragging",
    "FREQcount": "335"
  },
  {
    "Word": "experiments",
    "FREQcount": "335"
  },
  {
    "Word": "mice",
    "FREQcount": "335"
  },
  {
    "Word": "amateur",
    "FREQcount": "334"
  },
  {
    "Word": "architect",
    "FREQcount": "334"
  },
  {
    "Word": "atlanta",
    "FREQcount": "334"
  },
  {
    "Word": "consideration",
    "FREQcount": "334"
  },
  {
    "Word": "ew",
    "FREQcount": "334"
  },
  {
    "Word": "gown",
    "FREQcount": "334"
  },
  {
    "Word": "internet",
    "FREQcount": "334"
  },
  {
    "Word": "marching",
    "FREQcount": "334"
  },
  {
    "Word": "miracles",
    "FREQcount": "334"
  },
  {
    "Word": "needn",
    "FREQcount": "334"
  },
  {
    "Word": "ninth",
    "FREQcount": "334"
  },
  {
    "Word": "pier",
    "FREQcount": "334"
  },
  {
    "Word": "pregnancy",
    "FREQcount": "334"
  },
  {
    "Word": "salmon",
    "FREQcount": "334"
  },
  {
    "Word": "sawyer",
    "FREQcount": "334"
  },
  {
    "Word": "siren",
    "FREQcount": "334"
  },
  {
    "Word": "skinner",
    "FREQcount": "334"
  },
  {
    "Word": "starboard",
    "FREQcount": "334"
  },
  {
    "Word": "umm",
    "FREQcount": "334"
  },
  {
    "Word": "carries",
    "FREQcount": "333"
  },
  {
    "Word": "charts",
    "FREQcount": "333"
  },
  {
    "Word": "declared",
    "FREQcount": "333"
  },
  {
    "Word": "detention",
    "FREQcount": "333"
  },
  {
    "Word": "engineering",
    "FREQcount": "333"
  },
  {
    "Word": "fourteen",
    "FREQcount": "333"
  },
  {
    "Word": "gasoline",
    "FREQcount": "333"
  },
  {
    "Word": "hike",
    "FREQcount": "333"
  },
  {
    "Word": "registration",
    "FREQcount": "333"
  },
  {
    "Word": "survivors",
    "FREQcount": "333"
  },
  {
    "Word": "beep",
    "FREQcount": "332"
  },
  {
    "Word": "cancelled",
    "FREQcount": "332"
  },
  {
    "Word": "colleagues",
    "FREQcount": "332"
  },
  {
    "Word": "doubts",
    "FREQcount": "332"
  },
  {
    "Word": "maris",
    "FREQcount": "332"
  },
  {
    "Word": "risks",
    "FREQcount": "332"
  },
  {
    "Word": "urine",
    "FREQcount": "332"
  },
  {
    "Word": "vain",
    "FREQcount": "332"
  },
  {
    "Word": "venice",
    "FREQcount": "332"
  },
  {
    "Word": "airline",
    "FREQcount": "331"
  },
  {
    "Word": "approved",
    "FREQcount": "331"
  },
  {
    "Word": "clearing",
    "FREQcount": "331"
  },
  {
    "Word": "explosives",
    "FREQcount": "331"
  },
  {
    "Word": "forgiven",
    "FREQcount": "331"
  },
  {
    "Word": "kidnap",
    "FREQcount": "331"
  },
  {
    "Word": "laboratory",
    "FREQcount": "331"
  },
  {
    "Word": "morphine",
    "FREQcount": "331"
  },
  {
    "Word": "pronounce",
    "FREQcount": "331"
  },
  {
    "Word": "rehab",
    "FREQcount": "331"
  },
  {
    "Word": "riot",
    "FREQcount": "331"
  },
  {
    "Word": "robbing",
    "FREQcount": "331"
  },
  {
    "Word": "senate",
    "FREQcount": "331"
  },
  {
    "Word": "significant",
    "FREQcount": "331"
  },
  {
    "Word": "sloan",
    "FREQcount": "331"
  },
  {
    "Word": "stark",
    "FREQcount": "331"
  },
  {
    "Word": "stewart",
    "FREQcount": "331"
  },
  {
    "Word": "vows",
    "FREQcount": "331"
  },
  {
    "Word": "choke",
    "FREQcount": "330"
  },
  {
    "Word": "granddaughter",
    "FREQcount": "330"
  },
  {
    "Word": "involve",
    "FREQcount": "330"
  },
  {
    "Word": "lined",
    "FREQcount": "330"
  },
  {
    "Word": "methods",
    "FREQcount": "330"
  },
  {
    "Word": "wardrobe",
    "FREQcount": "330"
  },
  {
    "Word": "beeping",
    "FREQcount": "329"
  },
  {
    "Word": "cheerleader",
    "FREQcount": "329"
  },
  {
    "Word": "growth",
    "FREQcount": "329"
  },
  {
    "Word": "mansion",
    "FREQcount": "329"
  },
  {
    "Word": "mustard",
    "FREQcount": "329"
  },
  {
    "Word": "naive",
    "FREQcount": "329"
  },
  {
    "Word": "phoned",
    "FREQcount": "329"
  },
  {
    "Word": "tiffany",
    "FREQcount": "329"
  },
  {
    "Word": "butch",
    "FREQcount": "328"
  },
  {
    "Word": "fart",
    "FREQcount": "328"
  },
  {
    "Word": "happiest",
    "FREQcount": "328"
  },
  {
    "Word": "rabbits",
    "FREQcount": "328"
  },
  {
    "Word": "ram",
    "FREQcount": "328"
  },
  {
    "Word": "stew",
    "FREQcount": "328"
  },
  {
    "Word": "winchester",
    "FREQcount": "328"
  },
  {
    "Word": "altogether",
    "FREQcount": "327"
  },
  {
    "Word": "click",
    "FREQcount": "327"
  },
  {
    "Word": "creeps",
    "FREQcount": "327"
  },
  {
    "Word": "discharge",
    "FREQcount": "327"
  },
  {
    "Word": "drift",
    "FREQcount": "327"
  },
  {
    "Word": "extend",
    "FREQcount": "327"
  },
  {
    "Word": "ginger",
    "FREQcount": "327"
  },
  {
    "Word": "offensive",
    "FREQcount": "327"
  },
  {
    "Word": "pursue",
    "FREQcount": "327"
  },
  {
    "Word": "quest",
    "FREQcount": "327"
  },
  {
    "Word": "reservations",
    "FREQcount": "327"
  },
  {
    "Word": "stern",
    "FREQcount": "327"
  },
  {
    "Word": "tearing",
    "FREQcount": "327"
  },
  {
    "Word": "whereabouts",
    "FREQcount": "327"
  },
  {
    "Word": "angelus",
    "FREQcount": "326"
  },
  {
    "Word": "bullock",
    "FREQcount": "326"
  },
  {
    "Word": "canal",
    "FREQcount": "326"
  },
  {
    "Word": "carrier",
    "FREQcount": "326"
  },
  {
    "Word": "cups",
    "FREQcount": "326"
  },
  {
    "Word": "customs",
    "FREQcount": "326"
  },
  {
    "Word": "hangs",
    "FREQcount": "326"
  },
  {
    "Word": "healing",
    "FREQcount": "326"
  },
  {
    "Word": "literature",
    "FREQcount": "326"
  },
  {
    "Word": "luckily",
    "FREQcount": "326"
  },
  {
    "Word": "persuade",
    "FREQcount": "326"
  },
  {
    "Word": "psychotic",
    "FREQcount": "326"
  },
  {
    "Word": "tech",
    "FREQcount": "326"
  },
  {
    "Word": "torpedo",
    "FREQcount": "326"
  },
  {
    "Word": "congressman",
    "FREQcount": "325"
  },
  {
    "Word": "earthquake",
    "FREQcount": "325"
  },
  {
    "Word": "hay",
    "FREQcount": "325"
  },
  {
    "Word": "hereby",
    "FREQcount": "325"
  },
  {
    "Word": "initial",
    "FREQcount": "325"
  },
  {
    "Word": "performing",
    "FREQcount": "325"
  },
  {
    "Word": "purchase",
    "FREQcount": "325"
  },
  {
    "Word": "regulations",
    "FREQcount": "325"
  },
  {
    "Word": "roots",
    "FREQcount": "325"
  },
  {
    "Word": "tribe",
    "FREQcount": "325"
  },
  {
    "Word": "backing",
    "FREQcount": "324"
  },
  {
    "Word": "bein",
    "FREQcount": "324"
  },
  {
    "Word": "cereal",
    "FREQcount": "324"
  },
  {
    "Word": "chap",
    "FREQcount": "324"
  },
  {
    "Word": "convict",
    "FREQcount": "324"
  },
  {
    "Word": "depressing",
    "FREQcount": "324"
  },
  {
    "Word": "frighten",
    "FREQcount": "324"
  },
  {
    "Word": "intact",
    "FREQcount": "324"
  },
  {
    "Word": "peach",
    "FREQcount": "324"
  },
  {
    "Word": "rodney",
    "FREQcount": "324"
  },
  {
    "Word": "shares",
    "FREQcount": "324"
  },
  {
    "Word": "spilled",
    "FREQcount": "324"
  },
  {
    "Word": "surf",
    "FREQcount": "324"
  },
  {
    "Word": "wealth",
    "FREQcount": "324"
  },
  {
    "Word": "bake",
    "FREQcount": "323"
  },
  {
    "Word": "breed",
    "FREQcount": "323"
  },
  {
    "Word": "companion",
    "FREQcount": "323"
  },
  {
    "Word": "connecticut",
    "FREQcount": "323"
  },
  {
    "Word": "counted",
    "FREQcount": "323"
  },
  {
    "Word": "establish",
    "FREQcount": "323"
  },
  {
    "Word": "lighting",
    "FREQcount": "323"
  },
  {
    "Word": "lions",
    "FREQcount": "323"
  },
  {
    "Word": "nursing",
    "FREQcount": "323"
  },
  {
    "Word": "outrageous",
    "FREQcount": "323"
  },
  {
    "Word": "pond",
    "FREQcount": "323"
  },
  {
    "Word": "underwater",
    "FREQcount": "323"
  },
  {
    "Word": "winners",
    "FREQcount": "323"
  },
  {
    "Word": "absence",
    "FREQcount": "322"
  },
  {
    "Word": "colorado",
    "FREQcount": "322"
  },
  {
    "Word": "footsteps",
    "FREQcount": "322"
  },
  {
    "Word": "hairy",
    "FREQcount": "322"
  },
  {
    "Word": "settlement",
    "FREQcount": "322"
  },
  {
    "Word": "shipment",
    "FREQcount": "322"
  },
  {
    "Word": "shipping",
    "FREQcount": "322"
  },
  {
    "Word": "stripes",
    "FREQcount": "322"
  },
  {
    "Word": "tasty",
    "FREQcount": "322"
  },
  {
    "Word": "webster",
    "FREQcount": "322"
  },
  {
    "Word": "crashing",
    "FREQcount": "321"
  },
  {
    "Word": "curtains",
    "FREQcount": "321"
  },
  {
    "Word": "deceased",
    "FREQcount": "321"
  },
  {
    "Word": "diving",
    "FREQcount": "321"
  },
  {
    "Word": "global",
    "FREQcount": "321"
  },
  {
    "Word": "prophecy",
    "FREQcount": "321"
  },
  {
    "Word": "ramon",
    "FREQcount": "321"
  },
  {
    "Word": "swiss",
    "FREQcount": "321"
  },
  {
    "Word": "worms",
    "FREQcount": "321"
  },
  {
    "Word": "bronx",
    "FREQcount": "320"
  },
  {
    "Word": "bunk",
    "FREQcount": "320"
  },
  {
    "Word": "charging",
    "FREQcount": "320"
  },
  {
    "Word": "chester",
    "FREQcount": "320"
  },
  {
    "Word": "clues",
    "FREQcount": "320"
  },
  {
    "Word": "elegant",
    "FREQcount": "320"
  },
  {
    "Word": "faced",
    "FREQcount": "320"
  },
  {
    "Word": "lease",
    "FREQcount": "320"
  },
  {
    "Word": "liking",
    "FREQcount": "320"
  },
  {
    "Word": "spark",
    "FREQcount": "320"
  },
  {
    "Word": "syndrome",
    "FREQcount": "320"
  },
  {
    "Word": "velvet",
    "FREQcount": "320"
  },
  {
    "Word": "whew",
    "FREQcount": "320"
  },
  {
    "Word": "antonio",
    "FREQcount": "319"
  },
  {
    "Word": "authorized",
    "FREQcount": "319"
  },
  {
    "Word": "bourbon",
    "FREQcount": "319"
  },
  {
    "Word": "brace",
    "FREQcount": "319"
  },
  {
    "Word": "compassion",
    "FREQcount": "319"
  },
  {
    "Word": "deliberately",
    "FREQcount": "319"
  },
  {
    "Word": "ignorant",
    "FREQcount": "319"
  },
  {
    "Word": "puke",
    "FREQcount": "319"
  },
  {
    "Word": "scenario",
    "FREQcount": "319"
  },
  {
    "Word": "serves",
    "FREQcount": "319"
  },
  {
    "Word": "timer",
    "FREQcount": "319"
  },
  {
    "Word": "baggage",
    "FREQcount": "318"
  },
  {
    "Word": "coverage",
    "FREQcount": "318"
  },
  {
    "Word": "define",
    "FREQcount": "318"
  },
  {
    "Word": "figuring",
    "FREQcount": "318"
  },
  {
    "Word": "overtime",
    "FREQcount": "318"
  },
  {
    "Word": "retarded",
    "FREQcount": "318"
  },
  {
    "Word": "screech",
    "FREQcount": "318"
  },
  {
    "Word": "scrub",
    "FREQcount": "318"
  },
  {
    "Word": "sperm",
    "FREQcount": "318"
  },
  {
    "Word": "straw",
    "FREQcount": "318"
  },
  {
    "Word": "willow",
    "FREQcount": "318"
  },
  {
    "Word": "ashore",
    "FREQcount": "317"
  },
  {
    "Word": "bluff",
    "FREQcount": "317"
  },
  {
    "Word": "brat",
    "FREQcount": "317"
  },
  {
    "Word": "breach",
    "FREQcount": "317"
  },
  {
    "Word": "cavalry",
    "FREQcount": "317"
  },
  {
    "Word": "clowns",
    "FREQcount": "317"
  },
  {
    "Word": "erase",
    "FREQcount": "317"
  },
  {
    "Word": "explore",
    "FREQcount": "317"
  },
  {
    "Word": "meter",
    "FREQcount": "317"
  },
  {
    "Word": "napoleon",
    "FREQcount": "317"
  },
  {
    "Word": "replacement",
    "FREQcount": "317"
  },
  {
    "Word": "treats",
    "FREQcount": "317"
  },
  {
    "Word": "alcoholic",
    "FREQcount": "316"
  },
  {
    "Word": "assured",
    "FREQcount": "316"
  },
  {
    "Word": "bedtime",
    "FREQcount": "316"
  },
  {
    "Word": "carolina",
    "FREQcount": "316"
  },
  {
    "Word": "crib",
    "FREQcount": "316"
  },
  {
    "Word": "custom",
    "FREQcount": "316"
  },
  {
    "Word": "horns",
    "FREQcount": "316"
  },
  {
    "Word": "hugh",
    "FREQcount": "316"
  },
  {
    "Word": "mines",
    "FREQcount": "316"
  },
  {
    "Word": "overcome",
    "FREQcount": "316"
  },
  {
    "Word": "pine",
    "FREQcount": "316"
  },
  {
    "Word": "smiles",
    "FREQcount": "316"
  },
  {
    "Word": "stain",
    "FREQcount": "316"
  },
  {
    "Word": "struggling",
    "FREQcount": "316"
  },
  {
    "Word": "unnecessary",
    "FREQcount": "316"
  },
  {
    "Word": "wheelchair",
    "FREQcount": "316"
  },
  {
    "Word": "accountant",
    "FREQcount": "315"
  },
  {
    "Word": "camping",
    "FREQcount": "315"
  },
  {
    "Word": "civilized",
    "FREQcount": "315"
  },
  {
    "Word": "dental",
    "FREQcount": "315"
  },
  {
    "Word": "distinguished",
    "FREQcount": "315"
  },
  {
    "Word": "drunken",
    "FREQcount": "315"
  },
  {
    "Word": "elsewhere",
    "FREQcount": "315"
  },
  {
    "Word": "est",
    "FREQcount": "315"
  },
  {
    "Word": "hospitals",
    "FREQcount": "315"
  },
  {
    "Word": "hottest",
    "FREQcount": "315"
  },
  {
    "Word": "incoming",
    "FREQcount": "315"
  },
  {
    "Word": "lasted",
    "FREQcount": "315"
  },
  {
    "Word": "shocking",
    "FREQcount": "315"
  },
  {
    "Word": "applied",
    "FREQcount": "314"
  },
  {
    "Word": "countess",
    "FREQcount": "314"
  },
  {
    "Word": "definite",
    "FREQcount": "314"
  },
  {
    "Word": "engage",
    "FREQcount": "314"
  },
  {
    "Word": "fare",
    "FREQcount": "314"
  },
  {
    "Word": "pudding",
    "FREQcount": "314"
  },
  {
    "Word": "starve",
    "FREQcount": "314"
  },
  {
    "Word": "acknowledge",
    "FREQcount": "313"
  },
  {
    "Word": "booty",
    "FREQcount": "313"
  },
  {
    "Word": "carson",
    "FREQcount": "313"
  },
  {
    "Word": "earrings",
    "FREQcount": "313"
  },
  {
    "Word": "elbow",
    "FREQcount": "313"
  },
  {
    "Word": "entertain",
    "FREQcount": "313"
  },
  {
    "Word": "essay",
    "FREQcount": "313"
  },
  {
    "Word": "physician",
    "FREQcount": "313"
  },
  {
    "Word": "platform",
    "FREQcount": "313"
  },
  {
    "Word": "represents",
    "FREQcount": "313"
  },
  {
    "Word": "scam",
    "FREQcount": "313"
  },
  {
    "Word": "swinging",
    "FREQcount": "313"
  },
  {
    "Word": "yelled",
    "FREQcount": "313"
  },
  {
    "Word": "abilities",
    "FREQcount": "312"
  },
  {
    "Word": "den",
    "FREQcount": "312"
  },
  {
    "Word": "habits",
    "FREQcount": "312"
  },
  {
    "Word": "heavily",
    "FREQcount": "312"
  },
  {
    "Word": "ironic",
    "FREQcount": "312"
  },
  {
    "Word": "pinch",
    "FREQcount": "312"
  },
  {
    "Word": "products",
    "FREQcount": "312"
  },
  {
    "Word": "rendezvous",
    "FREQcount": "312"
  },
  {
    "Word": "stadium",
    "FREQcount": "312"
  },
  {
    "Word": "yen",
    "FREQcount": "312"
  },
  {
    "Word": "bathtub",
    "FREQcount": "311"
  },
  {
    "Word": "charmed",
    "FREQcount": "311"
  },
  {
    "Word": "cloth",
    "FREQcount": "311"
  },
  {
    "Word": "debts",
    "FREQcount": "311"
  },
  {
    "Word": "investigator",
    "FREQcount": "311"
  },
  {
    "Word": "journalist",
    "FREQcount": "311"
  },
  {
    "Word": "lawsuit",
    "FREQcount": "311"
  },
  {
    "Word": "madeline",
    "FREQcount": "311"
  },
  {
    "Word": "stack",
    "FREQcount": "311"
  },
  {
    "Word": "unpleasant",
    "FREQcount": "311"
  },
  {
    "Word": "vast",
    "FREQcount": "311"
  },
  {
    "Word": "zeus",
    "FREQcount": "311"
  },
  {
    "Word": "bumped",
    "FREQcount": "310"
  },
  {
    "Word": "chorus",
    "FREQcount": "310"
  },
  {
    "Word": "contain",
    "FREQcount": "310"
  },
  {
    "Word": "creation",
    "FREQcount": "310"
  },
  {
    "Word": "eighteen",
    "FREQcount": "310"
  },
  {
    "Word": "es",
    "FREQcount": "310"
  },
  {
    "Word": "fiction",
    "FREQcount": "310"
  },
  {
    "Word": "invention",
    "FREQcount": "310"
  },
  {
    "Word": "isolated",
    "FREQcount": "310"
  },
  {
    "Word": "ketchup",
    "FREQcount": "310"
  },
  {
    "Word": "positively",
    "FREQcount": "310"
  },
  {
    "Word": "pounding",
    "FREQcount": "310"
  },
  {
    "Word": "antique",
    "FREQcount": "309"
  },
  {
    "Word": "bats",
    "FREQcount": "309"
  },
  {
    "Word": "comb",
    "FREQcount": "309"
  },
  {
    "Word": "correctly",
    "FREQcount": "309"
  },
  {
    "Word": "hips",
    "FREQcount": "309"
  },
  {
    "Word": "noodles",
    "FREQcount": "309"
  },
  {
    "Word": "protective",
    "FREQcount": "309"
  },
  {
    "Word": "sunrise",
    "FREQcount": "309"
  },
  {
    "Word": "yankees",
    "FREQcount": "309"
  },
  {
    "Word": "articles",
    "FREQcount": "308"
  },
  {
    "Word": "bribe",
    "FREQcount": "308"
  },
  {
    "Word": "cured",
    "FREQcount": "308"
  },
  {
    "Word": "dash",
    "FREQcount": "308"
  },
  {
    "Word": "directed",
    "FREQcount": "308"
  },
  {
    "Word": "encourage",
    "FREQcount": "308"
  },
  {
    "Word": "frederick",
    "FREQcount": "308"
  },
  {
    "Word": "gibson",
    "FREQcount": "308"
  },
  {
    "Word": "montgomery",
    "FREQcount": "308"
  },
  {
    "Word": "musician",
    "FREQcount": "308"
  },
  {
    "Word": "ahold",
    "FREQcount": "307"
  },
  {
    "Word": "ding",
    "FREQcount": "307"
  },
  {
    "Word": "herman",
    "FREQcount": "307"
  },
  {
    "Word": "luxury",
    "FREQcount": "307"
  },
  {
    "Word": "mi",
    "FREQcount": "307"
  },
  {
    "Word": "rushing",
    "FREQcount": "307"
  },
  {
    "Word": "surprising",
    "FREQcount": "307"
  },
  {
    "Word": "waits",
    "FREQcount": "307"
  },
  {
    "Word": "carpenter",
    "FREQcount": "306"
  },
  {
    "Word": "civilians",
    "FREQcount": "306"
  },
  {
    "Word": "depending",
    "FREQcount": "306"
  },
  {
    "Word": "dickie",
    "FREQcount": "306"
  },
  {
    "Word": "dolly",
    "FREQcount": "306"
  },
  {
    "Word": "elk",
    "FREQcount": "306"
  },
  {
    "Word": "exotic",
    "FREQcount": "306"
  },
  {
    "Word": "furious",
    "FREQcount": "306"
  },
  {
    "Word": "garlic",
    "FREQcount": "306"
  },
  {
    "Word": "insulted",
    "FREQcount": "306"
  },
  {
    "Word": "niggers",
    "FREQcount": "306"
  },
  {
    "Word": "passionate",
    "FREQcount": "306"
  },
  {
    "Word": "principles",
    "FREQcount": "306"
  },
  {
    "Word": "printed",
    "FREQcount": "306"
  },
  {
    "Word": "vehicles",
    "FREQcount": "306"
  },
  {
    "Word": "voyage",
    "FREQcount": "306"
  },
  {
    "Word": "brake",
    "FREQcount": "305"
  },
  {
    "Word": "bubbles",
    "FREQcount": "305"
  },
  {
    "Word": "cinderella",
    "FREQcount": "305"
  },
  {
    "Word": "differences",
    "FREQcount": "305"
  },
  {
    "Word": "eliminate",
    "FREQcount": "305"
  },
  {
    "Word": "generations",
    "FREQcount": "305"
  },
  {
    "Word": "juliet",
    "FREQcount": "305"
  },
  {
    "Word": "poster",
    "FREQcount": "305"
  },
  {
    "Word": "sincere",
    "FREQcount": "305"
  },
  {
    "Word": "steer",
    "FREQcount": "305"
  },
  {
    "Word": "trading",
    "FREQcount": "305"
  },
  {
    "Word": "buchanan",
    "FREQcount": "304"
  },
  {
    "Word": "compartment",
    "FREQcount": "304"
  },
  {
    "Word": "confessed",
    "FREQcount": "304"
  },
  {
    "Word": "costumes",
    "FREQcount": "304"
  },
  {
    "Word": "drake",
    "FREQcount": "304"
  },
  {
    "Word": "graves",
    "FREQcount": "304"
  },
  {
    "Word": "sark",
    "FREQcount": "304"
  },
  {
    "Word": "scent",
    "FREQcount": "304"
  },
  {
    "Word": "shade",
    "FREQcount": "304"
  },
  {
    "Word": "stereo",
    "FREQcount": "304"
  },
  {
    "Word": "supervisor",
    "FREQcount": "304"
  },
  {
    "Word": "behold",
    "FREQcount": "303"
  },
  {
    "Word": "boil",
    "FREQcount": "303"
  },
  {
    "Word": "conviction",
    "FREQcount": "303"
  },
  {
    "Word": "cracking",
    "FREQcount": "303"
  },
  {
    "Word": "heller",
    "FREQcount": "303"
  },
  {
    "Word": "montana",
    "FREQcount": "303"
  },
  {
    "Word": "parlor",
    "FREQcount": "303"
  },
  {
    "Word": "peak",
    "FREQcount": "303"
  },
  {
    "Word": "ropes",
    "FREQcount": "303"
  },
  {
    "Word": "shook",
    "FREQcount": "303"
  },
  {
    "Word": "slipping",
    "FREQcount": "303"
  },
  {
    "Word": "writers",
    "FREQcount": "303"
  },
  {
    "Word": "assassin",
    "FREQcount": "302"
  },
  {
    "Word": "banner",
    "FREQcount": "302"
  },
  {
    "Word": "colony",
    "FREQcount": "302"
  },
  {
    "Word": "dances",
    "FREQcount": "302"
  },
  {
    "Word": "flashlight",
    "FREQcount": "302"
  },
  {
    "Word": "poisoning",
    "FREQcount": "302"
  },
  {
    "Word": "pouring",
    "FREQcount": "302"
  },
  {
    "Word": "slack",
    "FREQcount": "302"
  },
  {
    "Word": "spaghetti",
    "FREQcount": "302"
  },
  {
    "Word": "stamp",
    "FREQcount": "302"
  },
  {
    "Word": "wit",
    "FREQcount": "302"
  },
  {
    "Word": "wolves",
    "FREQcount": "302"
  },
  {
    "Word": "fayed",
    "FREQcount": "301"
  },
  {
    "Word": "groceries",
    "FREQcount": "301"
  },
  {
    "Word": "handwriting",
    "FREQcount": "301"
  },
  {
    "Word": "holler",
    "FREQcount": "301"
  },
  {
    "Word": "ignored",
    "FREQcount": "301"
  },
  {
    "Word": "lighten",
    "FREQcount": "301"
  },
  {
    "Word": "mortgage",
    "FREQcount": "301"
  },
  {
    "Word": "murderers",
    "FREQcount": "301"
  },
  {
    "Word": "nevertheless",
    "FREQcount": "301"
  },
  {
    "Word": "nude",
    "FREQcount": "301"
  },
  {
    "Word": "organs",
    "FREQcount": "301"
  },
  {
    "Word": "pigeon",
    "FREQcount": "301"
  },
  {
    "Word": "plaza",
    "FREQcount": "301"
  },
  {
    "Word": "randall",
    "FREQcount": "301"
  },
  {
    "Word": "regrets",
    "FREQcount": "301"
  },
  {
    "Word": "reliable",
    "FREQcount": "301"
  },
  {
    "Word": "rib",
    "FREQcount": "301"
  },
  {
    "Word": "shallow",
    "FREQcount": "301"
  },
  {
    "Word": "skate",
    "FREQcount": "301"
  },
  {
    "Word": "stir",
    "FREQcount": "301"
  },
  {
    "Word": "tomato",
    "FREQcount": "301"
  },
  {
    "Word": "vivian",
    "FREQcount": "301"
  },
  {
    "Word": "additional",
    "FREQcount": "300"
  },
  {
    "Word": "ammunition",
    "FREQcount": "300"
  },
  {
    "Word": "biological",
    "FREQcount": "300"
  },
  {
    "Word": "coats",
    "FREQcount": "300"
  },
  {
    "Word": "courts",
    "FREQcount": "300"
  },
  {
    "Word": "cycle",
    "FREQcount": "300"
  },
  {
    "Word": "dd",
    "FREQcount": "300"
  },
  {
    "Word": "destination",
    "FREQcount": "300"
  },
  {
    "Word": "glue",
    "FREQcount": "300"
  },
  {
    "Word": "harassment",
    "FREQcount": "300"
  },
  {
    "Word": "humiliating",
    "FREQcount": "300"
  },
  {
    "Word": "hunger",
    "FREQcount": "300"
  },
  {
    "Word": "inspection",
    "FREQcount": "300"
  },
  {
    "Word": "mayday",
    "FREQcount": "300"
  },
  {
    "Word": "modest",
    "FREQcount": "300"
  },
  {
    "Word": "newport",
    "FREQcount": "300"
  },
  {
    "Word": "pals",
    "FREQcount": "300"
  },
  {
    "Word": "shorter",
    "FREQcount": "300"
  },
  {
    "Word": "sloppy",
    "FREQcount": "300"
  },
  {
    "Word": "archie",
    "FREQcount": "299"
  },
  {
    "Word": "deadline",
    "FREQcount": "299"
  },
  {
    "Word": "despair",
    "FREQcount": "299"
  },
  {
    "Word": "probation",
    "FREQcount": "299"
  },
  {
    "Word": "sofa",
    "FREQcount": "299"
  },
  {
    "Word": "tequila",
    "FREQcount": "299"
  },
  {
    "Word": "universal",
    "FREQcount": "299"
  },
  {
    "Word": "wander",
    "FREQcount": "299"
  },
  {
    "Word": "accomplish",
    "FREQcount": "298"
  },
  {
    "Word": "battalion",
    "FREQcount": "298"
  },
  {
    "Word": "beau",
    "FREQcount": "298"
  },
  {
    "Word": "divide",
    "FREQcount": "298"
  },
  {
    "Word": "documentary",
    "FREQcount": "298"
  },
  {
    "Word": "evidently",
    "FREQcount": "298"
  },
  {
    "Word": "fastest",
    "FREQcount": "298"
  },
  {
    "Word": "feature",
    "FREQcount": "298"
  },
  {
    "Word": "housekeeper",
    "FREQcount": "298"
  },
  {
    "Word": "michigan",
    "FREQcount": "298"
  },
  {
    "Word": "pentagon",
    "FREQcount": "298"
  },
  {
    "Word": "poke",
    "FREQcount": "298"
  },
  {
    "Word": "recognise",
    "FREQcount": "298"
  },
  {
    "Word": "revealed",
    "FREQcount": "298"
  },
  {
    "Word": "shaving",
    "FREQcount": "298"
  },
  {
    "Word": "spends",
    "FREQcount": "298"
  },
  {
    "Word": "desperately",
    "FREQcount": "297"
  },
  {
    "Word": "fuzzy",
    "FREQcount": "297"
  },
  {
    "Word": "muffin",
    "FREQcount": "297"
  },
  {
    "Word": "niggas",
    "FREQcount": "297"
  },
  {
    "Word": "pajamas",
    "FREQcount": "297"
  },
  {
    "Word": "pressed",
    "FREQcount": "297"
  },
  {
    "Word": "sour",
    "FREQcount": "297"
  },
  {
    "Word": "whales",
    "FREQcount": "297"
  },
  {
    "Word": "whores",
    "FREQcount": "297"
  },
  {
    "Word": "wonders",
    "FREQcount": "297"
  },
  {
    "Word": "bon",
    "FREQcount": "296"
  },
  {
    "Word": "chambers",
    "FREQcount": "296"
  },
  {
    "Word": "contracts",
    "FREQcount": "296"
  },
  {
    "Word": "definition",
    "FREQcount": "296"
  },
  {
    "Word": "economy",
    "FREQcount": "296"
  },
  {
    "Word": "martial",
    "FREQcount": "296"
  },
  {
    "Word": "queer",
    "FREQcount": "296"
  },
  {
    "Word": "ra",
    "FREQcount": "296"
  },
  {
    "Word": "seventeen",
    "FREQcount": "296"
  },
  {
    "Word": "slam",
    "FREQcount": "296"
  },
  {
    "Word": "troop",
    "FREQcount": "296"
  },
  {
    "Word": "vet",
    "FREQcount": "296"
  },
  {
    "Word": "argh",
    "FREQcount": "295"
  },
  {
    "Word": "busting",
    "FREQcount": "295"
  },
  {
    "Word": "directors",
    "FREQcount": "295"
  },
  {
    "Word": "gilbert",
    "FREQcount": "295"
  },
  {
    "Word": "hilarious",
    "FREQcount": "295"
  },
  {
    "Word": "lv",
    "FREQcount": "295"
  },
  {
    "Word": "neighbourhood",
    "FREQcount": "295"
  },
  {
    "Word": "obliged",
    "FREQcount": "295"
  },
  {
    "Word": "presented",
    "FREQcount": "295"
  },
  {
    "Word": "remembering",
    "FREQcount": "295"
  },
  {
    "Word": "senor",
    "FREQcount": "295"
  },
  {
    "Word": "spells",
    "FREQcount": "295"
  },
  {
    "Word": "streak",
    "FREQcount": "295"
  },
  {
    "Word": "sweetest",
    "FREQcount": "295"
  },
  {
    "Word": "tow",
    "FREQcount": "295"
  },
  {
    "Word": "alma",
    "FREQcount": "294"
  },
  {
    "Word": "cheque",
    "FREQcount": "294"
  },
  {
    "Word": "classy",
    "FREQcount": "294"
  },
  {
    "Word": "cracker",
    "FREQcount": "294"
  },
  {
    "Word": "curly",
    "FREQcount": "294"
  },
  {
    "Word": "dc",
    "FREQcount": "294"
  },
  {
    "Word": "disco",
    "FREQcount": "294"
  },
  {
    "Word": "frightening",
    "FREQcount": "294"
  },
  {
    "Word": "tab",
    "FREQcount": "294"
  },
  {
    "Word": "trusting",
    "FREQcount": "294"
  },
  {
    "Word": "tsk",
    "FREQcount": "294"
  },
  {
    "Word": "vacuum",
    "FREQcount": "294"
  },
  {
    "Word": "variety",
    "FREQcount": "294"
  },
  {
    "Word": "blocking",
    "FREQcount": "293"
  },
  {
    "Word": "collected",
    "FREQcount": "293"
  },
  {
    "Word": "consistent",
    "FREQcount": "293"
  },
  {
    "Word": "dam",
    "FREQcount": "293"
  },
  {
    "Word": "facial",
    "FREQcount": "293"
  },
  {
    "Word": "glow",
    "FREQcount": "293"
  },
  {
    "Word": "hooray",
    "FREQcount": "293"
  },
  {
    "Word": "jealousy",
    "FREQcount": "293"
  },
  {
    "Word": "occupied",
    "FREQcount": "293"
  },
  {
    "Word": "orphan",
    "FREQcount": "293"
  },
  {
    "Word": "questioned",
    "FREQcount": "293"
  },
  {
    "Word": "resent",
    "FREQcount": "293"
  },
  {
    "Word": "roller",
    "FREQcount": "293"
  },
  {
    "Word": "scored",
    "FREQcount": "293"
  },
  {
    "Word": "spine",
    "FREQcount": "293"
  },
  {
    "Word": "suing",
    "FREQcount": "293"
  },
  {
    "Word": "switzerland",
    "FREQcount": "293"
  },
  {
    "Word": "tasted",
    "FREQcount": "293"
  },
  {
    "Word": "wheat",
    "FREQcount": "293"
  },
  {
    "Word": "appreciated",
    "FREQcount": "292"
  },
  {
    "Word": "beware",
    "FREQcount": "292"
  },
  {
    "Word": "bodyguard",
    "FREQcount": "292"
  },
  {
    "Word": "butts",
    "FREQcount": "292"
  },
  {
    "Word": "cadillac",
    "FREQcount": "292"
  },
  {
    "Word": "hayes",
    "FREQcount": "292"
  },
  {
    "Word": "janitor",
    "FREQcount": "292"
  },
  {
    "Word": "naval",
    "FREQcount": "292"
  },
  {
    "Word": "owners",
    "FREQcount": "292"
  },
  {
    "Word": "prettiest",
    "FREQcount": "292"
  },
  {
    "Word": "sticky",
    "FREQcount": "292"
  },
  {
    "Word": "automobile",
    "FREQcount": "291"
  },
  {
    "Word": "brett",
    "FREQcount": "291"
  },
  {
    "Word": "brewster",
    "FREQcount": "291"
  },
  {
    "Word": "cakes",
    "FREQcount": "291"
  },
  {
    "Word": "chemicals",
    "FREQcount": "291"
  },
  {
    "Word": "cuff",
    "FREQcount": "291"
  },
  {
    "Word": "deline",
    "FREQcount": "291"
  },
  {
    "Word": "era",
    "FREQcount": "291"
  },
  {
    "Word": "exposure",
    "FREQcount": "291"
  },
  {
    "Word": "feathers",
    "FREQcount": "291"
  },
  {
    "Word": "flood",
    "FREQcount": "291"
  },
  {
    "Word": "gabriel",
    "FREQcount": "291"
  },
  {
    "Word": "handful",
    "FREQcount": "291"
  },
  {
    "Word": "hugo",
    "FREQcount": "291"
  },
  {
    "Word": "medic",
    "FREQcount": "291"
  },
  {
    "Word": "millionaire",
    "FREQcount": "291"
  },
  {
    "Word": "nicest",
    "FREQcount": "291"
  },
  {
    "Word": "towns",
    "FREQcount": "291"
  },
  {
    "Word": "vegetable",
    "FREQcount": "291"
  },
  {
    "Word": "witnessed",
    "FREQcount": "291"
  },
  {
    "Word": "accuse",
    "FREQcount": "290"
  },
  {
    "Word": "attaboy",
    "FREQcount": "290"
  },
  {
    "Word": "attract",
    "FREQcount": "290"
  },
  {
    "Word": "clip",
    "FREQcount": "290"
  },
  {
    "Word": "crooked",
    "FREQcount": "290"
  },
  {
    "Word": "database",
    "FREQcount": "290"
  },
  {
    "Word": "generator",
    "FREQcount": "290"
  },
  {
    "Word": "mentally",
    "FREQcount": "290"
  },
  {
    "Word": "pets",
    "FREQcount": "290"
  },
  {
    "Word": "resume",
    "FREQcount": "290"
  },
  {
    "Word": "simmons",
    "FREQcount": "290"
  },
  {
    "Word": "tails",
    "FREQcount": "290"
  },
  {
    "Word": "tease",
    "FREQcount": "290"
  },
  {
    "Word": "toad",
    "FREQcount": "290"
  },
  {
    "Word": "announced",
    "FREQcount": "289"
  },
  {
    "Word": "cafeteria",
    "FREQcount": "289"
  },
  {
    "Word": "collapsed",
    "FREQcount": "289"
  },
  {
    "Word": "crackers",
    "FREQcount": "289"
  },
  {
    "Word": "craft",
    "FREQcount": "289"
  },
  {
    "Word": "crook",
    "FREQcount": "289"
  },
  {
    "Word": "dolls",
    "FREQcount": "289"
  },
  {
    "Word": "expedition",
    "FREQcount": "289"
  },
  {
    "Word": "feared",
    "FREQcount": "289"
  },
  {
    "Word": "hyde",
    "FREQcount": "289"
  },
  {
    "Word": "intel",
    "FREQcount": "289"
  },
  {
    "Word": "interrogation",
    "FREQcount": "289"
  },
  {
    "Word": "lethal",
    "FREQcount": "289"
  },
  {
    "Word": "lucille",
    "FREQcount": "289"
  },
  {
    "Word": "masks",
    "FREQcount": "289"
  },
  {
    "Word": "merlin",
    "FREQcount": "289"
  },
  {
    "Word": "obsession",
    "FREQcount": "289"
  },
  {
    "Word": "onions",
    "FREQcount": "289"
  },
  {
    "Word": "pressing",
    "FREQcount": "289"
  },
  {
    "Word": "scoop",
    "FREQcount": "289"
  },
  {
    "Word": "sophia",
    "FREQcount": "289"
  },
  {
    "Word": "spectacular",
    "FREQcount": "289"
  },
  {
    "Word": "cozy",
    "FREQcount": "288"
  },
  {
    "Word": "delight",
    "FREQcount": "288"
  },
  {
    "Word": "entertaining",
    "FREQcount": "288"
  },
  {
    "Word": "inevitable",
    "FREQcount": "288"
  },
  {
    "Word": "kirby",
    "FREQcount": "288"
  },
  {
    "Word": "orbit",
    "FREQcount": "288"
  },
  {
    "Word": "respectable",
    "FREQcount": "288"
  },
  {
    "Word": "seeking",
    "FREQcount": "288"
  },
  {
    "Word": "shack",
    "FREQcount": "288"
  },
  {
    "Word": "travels",
    "FREQcount": "288"
  },
  {
    "Word": "ultimately",
    "FREQcount": "288"
  },
  {
    "Word": "adjust",
    "FREQcount": "287"
  },
  {
    "Word": "blamed",
    "FREQcount": "287"
  },
  {
    "Word": "chauffeur",
    "FREQcount": "287"
  },
  {
    "Word": "essence",
    "FREQcount": "287"
  },
  {
    "Word": "farther",
    "FREQcount": "287"
  },
  {
    "Word": "fireworks",
    "FREQcount": "287"
  },
  {
    "Word": "preserve",
    "FREQcount": "287"
  },
  {
    "Word": "riley",
    "FREQcount": "287"
  },
  {
    "Word": "suction",
    "FREQcount": "287"
  },
  {
    "Word": "tomb",
    "FREQcount": "287"
  },
  {
    "Word": "developing",
    "FREQcount": "286"
  },
  {
    "Word": "doom",
    "FREQcount": "286"
  },
  {
    "Word": "evacuate",
    "FREQcount": "286"
  },
  {
    "Word": "fade",
    "FREQcount": "286"
  },
  {
    "Word": "intent",
    "FREQcount": "286"
  },
  {
    "Word": "oak",
    "FREQcount": "286"
  },
  {
    "Word": "owl",
    "FREQcount": "286"
  },
  {
    "Word": "promoted",
    "FREQcount": "286"
  },
  {
    "Word": "quarrel",
    "FREQcount": "286"
  },
  {
    "Word": "relevant",
    "FREQcount": "286"
  },
  {
    "Word": "republic",
    "FREQcount": "286"
  },
  {
    "Word": "satisfy",
    "FREQcount": "286"
  },
  {
    "Word": "scope",
    "FREQcount": "286"
  },
  {
    "Word": "sleeve",
    "FREQcount": "286"
  },
  {
    "Word": "co",
    "FREQcount": "285"
  },
  {
    "Word": "consult",
    "FREQcount": "285"
  },
  {
    "Word": "conversations",
    "FREQcount": "285"
  },
  {
    "Word": "difficulty",
    "FREQcount": "285"
  },
  {
    "Word": "felony",
    "FREQcount": "285"
  },
  {
    "Word": "fitting",
    "FREQcount": "285"
  },
  {
    "Word": "homecoming",
    "FREQcount": "285"
  },
  {
    "Word": "knots",
    "FREQcount": "285"
  },
  {
    "Word": "poop",
    "FREQcount": "285"
  },
  {
    "Word": "presidential",
    "FREQcount": "285"
  },
  {
    "Word": "projects",
    "FREQcount": "285"
  },
  {
    "Word": "quantum",
    "FREQcount": "285"
  },
  {
    "Word": "rubbish",
    "FREQcount": "285"
  },
  {
    "Word": "speeches",
    "FREQcount": "285"
  },
  {
    "Word": "audio",
    "FREQcount": "284"
  },
  {
    "Word": "corridor",
    "FREQcount": "284"
  },
  {
    "Word": "defeated",
    "FREQcount": "284"
  },
  {
    "Word": "dove",
    "FREQcount": "284"
  },
  {
    "Word": "encounter",
    "FREQcount": "284"
  },
  {
    "Word": "framed",
    "FREQcount": "284"
  },
  {
    "Word": "heartbeat",
    "FREQcount": "284"
  },
  {
    "Word": "listed",
    "FREQcount": "284"
  },
  {
    "Word": "lust",
    "FREQcount": "284"
  },
  {
    "Word": "oz",
    "FREQcount": "284"
  },
  {
    "Word": "programs",
    "FREQcount": "284"
  },
  {
    "Word": "relieve",
    "FREQcount": "284"
  },
  {
    "Word": "shells",
    "FREQcount": "284"
  },
  {
    "Word": "stanford",
    "FREQcount": "284"
  },
  {
    "Word": "taller",
    "FREQcount": "284"
  },
  {
    "Word": "trainer",
    "FREQcount": "284"
  },
  {
    "Word": "vest",
    "FREQcount": "284"
  },
  {
    "Word": "collapse",
    "FREQcount": "283"
  },
  {
    "Word": "dusty",
    "FREQcount": "283"
  },
  {
    "Word": "execute",
    "FREQcount": "283"
  },
  {
    "Word": "foreman",
    "FREQcount": "283"
  },
  {
    "Word": "gorilla",
    "FREQcount": "283"
  },
  {
    "Word": "issued",
    "FREQcount": "283"
  },
  {
    "Word": "madonna",
    "FREQcount": "283"
  },
  {
    "Word": "mia",
    "FREQcount": "283"
  },
  {
    "Word": "misunderstood",
    "FREQcount": "283"
  },
  {
    "Word": "phyllis",
    "FREQcount": "283"
  },
  {
    "Word": "rodeo",
    "FREQcount": "283"
  },
  {
    "Word": "stressed",
    "FREQcount": "283"
  },
  {
    "Word": "transportation",
    "FREQcount": "283"
  },
  {
    "Word": "vanished",
    "FREQcount": "283"
  },
  {
    "Word": "vera",
    "FREQcount": "283"
  },
  {
    "Word": "blair",
    "FREQcount": "282"
  },
  {
    "Word": "burglar",
    "FREQcount": "282"
  },
  {
    "Word": "cola",
    "FREQcount": "282"
  },
  {
    "Word": "concentration",
    "FREQcount": "282"
  },
  {
    "Word": "constitution",
    "FREQcount": "282"
  },
  {
    "Word": "educated",
    "FREQcount": "282"
  },
  {
    "Word": "freeway",
    "FREQcount": "282"
  },
  {
    "Word": "ghetto",
    "FREQcount": "282"
  },
  {
    "Word": "grid",
    "FREQcount": "282"
  },
  {
    "Word": "heavenly",
    "FREQcount": "282"
  },
  {
    "Word": "identical",
    "FREQcount": "282"
  },
  {
    "Word": "loosen",
    "FREQcount": "282"
  },
  {
    "Word": "maiden",
    "FREQcount": "282"
  },
  {
    "Word": "maine",
    "FREQcount": "282"
  },
  {
    "Word": "moose",
    "FREQcount": "282"
  },
  {
    "Word": "pinky",
    "FREQcount": "282"
  },
  {
    "Word": "profits",
    "FREQcount": "282"
  },
  {
    "Word": "punched",
    "FREQcount": "282"
  },
  {
    "Word": "shuttle",
    "FREQcount": "282"
  },
  {
    "Word": "strawberry",
    "FREQcount": "282"
  },
  {
    "Word": "submit",
    "FREQcount": "282"
  },
  {
    "Word": "veins",
    "FREQcount": "282"
  },
  {
    "Word": "assassination",
    "FREQcount": "281"
  },
  {
    "Word": "bloom",
    "FREQcount": "281"
  },
  {
    "Word": "butterfly",
    "FREQcount": "281"
  },
  {
    "Word": "chewing",
    "FREQcount": "281"
  },
  {
    "Word": "col",
    "FREQcount": "281"
  },
  {
    "Word": "examination",
    "FREQcount": "281"
  },
  {
    "Word": "hah",
    "FREQcount": "281"
  },
  {
    "Word": "lemonade",
    "FREQcount": "281"
  },
  {
    "Word": "orchestra",
    "FREQcount": "281"
  },
  {
    "Word": "oui",
    "FREQcount": "281"
  },
  {
    "Word": "prey",
    "FREQcount": "281"
  },
  {
    "Word": "ruled",
    "FREQcount": "281"
  },
  {
    "Word": "sane",
    "FREQcount": "281"
  },
  {
    "Word": "scumbag",
    "FREQcount": "281"
  },
  {
    "Word": "sol",
    "FREQcount": "281"
  },
  {
    "Word": "tactical",
    "FREQcount": "281"
  },
  {
    "Word": "artillery",
    "FREQcount": "280"
  },
  {
    "Word": "bark",
    "FREQcount": "280"
  },
  {
    "Word": "bites",
    "FREQcount": "280"
  },
  {
    "Word": "channels",
    "FREQcount": "280"
  },
  {
    "Word": "confirmation",
    "FREQcount": "280"
  },
  {
    "Word": "dozens",
    "FREQcount": "280"
  },
  {
    "Word": "february",
    "FREQcount": "280"
  },
  {
    "Word": "grocery",
    "FREQcount": "280"
  },
  {
    "Word": "mildred",
    "FREQcount": "280"
  },
  {
    "Word": "monte",
    "FREQcount": "280"
  },
  {
    "Word": "possess",
    "FREQcount": "280"
  },
  {
    "Word": "sew",
    "FREQcount": "280"
  },
  {
    "Word": "slot",
    "FREQcount": "280"
  },
  {
    "Word": "unlock",
    "FREQcount": "280"
  },
  {
    "Word": "warp",
    "FREQcount": "280"
  },
  {
    "Word": "weep",
    "FREQcount": "280"
  },
  {
    "Word": "whispers",
    "FREQcount": "280"
  },
  {
    "Word": "allows",
    "FREQcount": "279"
  },
  {
    "Word": "ancestors",
    "FREQcount": "279"
  },
  {
    "Word": "barber",
    "FREQcount": "279"
  },
  {
    "Word": "dismiss",
    "FREQcount": "279"
  },
  {
    "Word": "hesitate",
    "FREQcount": "279"
  },
  {
    "Word": "hiring",
    "FREQcount": "279"
  },
  {
    "Word": "listens",
    "FREQcount": "279"
  },
  {
    "Word": "psychology",
    "FREQcount": "279"
  },
  {
    "Word": "puppet",
    "FREQcount": "279"
  },
  {
    "Word": "runway",
    "FREQcount": "279"
  },
  {
    "Word": "scouts",
    "FREQcount": "279"
  },
  {
    "Word": "sidewalk",
    "FREQcount": "279"
  },
  {
    "Word": "spying",
    "FREQcount": "279"
  },
  {
    "Word": "squirrel",
    "FREQcount": "279"
  },
  {
    "Word": "statements",
    "FREQcount": "279"
  },
  {
    "Word": "waltz",
    "FREQcount": "279"
  },
  {
    "Word": "archer",
    "FREQcount": "278"
  },
  {
    "Word": "bananas",
    "FREQcount": "278"
  },
  {
    "Word": "defensive",
    "FREQcount": "278"
  },
  {
    "Word": "godfather",
    "FREQcount": "278"
  },
  {
    "Word": "importantly",
    "FREQcount": "278"
  },
  {
    "Word": "jasmine",
    "FREQcount": "278"
  },
  {
    "Word": "joshua",
    "FREQcount": "278"
  },
  {
    "Word": "nazis",
    "FREQcount": "278"
  },
  {
    "Word": "puppies",
    "FREQcount": "278"
  },
  {
    "Word": "reader",
    "FREQcount": "278"
  },
  {
    "Word": "slaughter",
    "FREQcount": "278"
  },
  {
    "Word": "ambush",
    "FREQcount": "277"
  },
  {
    "Word": "anyplace",
    "FREQcount": "277"
  },
  {
    "Word": "chops",
    "FREQcount": "277"
  },
  {
    "Word": "disappointment",
    "FREQcount": "277"
  },
  {
    "Word": "hee",
    "FREQcount": "277"
  },
  {
    "Word": "indicates",
    "FREQcount": "277"
  },
  {
    "Word": "mint",
    "FREQcount": "277"
  },
  {
    "Word": "politicians",
    "FREQcount": "277"
  },
  {
    "Word": "portrait",
    "FREQcount": "277"
  },
  {
    "Word": "rang",
    "FREQcount": "277"
  },
  {
    "Word": "roland",
    "FREQcount": "277"
  },
  {
    "Word": "sixty",
    "FREQcount": "277"
  },
  {
    "Word": "asian",
    "FREQcount": "276"
  },
  {
    "Word": "choosing",
    "FREQcount": "276"
  },
  {
    "Word": "deserted",
    "FREQcount": "276"
  },
  {
    "Word": "elders",
    "FREQcount": "276"
  },
  {
    "Word": "forcing",
    "FREQcount": "276"
  },
  {
    "Word": "gregory",
    "FREQcount": "276"
  },
  {
    "Word": "hatred",
    "FREQcount": "276"
  },
  {
    "Word": "leopard",
    "FREQcount": "276"
  },
  {
    "Word": "rescued",
    "FREQcount": "276"
  },
  {
    "Word": "suggestions",
    "FREQcount": "276"
  },
  {
    "Word": "theories",
    "FREQcount": "276"
  },
  {
    "Word": "tougher",
    "FREQcount": "276"
  },
  {
    "Word": "tourists",
    "FREQcount": "276"
  },
  {
    "Word": "vengeance",
    "FREQcount": "276"
  },
  {
    "Word": "vow",
    "FREQcount": "276"
  },
  {
    "Word": "behaviour",
    "FREQcount": "275"
  },
  {
    "Word": "clumsy",
    "FREQcount": "275"
  },
  {
    "Word": "corners",
    "FREQcount": "275"
  },
  {
    "Word": "departure",
    "FREQcount": "275"
  },
  {
    "Word": "digital",
    "FREQcount": "275"
  },
  {
    "Word": "examined",
    "FREQcount": "275"
  },
  {
    "Word": "extension",
    "FREQcount": "275"
  },
  {
    "Word": "fag",
    "FREQcount": "275"
  },
  {
    "Word": "failing",
    "FREQcount": "275"
  },
  {
    "Word": "hanna",
    "FREQcount": "275"
  },
  {
    "Word": "pause",
    "FREQcount": "275"
  },
  {
    "Word": "perfection",
    "FREQcount": "275"
  },
  {
    "Word": "popping",
    "FREQcount": "275"
  },
  {
    "Word": "towers",
    "FREQcount": "275"
  },
  {
    "Word": "ammo",
    "FREQcount": "274"
  },
  {
    "Word": "bands",
    "FREQcount": "274"
  },
  {
    "Word": "bin",
    "FREQcount": "274"
  },
  {
    "Word": "campbell",
    "FREQcount": "274"
  },
  {
    "Word": "delayed",
    "FREQcount": "274"
  },
  {
    "Word": "dwight",
    "FREQcount": "274"
  },
  {
    "Word": "employer",
    "FREQcount": "274"
  },
  {
    "Word": "equally",
    "FREQcount": "274"
  },
  {
    "Word": "florence",
    "FREQcount": "274"
  },
  {
    "Word": "hideous",
    "FREQcount": "274"
  },
  {
    "Word": "insulting",
    "FREQcount": "274"
  },
  {
    "Word": "mock",
    "FREQcount": "274"
  },
  {
    "Word": "negro",
    "FREQcount": "274"
  },
  {
    "Word": "tango",
    "FREQcount": "274"
  },
  {
    "Word": "thankful",
    "FREQcount": "274"
  },
  {
    "Word": "acquaintance",
    "FREQcount": "273"
  },
  {
    "Word": "addict",
    "FREQcount": "273"
  },
  {
    "Word": "ambition",
    "FREQcount": "273"
  },
  {
    "Word": "ant",
    "FREQcount": "273"
  },
  {
    "Word": "donkey",
    "FREQcount": "273"
  },
  {
    "Word": "erica",
    "FREQcount": "273"
  },
  {
    "Word": "ethics",
    "FREQcount": "273"
  },
  {
    "Word": "ferry",
    "FREQcount": "273"
  },
  {
    "Word": "finance",
    "FREQcount": "273"
  },
  {
    "Word": "helm",
    "FREQcount": "273"
  },
  {
    "Word": "mouths",
    "FREQcount": "273"
  },
  {
    "Word": "offence",
    "FREQcount": "273"
  },
  {
    "Word": "orphanage",
    "FREQcount": "273"
  },
  {
    "Word": "peel",
    "FREQcount": "273"
  },
  {
    "Word": "rebel",
    "FREQcount": "273"
  },
  {
    "Word": "requests",
    "FREQcount": "273"
  },
  {
    "Word": "sponsor",
    "FREQcount": "273"
  },
  {
    "Word": "bees",
    "FREQcount": "272"
  },
  {
    "Word": "blouse",
    "FREQcount": "272"
  },
  {
    "Word": "crank",
    "FREQcount": "272"
  },
  {
    "Word": "dancers",
    "FREQcount": "272"
  },
  {
    "Word": "employment",
    "FREQcount": "272"
  },
  {
    "Word": "evolution",
    "FREQcount": "272"
  },
  {
    "Word": "gangster",
    "FREQcount": "272"
  },
  {
    "Word": "graveyard",
    "FREQcount": "272"
  },
  {
    "Word": "holt",
    "FREQcount": "272"
  },
  {
    "Word": "kneel",
    "FREQcount": "272"
  },
  {
    "Word": "landlord",
    "FREQcount": "272"
  },
  {
    "Word": "peek",
    "FREQcount": "272"
  },
  {
    "Word": "prophet",
    "FREQcount": "272"
  },
  {
    "Word": "recommended",
    "FREQcount": "272"
  },
  {
    "Word": "specialty",
    "FREQcount": "272"
  },
  {
    "Word": "stray",
    "FREQcount": "272"
  },
  {
    "Word": "vomit",
    "FREQcount": "272"
  },
  {
    "Word": "warner",
    "FREQcount": "272"
  },
  {
    "Word": "wrecked",
    "FREQcount": "272"
  },
  {
    "Word": "artery",
    "FREQcount": "271"
  },
  {
    "Word": "choir",
    "FREQcount": "271"
  },
  {
    "Word": "corrupt",
    "FREQcount": "271"
  },
  {
    "Word": "explosive",
    "FREQcount": "271"
  },
  {
    "Word": "flirting",
    "FREQcount": "271"
  },
  {
    "Word": "headaches",
    "FREQcount": "271"
  },
  {
    "Word": "jurisdiction",
    "FREQcount": "271"
  },
  {
    "Word": "marijuana",
    "FREQcount": "271"
  },
  {
    "Word": "rivers",
    "FREQcount": "271"
  },
  {
    "Word": "topic",
    "FREQcount": "271"
  },
  {
    "Word": "unacceptable",
    "FREQcount": "271"
  },
  {
    "Word": "appointed",
    "FREQcount": "270"
  },
  {
    "Word": "asia",
    "FREQcount": "270"
  },
  {
    "Word": "cottage",
    "FREQcount": "270"
  },
  {
    "Word": "dealers",
    "FREQcount": "270"
  },
  {
    "Word": "diapers",
    "FREQcount": "270"
  },
  {
    "Word": "dose",
    "FREQcount": "270"
  },
  {
    "Word": "egypt",
    "FREQcount": "270"
  },
  {
    "Word": "iris",
    "FREQcount": "270"
  },
  {
    "Word": "nova",
    "FREQcount": "270"
  },
  {
    "Word": "partnership",
    "FREQcount": "270"
  },
  {
    "Word": "repeating",
    "FREQcount": "270"
  },
  {
    "Word": "representative",
    "FREQcount": "270"
  },
  {
    "Word": "spice",
    "FREQcount": "270"
  },
  {
    "Word": "acceptable",
    "FREQcount": "269"
  },
  {
    "Word": "atlantis",
    "FREQcount": "269"
  },
  {
    "Word": "bruises",
    "FREQcount": "269"
  },
  {
    "Word": "einstein",
    "FREQcount": "269"
  },
  {
    "Word": "gravy",
    "FREQcount": "269"
  },
  {
    "Word": "historical",
    "FREQcount": "269"
  },
  {
    "Word": "humour",
    "FREQcount": "269"
  },
  {
    "Word": "impulse",
    "FREQcount": "269"
  },
  {
    "Word": "includes",
    "FREQcount": "269"
  },
  {
    "Word": "madman",
    "FREQcount": "269"
  },
  {
    "Word": "pains",
    "FREQcount": "269"
  },
  {
    "Word": "pearls",
    "FREQcount": "269"
  },
  {
    "Word": "sherlock",
    "FREQcount": "269"
  },
  {
    "Word": "stalking",
    "FREQcount": "269"
  },
  {
    "Word": "brazil",
    "FREQcount": "268"
  },
  {
    "Word": "denial",
    "FREQcount": "268"
  },
  {
    "Word": "expectations",
    "FREQcount": "268"
  },
  {
    "Word": "greet",
    "FREQcount": "268"
  },
  {
    "Word": "interviews",
    "FREQcount": "268"
  },
  {
    "Word": "kung",
    "FREQcount": "268"
  },
  {
    "Word": "lone",
    "FREQcount": "268"
  },
  {
    "Word": "measures",
    "FREQcount": "268"
  },
  {
    "Word": "produced",
    "FREQcount": "268"
  },
  {
    "Word": "rushed",
    "FREQcount": "268"
  },
  {
    "Word": "sh",
    "FREQcount": "268"
  },
  {
    "Word": "sole",
    "FREQcount": "268"
  },
  {
    "Word": "thirteen",
    "FREQcount": "268"
  },
  {
    "Word": "trance",
    "FREQcount": "268"
  },
  {
    "Word": "advised",
    "FREQcount": "267"
  },
  {
    "Word": "carbon",
    "FREQcount": "267"
  },
  {
    "Word": "chaplin",
    "FREQcount": "267"
  },
  {
    "Word": "colt",
    "FREQcount": "267"
  },
  {
    "Word": "ct",
    "FREQcount": "267"
  },
  {
    "Word": "designer",
    "FREQcount": "267"
  },
  {
    "Word": "devils",
    "FREQcount": "267"
  },
  {
    "Word": "disrespect",
    "FREQcount": "267"
  },
  {
    "Word": "gutter",
    "FREQcount": "267"
  },
  {
    "Word": "interior",
    "FREQcount": "267"
  },
  {
    "Word": "interrupted",
    "FREQcount": "267"
  },
  {
    "Word": "marker",
    "FREQcount": "267"
  },
  {
    "Word": "olivia",
    "FREQcount": "267"
  },
  {
    "Word": "que",
    "FREQcount": "267"
  },
  {
    "Word": "reaches",
    "FREQcount": "267"
  },
  {
    "Word": "realised",
    "FREQcount": "267"
  },
  {
    "Word": "shoo",
    "FREQcount": "267"
  },
  {
    "Word": "stamps",
    "FREQcount": "267"
  },
  {
    "Word": "stripper",
    "FREQcount": "267"
  },
  {
    "Word": "text",
    "FREQcount": "267"
  },
  {
    "Word": "tribute",
    "FREQcount": "267"
  },
  {
    "Word": "arrogant",
    "FREQcount": "266"
  },
  {
    "Word": "cuffs",
    "FREQcount": "266"
  },
  {
    "Word": "globe",
    "FREQcount": "266"
  },
  {
    "Word": "goofy",
    "FREQcount": "266"
  },
  {
    "Word": "gunfire",
    "FREQcount": "266"
  },
  {
    "Word": "heir",
    "FREQcount": "266"
  },
  {
    "Word": "kentucky",
    "FREQcount": "266"
  },
  {
    "Word": "marble",
    "FREQcount": "266"
  },
  {
    "Word": "offend",
    "FREQcount": "266"
  },
  {
    "Word": "rains",
    "FREQcount": "266"
  },
  {
    "Word": "vibe",
    "FREQcount": "266"
  },
  {
    "Word": "waving",
    "FREQcount": "266"
  },
  {
    "Word": "allowance",
    "FREQcount": "265"
  },
  {
    "Word": "boogie",
    "FREQcount": "265"
  },
  {
    "Word": "dont",
    "FREQcount": "265"
  },
  {
    "Word": "hairs",
    "FREQcount": "265"
  },
  {
    "Word": "junkie",
    "FREQcount": "265"
  },
  {
    "Word": "leaf",
    "FREQcount": "265"
  },
  {
    "Word": "precise",
    "FREQcount": "265"
  },
  {
    "Word": "repay",
    "FREQcount": "265"
  },
  {
    "Word": "residents",
    "FREQcount": "265"
  },
  {
    "Word": "teaches",
    "FREQcount": "265"
  },
  {
    "Word": "abraham",
    "FREQcount": "264"
  },
  {
    "Word": "ana",
    "FREQcount": "264"
  },
  {
    "Word": "armstrong",
    "FREQcount": "264"
  },
  {
    "Word": "boulevard",
    "FREQcount": "264"
  },
  {
    "Word": "bulls",
    "FREQcount": "264"
  },
  {
    "Word": "buyer",
    "FREQcount": "264"
  },
  {
    "Word": "chinatown",
    "FREQcount": "264"
  },
  {
    "Word": "fracture",
    "FREQcount": "264"
  },
  {
    "Word": "fugitive",
    "FREQcount": "264"
  },
  {
    "Word": "gained",
    "FREQcount": "264"
  },
  {
    "Word": "shifts",
    "FREQcount": "264"
  },
  {
    "Word": "slower",
    "FREQcount": "264"
  },
  {
    "Word": "specialist",
    "FREQcount": "264"
  },
  {
    "Word": "untie",
    "FREQcount": "264"
  },
  {
    "Word": "videotape",
    "FREQcount": "264"
  },
  {
    "Word": "banquet",
    "FREQcount": "263"
  },
  {
    "Word": "buddha",
    "FREQcount": "263"
  },
  {
    "Word": "cassie",
    "FREQcount": "263"
  },
  {
    "Word": "caution",
    "FREQcount": "263"
  },
  {
    "Word": "condom",
    "FREQcount": "263"
  },
  {
    "Word": "dante",
    "FREQcount": "263"
  },
  {
    "Word": "fay",
    "FREQcount": "263"
  },
  {
    "Word": "freezer",
    "FREQcount": "263"
  },
  {
    "Word": "golly",
    "FREQcount": "263"
  },
  {
    "Word": "handcuffs",
    "FREQcount": "263"
  },
  {
    "Word": "hunk",
    "FREQcount": "263"
  },
  {
    "Word": "hup",
    "FREQcount": "263"
  },
  {
    "Word": "im",
    "FREQcount": "263"
  },
  {
    "Word": "mode",
    "FREQcount": "263"
  },
  {
    "Word": "needles",
    "FREQcount": "263"
  },
  {
    "Word": "override",
    "FREQcount": "263"
  },
  {
    "Word": "primitive",
    "FREQcount": "263"
  },
  {
    "Word": "rep",
    "FREQcount": "263"
  },
  {
    "Word": "saves",
    "FREQcount": "263"
  },
  {
    "Word": "slippers",
    "FREQcount": "263"
  },
  {
    "Word": "strap",
    "FREQcount": "263"
  },
  {
    "Word": "thread",
    "FREQcount": "263"
  },
  {
    "Word": "trousers",
    "FREQcount": "263"
  },
  {
    "Word": "tumor",
    "FREQcount": "263"
  },
  {
    "Word": "valet",
    "FREQcount": "263"
  },
  {
    "Word": "virtue",
    "FREQcount": "263"
  },
  {
    "Word": "volunteers",
    "FREQcount": "263"
  },
  {
    "Word": "dom",
    "FREQcount": "262"
  },
  {
    "Word": "fanny",
    "FREQcount": "262"
  },
  {
    "Word": "fragile",
    "FREQcount": "262"
  },
  {
    "Word": "goals",
    "FREQcount": "262"
  },
  {
    "Word": "hanged",
    "FREQcount": "262"
  },
  {
    "Word": "instruments",
    "FREQcount": "262"
  },
  {
    "Word": "irrelevant",
    "FREQcount": "262"
  },
  {
    "Word": "marc",
    "FREQcount": "262"
  },
  {
    "Word": "narcotics",
    "FREQcount": "262"
  },
  {
    "Word": "panicked",
    "FREQcount": "262"
  },
  {
    "Word": "purposes",
    "FREQcount": "262"
  },
  {
    "Word": "regardless",
    "FREQcount": "262"
  },
  {
    "Word": "saloon",
    "FREQcount": "262"
  },
  {
    "Word": "secured",
    "FREQcount": "262"
  },
  {
    "Word": "sensors",
    "FREQcount": "262"
  },
  {
    "Word": "shields",
    "FREQcount": "262"
  },
  {
    "Word": "smokes",
    "FREQcount": "262"
  },
  {
    "Word": "sobbing",
    "FREQcount": "262"
  },
  {
    "Word": "supposedly",
    "FREQcount": "262"
  },
  {
    "Word": "tammy",
    "FREQcount": "262"
  },
  {
    "Word": "waist",
    "FREQcount": "262"
  },
  {
    "Word": "amazed",
    "FREQcount": "261"
  },
  {
    "Word": "appreciation",
    "FREQcount": "261"
  },
  {
    "Word": "backstage",
    "FREQcount": "261"
  },
  {
    "Word": "detect",
    "FREQcount": "261"
  },
  {
    "Word": "drip",
    "FREQcount": "261"
  },
  {
    "Word": "fails",
    "FREQcount": "261"
  },
  {
    "Word": "francs",
    "FREQcount": "261"
  },
  {
    "Word": "hog",
    "FREQcount": "261"
  },
  {
    "Word": "juvenile",
    "FREQcount": "261"
  },
  {
    "Word": "majority",
    "FREQcount": "261"
  },
  {
    "Word": "peacock",
    "FREQcount": "261"
  },
  {
    "Word": "rifles",
    "FREQcount": "261"
  },
  {
    "Word": "skeleton",
    "FREQcount": "261"
  },
  {
    "Word": "whistling",
    "FREQcount": "261"
  },
  {
    "Word": "allies",
    "FREQcount": "260"
  },
  {
    "Word": "assets",
    "FREQcount": "260"
  },
  {
    "Word": "battles",
    "FREQcount": "260"
  },
  {
    "Word": "blankets",
    "FREQcount": "260"
  },
  {
    "Word": "choking",
    "FREQcount": "260"
  },
  {
    "Word": "contains",
    "FREQcount": "260"
  },
  {
    "Word": "fatty",
    "FREQcount": "260"
  },
  {
    "Word": "immortal",
    "FREQcount": "260"
  },
  {
    "Word": "motto",
    "FREQcount": "260"
  },
  {
    "Word": "playground",
    "FREQcount": "260"
  },
  {
    "Word": "procedures",
    "FREQcount": "260"
  },
  {
    "Word": "publish",
    "FREQcount": "260"
  },
  {
    "Word": "secretly",
    "FREQcount": "260"
  },
  {
    "Word": "sip",
    "FREQcount": "260"
  },
  {
    "Word": "syrup",
    "FREQcount": "260"
  },
  {
    "Word": "thorn",
    "FREQcount": "260"
  },
  {
    "Word": "transplant",
    "FREQcount": "260"
  },
  {
    "Word": "unstable",
    "FREQcount": "260"
  },
  {
    "Word": "vietnamese",
    "FREQcount": "260"
  },
  {
    "Word": "altar",
    "FREQcount": "259"
  },
  {
    "Word": "amigo",
    "FREQcount": "259"
  },
  {
    "Word": "boyfriends",
    "FREQcount": "259"
  },
  {
    "Word": "fireplace",
    "FREQcount": "259"
  },
  {
    "Word": "funky",
    "FREQcount": "259"
  },
  {
    "Word": "grunting",
    "FREQcount": "259"
  },
  {
    "Word": "hilary",
    "FREQcount": "259"
  },
  {
    "Word": "jade",
    "FREQcount": "259"
  },
  {
    "Word": "lyrics",
    "FREQcount": "259"
  },
  {
    "Word": "overboard",
    "FREQcount": "259"
  },
  {
    "Word": "premises",
    "FREQcount": "259"
  },
  {
    "Word": "treason",
    "FREQcount": "259"
  },
  {
    "Word": "ads",
    "FREQcount": "258"
  },
  {
    "Word": "blink",
    "FREQcount": "258"
  },
  {
    "Word": "cafe",
    "FREQcount": "258"
  },
  {
    "Word": "dried",
    "FREQcount": "258"
  },
  {
    "Word": "jingle",
    "FREQcount": "258"
  },
  {
    "Word": "mechanic",
    "FREQcount": "258"
  },
  {
    "Word": "purely",
    "FREQcount": "258"
  },
  {
    "Word": "raines",
    "FREQcount": "258"
  },
  {
    "Word": "recommendation",
    "FREQcount": "258"
  },
  {
    "Word": "regards",
    "FREQcount": "258"
  },
  {
    "Word": "reno",
    "FREQcount": "258"
  },
  {
    "Word": "reserved",
    "FREQcount": "258"
  },
  {
    "Word": "ribbon",
    "FREQcount": "258"
  },
  {
    "Word": "rosa",
    "FREQcount": "258"
  },
  {
    "Word": "skipped",
    "FREQcount": "258"
  },
  {
    "Word": "underestimate",
    "FREQcount": "258"
  },
  {
    "Word": "unlikely",
    "FREQcount": "258"
  },
  {
    "Word": "vagina",
    "FREQcount": "258"
  },
  {
    "Word": "bluffing",
    "FREQcount": "257"
  },
  {
    "Word": "buckle",
    "FREQcount": "257"
  },
  {
    "Word": "flick",
    "FREQcount": "257"
  },
  {
    "Word": "gladly",
    "FREQcount": "257"
  },
  {
    "Word": "hotels",
    "FREQcount": "257"
  },
  {
    "Word": "hound",
    "FREQcount": "257"
  },
  {
    "Word": "lynch",
    "FREQcount": "257"
  },
  {
    "Word": "maxwell",
    "FREQcount": "257"
  },
  {
    "Word": "noisy",
    "FREQcount": "257"
  }
]

export {words}